/*
Module : ntservEventLogSource.h
Purpose: CNTEventLogSource��ӿڶ���
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
////////////////////////////// Macros / Defines ///////////////////////////////

#pragma once

#ifndef __NTSERVEVENTLOGSOURCE_H__
#define __NTSERVEVENTLOGSOURCE_H__


////////////////////////////// Includes ///////////////////////////////////////

#include "ntservDefines.h"


////////////////////////////// Classes ////////////////////////////////////////

//����ע�ᡢע����д�롢��װ��ж���¼���־��Ŀ��api�ķ�װ 
//i.e. the server side to the Event log APIs
class CNTSERVICE_EXT_CLASS CNTEventLogSource
{
public:
	//Constructors / Destructors
	CNTEventLogSource();
	CNTEventLogSource(_In_opt_z_ LPCTSTR pUNCServerName, _In_opt_z_ LPCTSTR pSourceName, _In_opt_z_ LPCTSTR pLogName);
	CNTEventLogSource(_In_opt_z_ LPCTSTR pUNCServerName, _In_opt_z_ LPCTSTR pSourceName);
	~CNTEventLogSource();

	//Accessors / Mutators
	void             SetServerName(_In_opt_z_ LPCTSTR pszServerName);
	CNTServiceString GetServerName() const { return m_sServerName; };
	void             SetSourceName(_In_opt_z_ LPCTSTR pszSourceName);
	CNTServiceString GetSourceName() const { return m_sSourceName; };
	void             SetLogName(_In_opt_z_ LPCTSTR pszLogName);
	CNTServiceString GetLogName() const { return m_sLogName; };

	//Methods
	operator HANDLE() const;
	_Return_type_success_(return != 0) BOOL Attach(_In_opt_ HANDLE hEventSource);
	HANDLE                                  Detach();
	_Return_type_success_(return != 0) BOOL Register(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pSourceName);
	_Return_type_success_(return != 0) BOOL Deregister();
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ WORD wCategory, _In_ DWORD dwEventID, _In_opt_ PSID pUserSid,
		_In_ WORD wNumStrings, _In_ DWORD dwDataSize, _In_reads_opt_(wNumStrings) LPCTSTR* pStrings, _In_reads_bytes_opt_(dwDataSize) LPVOID pRawData);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_opt_z_ LPCTSTR pszString);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2, _In_opt_z_ LPCTSTR pszString3);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2, _In_ DWORD dwCode, _In_ BOOL bReportAsHex = FALSE);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString, _In_ DWORD dwCode, _In_ BOOL bReportAsHex = FALSE);
	_Return_type_success_(return != 0) BOOL Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_ DWORD dwCode, _In_ BOOL bReportAsHex = FALSE);

	static _Return_type_success_(return != 0) BOOL Install(_In_opt_z_ LPCTSTR pszSourceName, _In_opt_z_ LPCTSTR pszEventMessageFile, _In_opt_z_ LPCTSTR pszEventCategoryMessageFile, _In_opt_z_ LPCTSTR pszEventParameterMessageFile, _In_ DWORD dwTypesSupported, _In_ DWORD dwCategoryCount);
	static _Return_type_success_(return != 0) BOOL Install(_In_opt_z_ LPCTSTR pszLogName, _In_opt_z_ LPCTSTR pszSourceName, _In_opt_z_ LPCTSTR pszEventMessageFile, _In_opt_z_ LPCTSTR pszEventCategoryMessageFile, _In_opt_z_ LPCTSTR pszEventParameterMessageFile, _In_ DWORD dwTypesSupported, _In_ DWORD dwCategoryCount);
	static _Return_type_success_(return != 0) BOOL Uninstall(_In_opt_z_ LPCTSTR pSourceName);
	static _Return_type_success_(return != 0) BOOL Uninstall(_In_opt_z_ LPCTSTR pszLogName, _In_opt_z_ LPCTSTR pszSourceName);
	static _Return_type_success_(return != 0) BOOL GetStringArrayFromRegistry(_In_ ATL::CRegKey& key, _In_opt_z_ LPCTSTR pszEntry, _Out_ CNTServiceStringArray& array, _Inout_opt_ DWORD* pLastError = nullptr);
	static _Return_type_success_(return != 0) BOOL SetStringArrayIntoRegistry(_In_ ATL::CRegKey& key, _In_opt_z_ LPCTSTR pszEntry, _In_ const CNTServiceStringArray& array, _Inout_opt_ DWORD* pLastError = nullptr);

protected:
	HANDLE                       m_hEventSource;
	CNTServiceString             m_sServerName;
	CNTServiceString             m_sSourceName;
	CNTServiceString             m_sLogName;
	ATL::CComAutoCriticalSection m_csReport; //Critical section to protect multiple threads calling Report at the one time

	friend class CNTService;
};
#endif //#ifndef __NTSERVEVENTLOGSOURCE_H__