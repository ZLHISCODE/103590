/*
Module : ntservEventLogRecord.cpp
Purpose: ʵ��CEventLogRecord�Ľӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
/////////////////////////////////  Includes  //////////////////////////////////

#include "stdafx.h"
#include "ntservEventLogRecord.h"


/////////////////////////////////  Macros /////////////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Implementation //////////////////////////////

CEventLogRecord::CEventLogRecord() : m_dwRecordNumber(0),
	m_dwTimeGenerated(0),
	m_dwTimeWritten(0),
	m_dwEventID(0),
	m_wEventType(0),
	m_wEventCategory(0)
{
}

CEventLogRecord::CEventLogRecord(_In_ const CEventLogRecord& record)
{
	*this = record;
}

CEventLogRecord::CEventLogRecord(_In_opt_ const EVENTLOGRECORD* pRecord)
{
	//Validate our parameters
	ATLASSUME(pRecord != nullptr);

	//First the easy ones
	m_dwRecordNumber = pRecord->RecordNumber;
	m_dwTimeGenerated = pRecord->TimeGenerated;
	m_dwTimeWritten = pRecord->TimeWritten;
	m_dwEventID = pRecord->EventID;
	m_wEventType = pRecord->EventType;
	m_wEventCategory = pRecord->EventCategory;

	//Copy over the SID
	DWORD i = 0;
	const BYTE* pBeginRecord = reinterpret_cast<const BYTE*>(pRecord);
	ATLASSUME(pBeginRecord != nullptr);
	DWORD dwCurOffset = pRecord->UserSidOffset;
	if (pRecord->UserSidLength)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_UserSID.SetSize(0, pRecord->UserSidLength); //Preallocate the array to improve performance
#else
		m_UserSID.reserve(pRecord->UserSidLength); //Preallocate the array to improve performance
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}
	while (i < pRecord->UserSidLength)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_UserSID.Add(pBeginRecord[dwCurOffset + i]);
#else
		m_UserSID.push_back(pBeginRecord[dwCurOffset + i]);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		i++;
	}
	dwCurOffset += pRecord->UserSidLength;

	//Copy over the Binary data
	i = 0;
	dwCurOffset = pRecord->DataOffset;
	if (pRecord->DataLength)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_Data.SetSize(0, pRecord->DataLength); //Preallocate the array to improve performance
#else
		m_Data.reserve(pRecord->DataLength); //Preallocate the array to improve performance
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}
	while (i < pRecord->DataLength)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_Data.Add(pBeginRecord[dwCurOffset + i]);
#else
		m_Data.push_back(pBeginRecord[dwCurOffset + i]);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		i++;
	}
	dwCurOffset += pRecord->DataLength;

	//Copy over the SourceName
	const TCHAR* pszBeginRecord = reinterpret_cast<const TCHAR*>(pBeginRecord + sizeof(EVENTLOGRECORD));
	dwCurOffset = 0;
	DWORD dwStartOffset = dwCurOffset;
	while (pszBeginRecord[dwCurOffset])
		dwCurOffset++;
	m_sSourceName = &pszBeginRecord[dwStartOffset];

	//Skip over the null 
	dwCurOffset++;

	//Copy over the ComputerName
	dwStartOffset = dwCurOffset;
	while (pszBeginRecord[dwCurOffset])
		dwCurOffset++;
	m_sComputerName = &pszBeginRecord[dwStartOffset];

	//Copy over the strings array
	int nStringsRead = 0;
	pszBeginRecord = reinterpret_cast<const TCHAR*>(pBeginRecord + pRecord->StringOffset);
	dwCurOffset = 0;
	while (nStringsRead < pRecord->NumStrings)
	{
		//Find the next string
		dwStartOffset = dwCurOffset;
		while (pszBeginRecord[dwCurOffset])
			dwCurOffset++;

		//Add it to the array
		CNTServiceString sText(&pszBeginRecord[dwStartOffset]);
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_Strings.Add(sText);
#else
		m_Strings.push_back(sText);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

		//Increment the number of strings read
		nStringsRead++;

		//Skip over the null
		dwCurOffset++;
	}
}

CEventLogRecord& CEventLogRecord::operator=(_In_ const CEventLogRecord& record)
{
	m_dwRecordNumber = record.m_dwRecordNumber;
	m_dwTimeGenerated = record.m_dwTimeGenerated;
	m_dwTimeWritten = record.m_dwTimeWritten;
	m_dwEventID = record.m_dwEventID;
	m_wEventType = record.m_wEventType;
	m_wEventCategory = record.m_wEventCategory;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_UserSID.Copy(record.m_UserSID);
	m_Strings.Copy(record.m_Strings);
	m_Data.Copy(record.m_Data);
#else
	m_UserSID = record.m_UserSID;
	m_Strings = record.m_Strings;
	m_Data = record.m_Data;
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_sSourceName = record.m_sSourceName;
	m_sComputerName = record.m_sComputerName;

	return *this;
}