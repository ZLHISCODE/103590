/*
Module : ntservCmdLineInfo.h
Purpose: ʵ��CTNServiceCommandLineInfo�Ľӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/

///////////////////////////////// Includes ////////////////////////////////////
#include "stdafx.h"
#include "ntservCmdLineInfo.h"

#ifndef CNTSERVICE_MFC_EXTENSIONS
#ifndef _ALGORITHM_
#pragma message("To avoid this message, please put algorithm in your pre compiled header (normally stdafx.h)")
#include <algorithm>
#endif //#ifndef _ALGORITHM_
#endif //#ifndef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Macros //////////////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Implementation //////////////////////////////

CNTServiceCommandLineInfo::CNTServiceCommandLineInfo() : m_nShellCommand(RunAsService),
	m_dwTimeout(5000),
	m_bSilent(FALSE),
	m_bAutoStart(FALSE),
	m_bEnableServiceLogonRight(FALSE)
{
}

void CNTServiceCommandLineInfo::ParseParam(_In_z_ LPCTSTR pszParam, _In_ BOOL bFlag, _In_ BOOL bLast)
{
	if (bFlag)
	{
		CNTServiceString sParam(pszParam);
		CNTServiceString sParamUpper(sParam);
#ifdef CNTSERVICE_MFC_EXTENSIONS
		sParamUpper.MakeUpper();
		int nParamLength = sParam.GetLength();
#else
		std::transform(sParamUpper.begin(), sParamUpper.end(), sParamUpper.begin(), [](TCHAR c) -> TCHAR { return static_cast<TCHAR>(_totupper(c)); });
		CNTServiceString::size_type nParamLength = sParam.length();
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

		if (_tcsicmp(pszParam, _T("install")) == 0)
			m_nShellCommand = InstallService;
		else if (_tcsicmp(pszParam, _T("silent")) == 0)
			m_bSilent = TRUE;
		else if (_tcsicmp(pszParam, _T("start")) == 0)
			m_nShellCommand = StartTheService;
		else if (_tcsicmp(pszParam, _T("pause")) == 0)
			m_nShellCommand = PauseService;
		else if (_tcsicmp(pszParam, _T("continue")) == 0)
			m_nShellCommand = ContinueService;
		else if (_tcsicmp(pszParam, _T("stop")) == 0)
			m_nShellCommand = StopService;
		else if (_tcsicmp(pszParam, _T("auto")) == 0)
			m_bAutoStart = TRUE;
		else if (_tcsicmp(pszParam, _T("EnableServiceLogonRight")) == 0)
			m_bEnableServiceLogonRight = TRUE;
		else if ((_tcsicmp(pszParam, _T("remove")) == 0) ||
			(_tcsicmp(pszParam, _T("uninstall")) == 0) )
			m_nShellCommand = UninstallService;
		else if ((_tcsicmp(pszParam, _T("debug")) == 0) || (_tcsicmp(pszParam, _T("app")) == 0) || 
			(_tcsicmp(pszParam, _T("application")) == 0) || (_tcsicmp(pszParam, _T("console")) == 0))
			m_nShellCommand = DebugService;
		else if ((_tcsicmp(pszParam, _T("help")) == 0) ||
			(_tcsicmp(pszParam, _T("?")) == 0) )
			m_nShellCommand = ShowServiceHelp;
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("T:")) == 0 && (nParamLength > 2))
			m_dwTimeout = _ttoi(sParam.Mid(2, nParamLength - 2));
#else
		else if (sParamUpper.find(_T("T:")) == 0 && (nParamLength > 2))
			m_dwTimeout = _ttoi(sParam.substr(2, nParamLength - 2).c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("SCL:")) == 0 && (nParamLength > 4))
			m_sServiceCommandLine = sParam.Mid(4, nParamLength - 4);
#else
		else if (sParamUpper.find(_T("SCL:")) == 0 && (nParamLength > 4))
			m_sServiceCommandLine = sParam.substr(4, nParamLength - 4);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("SD:")) == 0 && (nParamLength > 3))
			m_sServiceDescription = sParam.Mid(3, nParamLength - 3);
#else
		else if (sParamUpper.find(_T("SD:")) == 0 && (nParamLength > 3))
			m_sServiceDescription = sParam.substr(3, nParamLength - 3);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("SN:")) == 0 && (nParamLength > 3))
			m_sServiceName = sParam.Mid(3, nParamLength - 3);
#else
		else if (sParamUpper.find(_T("SN:")) == 0 && (nParamLength > 3))
			m_sServiceName = sParam.substr(3, nParamLength - 3);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("SDN:")) == 0 && (nParamLength > 4))
			m_sServiceDisplayName = sParam.Mid(4, nParamLength - 4);
#else
		else if (sParamUpper.find(_T("SDN:")) == 0 && (nParamLength > 4))
			m_sServiceDisplayName = sParam.substr(4, nParamLength - 4);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("P:")) == 0 && (nParamLength > 2))
			m_sPassword = sParam.Mid(2, nParamLength - 2);
#else
		else if (sParamUpper.find(_T("P:")) == 0 && (nParamLength > 2))
			m_sPassword = sParam.substr(2, nParamLength - 2);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef CNTSERVICE_MFC_EXTENSIONS
		else if (sParamUpper.Find(_T("U:")) == 0 && (nParamLength > 2))
			m_sUserName = sParam.Mid(2, nParamLength - 2);
#else
		else if (sParamUpper.find(_T("U:")) == 0 && (nParamLength > 2))
			m_sUserName = sParam.substr(2, nParamLength - 2);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}
	else
	{
		//Currently don't support parsing anything from
		//the command line except flags
	}

	if (bLast)
	{
		//Again the we don't support anything for the
		//last parameter
	}
}