/*
Module : ntservCmdLineInfo.h
Purpose: CTNServiceCommandLineInfo�Ľӿڶ���
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
/////////////////////////////// Macros / Defines //////////////////////////////

#pragma once

#ifndef __NTSERVCMDLINEINFO_H__
#define __NTSERVCMDLINEINFO_H__


////////////////////////////// Includes ///////////////////////////////////////

#include "ntservDefines.h"


////////////////////////////// Classes ////////////////////////////////////////

//CNTServiceCommandLineInfo�������NT�����Ӧ�ó�������ʱ���������С��ýṹ�ǻ���MFC��CCommandLineInfo��Ƶ�
class CNTSERVICE_EXT_CLASS CNTServiceCommandLineInfo
{
public:
	//Constructors / Destructors
	CNTServiceCommandLineInfo();

	//Methods
	virtual void ParseParam(_In_z_ LPCTSTR pszParam, _In_ BOOL bFlag, _In_ BOOL bLast);

	//Data
	enum
	{
		RunAsService,
		StartTheService,
		PauseService,
		ContinueService,
		StopService,
		InstallService,
		UninstallService,
		DebugService,
		ShowServiceHelp
	} m_nShellCommand;

	DWORD            m_dwTimeout;
	BOOL             m_bSilent;
	CNTServiceString m_sServiceCommandLine;
	CNTServiceString m_sServiceName;
	CNTServiceString m_sServiceDisplayName;
	CNTServiceString m_sServiceDescription;
	CNTServiceString m_sUserName;
	CNTServiceString m_sPassword;
	BOOL             m_bAutoStart;
	BOOL             m_bEnableServiceLogonRight;
};

#endif //#ifndef __NTSERVCMDLINEINFO_H__