/*
Module : ntservEventLogSource.cpp
Purpose: ʵ��CNTEventLogSource�ӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
///////////////////////////////// Includes ////////////////////////////////////

#include "stdafx.h"
#include "ntservEventLogSource.h"
#include "ntserv_msg.h"


///////////////////////////////// Macros //////////////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Includes ////////////////////////////////////

CNTEventLogSource::CNTEventLogSource() : m_hEventSource(nullptr),
	m_sLogName(_T("Application"))
{
}

CNTEventLogSource::CNTEventLogSource(_In_opt_z_ LPCTSTR pUNCServerName, _In_opt_z_ LPCTSTR pSourceName, _In_opt_z_ LPCTSTR pLogName) : m_hEventSource(nullptr),
	m_sServerName((pUNCServerName == nullptr) ? _T("") : pUNCServerName),
	m_sSourceName((pSourceName == nullptr) ? _T("") : pSourceName),
	m_sLogName((pLogName == nullptr) ? _T("") : pLogName)

{
}

CNTEventLogSource::CNTEventLogSource(_In_opt_z_ LPCTSTR pUNCServerName, _In_opt_z_ LPCTSTR pSourceName) : m_hEventSource(nullptr),
	m_sServerName((pUNCServerName == nullptr) ? _T("") : pUNCServerName),
	m_sSourceName((pSourceName == nullptr) ? _T("") : pSourceName),
	m_sLogName(_T("Application"))
{
}

CNTEventLogSource::~CNTEventLogSource()
{
	Deregister();
}

void CNTEventLogSource::SetServerName(_In_opt_z_ LPCTSTR pszServerName) 
{ 
	m_sServerName = (pszServerName == nullptr) ? _T("") : pszServerName; 
}

void CNTEventLogSource::SetSourceName(_In_opt_z_ LPCTSTR pszSourceName) 
{ 
	m_sSourceName = (pszSourceName == nullptr) ? _T("") : pszSourceName; 
}

void CNTEventLogSource::SetLogName(_In_opt_z_ LPCTSTR pszLogName) 
{ 
	m_sLogName = (pszLogName == nullptr) ? _T("") : pszLogName;
}

CNTEventLogSource::operator HANDLE() const
{
	return m_hEventSource;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Attach(_In_opt_ HANDLE hEventSource)
{
	if (m_hEventSource != hEventSource)
		Deregister();

	m_hEventSource = hEventSource;
	return TRUE;
}

HANDLE CNTEventLogSource::Detach()
{
	HANDLE hReturn = m_hEventSource;
	m_hEventSource = nullptr;
	return hReturn;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Register(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pSourceName)
{
	Deregister();
	m_hEventSource = RegisterEventSource(pUNCServerName, pSourceName);
	return (m_hEventSource != nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ WORD wCategory, _In_ DWORD dwEventID, _In_opt_ PSID pUserSid,
	_In_ WORD wNumStrings, _In_ DWORD dwDataSize, _In_reads_opt_(wNumStrings) LPCTSTR* pStrings, _In_reads_bytes_opt_(dwDataSize) LPVOID pRawData)
{
	ATL::CComCritSecLock<ATL::CComAutoCriticalSection> sl(m_csReport, true);

	ATLASSERT(m_hEventSource == nullptr);
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (!Register(m_sServerName, m_sSourceName))
#else
	if (!Register(m_sServerName.c_str(), m_sSourceName.c_str()))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		return FALSE;
	ATLASSUME(m_hEventSource != nullptr);

	//Call the SDK version of the function
	BOOL bSuccess = ReportEvent(m_hEventSource, wType,	wCategory, dwEventID, pUserSid, wNumStrings, dwDataSize, pStrings, pRawData);
	Deregister();  

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID)
{
	return Report(wType, 0, dwEventID, nullptr, 0, 0, nullptr, nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_opt_z_ LPCTSTR pszString)
{
	return Report(wType, CNTS_MSG_SERVICE_FULLSTRING, pszString);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString)
{
	//Validate our parameters
	ATLASSERT(pszString != nullptr);

	return Report(wType, 0, dwEventID, nullptr, 1, 0, &pszString, nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2)
{
	//Validate our parameters
	ATLASSERT(pszString1 != nullptr);
	ATLASSERT(pszString2 != nullptr);

	LPCTSTR pStrings[2];
	pStrings[0] = pszString1;
	pStrings[1] = pszString2;
	return Report(wType, 0, dwEventID, nullptr, 2, 0, pStrings, nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2, _In_ DWORD dwCode, _In_ BOOL bReportAsHex)
{
	//Validate our parameters
	ATLASSERT(pszString1 != nullptr);
	ATLASSERT(pszString2 != nullptr);

	LPCTSTR pStrings[3];
	pStrings[0] = pszString1;
	pStrings[1] = pszString2;
	TCHAR szError[32];
	if (bReportAsHex)
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%08X"), dwCode);
	else
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%u"), dwCode);
	pStrings[2] = szError;
	return Report(wType, 0, dwEventID, nullptr, 3, 0, pStrings, nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString1, _In_opt_z_ LPCTSTR pszString2, _In_opt_z_ LPCTSTR pszString3)
{
	//Validate our parameters
	ATLASSERT(pszString1 != nullptr);
	ATLASSERT(pszString2 != nullptr);
	ATLASSERT(pszString3 != nullptr);

	LPCTSTR pStrings[3];
	pStrings[0] = pszString1;
	pStrings[1] = pszString2;
	pStrings[2] = pszString3;
	return Report(wType, 0, dwEventID, nullptr, 3, 0, pStrings, nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_ DWORD dwCode, _In_ BOOL bReportAsHex)
{
	TCHAR szError[32];
	if (bReportAsHex)
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%08X"), dwCode);
	else
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%u"), dwCode);
	return Report(wType, dwEventID, szError);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Report(_In_ WORD wType, _In_ DWORD dwEventID, _In_opt_z_ LPCTSTR pszString, _In_ DWORD dwCode, _In_ BOOL bReportAsHex)
{
	TCHAR szError[32];
	if (bReportAsHex)
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%08X"), dwCode);
	else
		_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%u"), dwCode);
	return Report(wType, dwEventID, pszString, szError);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Deregister()
{
	BOOL bSuccess = TRUE;
	if (m_hEventSource != nullptr)
	{
		bSuccess = DeregisterEventSource(m_hEventSource);
		m_hEventSource = nullptr;
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Install(_In_opt_z_ LPCTSTR pszSourceName, _In_opt_z_ LPCTSTR pszEventMessageFile, _In_opt_z_ LPCTSTR pszEventCategoryMessageFile, _In_opt_z_ LPCTSTR pszEventParameterMessageFile, _In_ DWORD dwTypesSupported, _In_ DWORD dwCategoryCount)
{
	//Just delegate the work to the other version of "Install"
	return Install(_T("Application"), pszSourceName, pszEventMessageFile, pszEventCategoryMessageFile, pszEventParameterMessageFile, dwTypesSupported, dwCategoryCount);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Install(_In_opt_z_ LPCTSTR pszLogName, _In_opt_z_ LPCTSTR pszSourceName, _In_opt_z_ LPCTSTR pszEventMessageFile, _In_opt_z_ LPCTSTR pszEventCategoryMessageFile, _In_opt_z_ LPCTSTR pszEventParameterMessageFile, _In_ DWORD dwTypesSupported, _In_ DWORD dwCategoryCount)
{
	//Validate our parameters
	ATLASSUME(pszLogName != nullptr);
	ATLASSERT(_tcslen(pszLogName));
	ATLASSUME(pszSourceName != nullptr);
	ATLASSERT(_tcslen(pszSourceName));
	ATLASSUME(pszEventMessageFile != nullptr);

	//What will be the return value from this function, assume the worst
	BOOL bSuccess = FALSE;

	//Make the necessary updates to the registry
	TCHAR szKey[4096];
	_stprintf_s(szKey, sizeof(szKey)/sizeof(TCHAR), _T("SYSTEM\\CurrentControlSet\\Services\\EventLog\\%s"), pszLogName);
	ATL::CRegKey appKey;
	if (appKey.Create(HKEY_LOCAL_MACHINE, szKey) == ERROR_SUCCESS)
	{
		ATL::CRegKey sourceKey;
		if (sourceKey.Create(appKey, pszSourceName, REG_NONE, REG_OPTION_NON_VOLATILE, KEY_WRITE | KEY_READ, nullptr) == ERROR_SUCCESS)
		{
			//Write the EventMessageFile string value
			bSuccess = sourceKey.SetStringValue(_T("EventMessageFile"), pszEventMessageFile) == ERROR_SUCCESS;

			//Write the TypesSupported value
			bSuccess = bSuccess && sourceKey.SetDWORDValue(_T("TypesSupported"), dwTypesSupported) == ERROR_SUCCESS;

			//Write the CategoryCount value if required
			if (dwCategoryCount && bSuccess)
				bSuccess = sourceKey.SetDWORDValue(_T("CategoryCount"), dwCategoryCount) == ERROR_SUCCESS;

			//Write the CategoryMessageFile string if required
			if (pszEventCategoryMessageFile && _tcslen(pszEventCategoryMessageFile) && bSuccess)
				bSuccess = sourceKey.SetStringValue(_T("CategoryMessageFile"), pszEventCategoryMessageFile) == ERROR_SUCCESS;

			//Write the ParameterMessageFile string if required
			if (pszEventParameterMessageFile && _tcslen(pszEventParameterMessageFile) && bSuccess)
				bSuccess = sourceKey.SetStringValue(_T("ParameterMessageFile"), pszEventParameterMessageFile) == ERROR_SUCCESS;

			//Update the sources registry key so that the event viewer can filter on the events which we write to the event log
			if (bSuccess)
			{
				CNTServiceStringArray sources;
				if (GetStringArrayFromRegistry(appKey, _T("Sources"), sources))
				{
					//If our name is not in the array then add it
					BOOL bFoundMyself = FALSE;
#ifdef CNTSERVICE_MFC_EXTENSIONS
					for (int i=0; i<sources.GetSize() && !bFoundMyself; i++)
						bFoundMyself = (sources.GetAt(i) == pszSourceName);
#else
					bFoundMyself = (std::find(sources.begin(), sources.end(), pszSourceName) != sources.end());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
					if (!bFoundMyself)
					{
#ifdef CNTSERVICE_MFC_EXTENSIONS
						sources.Add(pszSourceName);
#else
						sources.push_back(pszSourceName);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
						SetStringArrayIntoRegistry(appKey, _T("Sources"), sources);
					}
				}
			}
		}
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Uninstall(_In_opt_z_ LPCTSTR pSourceName)
{
	//Just delegate the work to the other version of "Install"
	return Uninstall(_T("Application"), pSourceName);
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::Uninstall(_In_opt_z_ LPCTSTR pszLogName, _In_opt_z_ LPCTSTR pszSourceName)
{
	//Validate our parameters
	ATLASSUME(pszLogName != nullptr);
	ATLASSERT(_tcslen(pszLogName));
	ATLASSUME(pszSourceName != nullptr);
	ATLASSERT(_tcslen(pszSourceName));

	//Remove the settings from the registry
	TCHAR szSubKey[4096];
	_stprintf_s(szSubKey, sizeof(szSubKey)/sizeof(TCHAR), _T("SYSTEM\\CurrentControlSet\\Services\\EventLog\\%s\\%s"), pszLogName, pszSourceName);
	LSTATUS nSuccess = RegDeleteKey(HKEY_LOCAL_MACHINE, szSubKey);
	if (nSuccess != ERROR_SUCCESS) //If we cannot delete this registry key, then abort this function before we go any further
	{
		SetLastError(nSuccess); //Make the last error value available to our callers 
		return FALSE;
	}

	//Remove ourself from the "Sources" registry key
	_stprintf_s(szSubKey, sizeof(szSubKey)/sizeof(TCHAR), _T("SYSTEM\\CurrentControlSet\\Services\\EventLog\\%s"), pszLogName);
	ATL::CRegKey appKey;
	if (appKey.Open(HKEY_LOCAL_MACHINE, szSubKey, KEY_WRITE | KEY_READ) == ERROR_SUCCESS)
	{
		CNTServiceStringArray sources;
		if (GetStringArrayFromRegistry(appKey, _T("Sources"), sources))
		{
			//If our name is in the array then remove it
			BOOL bFoundMyself = FALSE;

#ifdef CNTSERVICE_MFC_EXTENSIONS
			for (int i=0; i<sources.GetSize() && !bFoundMyself; i++)
			{
				bFoundMyself = (sources.GetAt(i) == pszSourceName);
				if (bFoundMyself)
				{
					sources.RemoveAt(i);
				}
			}
#else
			CNTServiceStringArray::iterator iterFind = std::find(sources.begin(), sources.end(), pszSourceName);
			bFoundMyself = (iterFind != sources.end());
			if (bFoundMyself)
				sources.erase(iterFind);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

			if (bFoundMyself)
				SetStringArrayIntoRegistry(appKey, _T("Sources"), sources);
		}
	}

	return TRUE;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::GetStringArrayFromRegistry(_In_ ATL::CRegKey& key, _In_opt_z_ LPCTSTR pszEntry, _Out_ CNTServiceStringArray& array, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszEntry != nullptr);

	//What will be the return value from this function, assume the worst
	BOOL bSuccess = FALSE;

	//Initialize the output parameters to default values
	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	array.RemoveAll();
#else
	array.clear();
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	DWORD dwType = 0;
	ULONG nBytes = 0;
	LSTATUS lResult = key.QueryValue(pszEntry, &dwType, nullptr, &nBytes);
	if (lResult == ERROR_SUCCESS)
	{
		//Allocate some memory for the API
		ATL::CHeapPtr<TCHAR> pBuffer;
		ULONG nChars = nBytes / sizeof(TCHAR);
		if (nChars < 2) //Ensure we can handle an empty MULTI_SZ string
			nChars = 2;
		if (!pBuffer.Allocate(nChars))
		{
			SetLastError(ERROR_OUTOFMEMORY);
			if (pLastError != nullptr)
				*pLastError = ERROR_OUTOFMEMORY;
			return FALSE;
		}

		lResult = key.QueryMultiStringValue(pszEntry, pBuffer, &nChars);
		if (lResult == ERROR_SUCCESS)
		{
			LPTSTR pszStrings = pBuffer.m_pData;
			while (pszStrings[0] != 0)
			{
#ifdef CNTSERVICE_MFC_EXTENSIONS
				array.Add(pszStrings);
#else
				array.push_back(pszStrings);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				pszStrings += (_tcslen(pszStrings) + 1);
			}

			bSuccess = TRUE;
		}
		else
		{
			if (pLastError != nullptr)
				*pLastError = lResult;
		}
	}
	else
	{
		if (pLastError != nullptr)
			*pLastError = lResult;
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLogSource::SetStringArrayIntoRegistry(_In_ ATL::CRegKey& key, _In_opt_z_ LPCTSTR pszEntry, _In_ const CNTServiceStringArray& array, _Inout_opt_ DWORD* pLastError)
{   
	//Validate our input parameters
	ATLASSERT(pszEntry != nullptr);

	//Initialize the output parameter to default value
	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	//Work out the size of the buffer we will need
#ifdef CNTSERVICE_MFC_EXTENSIONS
	int nSize = 0;
	INT_PTR nStrings = array.GetSize();
	for (INT_PTR i=0; i<nStrings; i++)
		nSize += array.GetAt(i).GetLength() + 1; //1 extra for each null terminator
#else
	CNTServiceStringArray::size_type nSize = 0;
	CNTServiceStringArray::size_type nStrings = array.size();
	for (CNTServiceStringArray::size_type i=0; i<nStrings; i++)
		nSize += array[i].length() + 1; //1 extra for each null terminator
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//Need one second null for the double null at the end
	nSize++;

	//Allocate some memory for the API
	ATL::CHeapPtr<TCHAR> pBuffer;
	if (!pBuffer.Allocate(nSize))
	{
		SetLastError(ERROR_OUTOFMEMORY);
		if (pLastError != nullptr)
			*pLastError = ERROR_OUTOFMEMORY;
		return FALSE;
	}

	//Now copy the strings into the buffer
	LPTSTR pszString = pBuffer.m_pData;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	int nCurOffset = 0;
	for (INT_PTR i=0; i<nStrings; i++)
#else
	CNTServiceStringArray::size_type nCurOffset = 0;
	for (CNTServiceStringArray::size_type i=0; i<nStrings; i++)
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		const CNTServiceString& sText = array[i];
#ifdef CNTSERVICE_MFC_EXTENSIONS
		int nCurrentStringLength = sText.GetLength();
		_tcscpy_s(&pszString[nCurOffset], nCurrentStringLength+1, sText);
#else
		CNTServiceString::size_type nCurrentStringLength = sText.length();
		_tcscpy_s(&pszString[nCurOffset], nCurrentStringLength+1, sText.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		nCurOffset += (nCurrentStringLength + 1);
	}
	//Don't forgot to doubly null terminate
	pszString[nCurOffset] = _T('\0');

	//Finally write it into the registry
	LSTATUS lResult = key.SetMultiStringValue(pszEntry, pBuffer);
	BOOL bSuccess = (lResult == ERROR_SUCCESS);
	if (!bSuccess && (pLastError != nullptr))
		*pLastError = lResult;

	return bSuccess;
}