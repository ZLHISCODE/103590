/*
Module : ntserv.cpp
Purpose: ʵ��Windows����Ŀ����ӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/

///////////////////////////////// Includes ////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
//#include <Tlhelp32.h>
//
//#ifndef _WINSVC_
//#pragma message("To avoid this message, please put winsvc.h in your pre compiled header (normally stdafx.h)")
//#include <winsvc.h>
//#endif //#ifndef _WINSVC_
//
//#ifndef _NTSECAPI_
//#pragma message("To avoid this message, please put ntsecapi.h in your pre compiled header (normally stdafx.h)")
//#include <ntsecapi.h>
//#endif //#ifndef _NTSECAPI_
//
//#ifndef CNTSERVICE_MFC_EXTENSIONS
//#ifndef _ALGORITHM_
//#pragma message("To avoid this message, please put algorithm in your pre compiled header (normally stdafx.h)")
//#include <algorithm>
//#endif //#ifndef _ALGORITHM_
//#endif //#ifndef CNTSERVICE_MFC_EXTENSIONS
#include <userenv.h>
#pragma comment(lib,"userenv.lib")
#include <Psapi.h>
#pragma comment (lib,"Psapi.lib")
#include <Tlhelp32.h>

#include "ntserv.h"
#include "ntserv_msg.h" //If you get an error about this missing header file, then please make sure you build the TestSrvMsg project first


///////////////////////////////// Macros /Defines /////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

CNTService* CNTService::sm_pService = nullptr;


//////////////////////////////// Implementation ///////////////////////////////

CNTServiceTerminateException::CNTServiceTerminateException(_In_ DWORD dwWin32ExitCode, _In_ DWORD dwServiceSpecificExitCode) : m_dwWin32ExitCode(dwWin32ExitCode), 
	m_dwServiceSpecificExitCode(dwServiceSpecificExitCode) 
{
}

CNTService::CNTService()
{
	InitializeFunctionPointers();
	Initialize(nullptr, nullptr, SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_STOP, nullptr); //The dwControlsAccepted value we pass to Initialize doesn't really matter
	//since client code can cusomize this by calling SetControlsAccepted or
	//implementing a derived version of Initialize
}

CNTService::CNTService(_In_z_ LPCTSTR pszServiceName, _In_z_ LPCTSTR pszDisplayName, _In_ DWORD dwControlsAccepted, _In_opt_z_ LPCTSTR pszDescription)
{
	//Validate our parameters
	ATLASSERT(pszServiceName != nullptr);
	ATLASSERT(pszDisplayName != nullptr);

	InitializeFunctionPointers();
	Initialize(pszServiceName, pszDisplayName, dwControlsAccepted, pszDescription);
}

void CNTService::InitializeFunctionPointers()
{
	m_pfnQueryServiceDynamicInformation = nullptr;
	m_hAdvapi32 = GetModuleHandle(_T("ADVAPI32.DLL"));
	if (m_hAdvapi32 != nullptr)
	{
		m_pfnQueryServiceDynamicInformation = reinterpret_cast<LPQUERYSERVICEDYNAMICINFORMATION>(GetProcAddress(m_hAdvapi32, "QueryServiceDynamicInformation"));
	}
	m_hWtsapi32=LoadLibrary(_T("Wtsapi32.dll"));
	m_hKernel32=LoadLibrary(_T("Kernel32.dll"));
	if (m_hWtsapi32 != nullptr)
	{
#ifdef _UNICODE
		m_pfnWTSEnumerateSessionsEx = reinterpret_cast<LPMYWTSENUMERATESESSIONSEX>(GetProcAddress(m_hWtsapi32, "WTSEnumerateSessionsExW"));
		if(m_pfnWTSEnumerateSessionsEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateSessionsExW.Adress Is null")); 
		m_pfnWTSFreeMemoryEx = reinterpret_cast<LPMYWTSFREEMEMORYEX>(GetProcAddress(m_hWtsapi32, "WTSFreeMemoryExW"));
		if(m_pfnWTSFreeMemoryEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSFreeMemoryExW.Adress Is null")); 
		m_pfnWTSEnumerateProcessesEx = reinterpret_cast<LPMYWTSENUMERATEPROCESSESEX>(GetProcAddress(m_hWtsapi32, "WTSEnumerateProcessesExW"));
		if(m_pfnWTSFreeMemoryEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateProcessesExW.Adress Is null"));
		m_pfnWTSEnumerateSessions = reinterpret_cast<LPMYWTSENUMERATESESSIONS>(GetProcAddress(m_hWtsapi32, "WTSEnumerateSessionsW"));
		if(m_pfnWTSFreeMemoryEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateSessionsW.Adress Is null"));
		m_pfnWTSQuerySessionInformation = reinterpret_cast<LPMYWTSQUERYSESSIONINFORMATION>(GetProcAddress(m_hWtsapi32, "WTSQuerySessionInformationW"));
		if(m_pfnWTSFreeMemoryEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSQuerySessionInformationW.Adress Is null"));
#else
		m_pfnWTSEnumerateSessionsEx = reinterpret_cast<LPMYWTSENUMERATESESSIONSEX>(GetProcAddress(m_hWtsapi32, "WTSEnumerateSessionsExA"));
		if(m_pfnWTSEnumerateSessionsEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateSessionsExA.Adress Is null")); 
		m_pfnWTSFreeMemoryEx = reinterpret_cast<LPMYWTSFREEMEMORYEX>(GetProcAddress(m_hWtsapi32, "WTSFreeMemoryExA"));
		if(m_pfnWTSFreeMemoryEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSFreeMemoryExA.Adress Is null")); 
		m_pfnWTSEnumerateProcessesEx = reinterpret_cast<LPMYWTSENUMERATEPROCESSESEX>(GetProcAddress(m_hWtsapi32, "WTSEnumerateProcessesExA"));
		if(m_pfnWTSEnumerateProcessesEx== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateProcessesExA.Adress Is null"));
		m_pfnWTSEnumerateSessions = reinterpret_cast<LPMYWTSENUMERATESESSIONS>(GetProcAddress(m_hWtsapi32, "WTSEnumerateSessionsA"));
		if(m_pfnWTSEnumerateSessions== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSEnumerateSessionsA.Adress Is null"));
		m_pfnWTSQuerySessionInformation = reinterpret_cast<LPMYWTSQUERYSESSIONINFORMATION>(GetProcAddress(m_hWtsapi32, "WTSQuerySessionInformationA"));
		if(m_pfnWTSQuerySessionInformation== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSQuerySessionInformationA.Adress Is null"));
#endif //#ifdef _UNICODE
		m_pfnWTSFreeMemory = reinterpret_cast<LPMYWTSFREEMEMORY>(GetProcAddress(m_hWtsapi32, "WTSFreeMemory"));
		if(m_pfnWTSFreeMemory== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSFreeMemory.Adress Is null"));
		m_pfnWTSTerminateProcess = reinterpret_cast<LPMYWTSTERMINATEPROCESS>(GetProcAddress(m_hWtsapi32, "WTSTerminateProcess"));
		if(m_pfnWTSTerminateProcess== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSTerminateProcess.Adress Is null"));
	}else
	{
		LogEvent(_T("InitializeFunctionPointers:Wtsapi32.Adress Is null")); 
	}
	if (m_hKernel32 != nullptr)
	{
		m_pfnWTSGetActiveConsoleSessionId = reinterpret_cast<LPMYWTSGETACTIVECONSOLESESSIONID>(GetProcAddress(m_hKernel32, "WTSGetActiveConsoleSessionId"));
		if(m_pfnWTSGetActiveConsoleSessionId== nullptr)
			LogEvent(_T("InitializeFunctionPointers:WTSGetActiveConsoleSessionId.Adress Is null"));
		m_pfnProcessIdToSessionId = reinterpret_cast<LPMYPROCESSIDTOSESSIONID>(GetProcAddress(m_hKernel32, "ProcessIdToSessionId"));
		if(m_pfnProcessIdToSessionId== nullptr)
			LogEvent(_T("InitializeFunctionPointers:ProcessIdToSessionId.Adress Is null"));
	}
	else
	{
		LogEvent(_T("InitializeFunctionPointers:Kernel32.Adress Is null")); 
	}
}

void CNTService::SetServiceName(_In_opt_z_ LPCTSTR pszServiceName) 
{
	//Change both the master service name and the active/current instance service name
	m_sServiceName = (pszServiceName == nullptr) ? _T("") : pszServiceName;
	m_sMasterServiceName = (pszServiceName == nullptr) ? _T("") : pszServiceName;
}

void CNTService::SetInstanceServiceName(_In_opt_z_ LPCTSTR pszServiceName) 
{ 
	m_sServiceName = (pszServiceName == nullptr) ? _T("") : pszServiceName;
}

void CNTService::SetMasterServiceName(_In_opt_z_ LPCTSTR pszServiceName) 
{ 
	m_sMasterServiceName = (pszServiceName == nullptr) ? _T("") : pszServiceName;
}

void CNTService::SetDisplayName(_In_opt_z_ LPCTSTR pszDisplayName)
{ 
	//Change both the master service name and the active/current instance display name
	m_sDisplayName = (pszDisplayName == nullptr) ? _T("") : pszDisplayName;
	m_sMasterDisplayName = (pszDisplayName == nullptr) ? _T("") : pszDisplayName;
}

void CNTService::SetInstanceDisplayName(_In_opt_z_ LPCTSTR pszDisplayName) 
{ 
	m_sDisplayName = (pszDisplayName == nullptr) ? _T("") : pszDisplayName;
}

void CNTService::SetMasterDisplayName(_In_opt_z_ LPCTSTR pszDisplayName) 
{ 
	m_sMasterDisplayName = (pszDisplayName == nullptr) ? _T("") : pszDisplayName;
}

void CNTService::SetDescription(_In_opt_z_ LPCTSTR pszDescription)
{ 
	//Change both the master description and the active/current instance description
	m_sDescription = (pszDescription == nullptr) ? _T("") : pszDescription;
	m_sMasterDescription = (pszDescription == nullptr) ? _T("") : pszDescription;
}

void CNTService::SetInstanceDescription(_In_opt_z_ LPCTSTR pszDescription) 
{ 
	m_sDescription = (pszDescription == nullptr) ? _T("") : pszDescription;
}

void CNTService::SetMasterDescription(_In_opt_z_ LPCTSTR pszDescription) 
{ 
	m_sMasterDescription = (pszDescription == nullptr) ? _T("") : pszDescription;
}

void CNTService::Initialize(_In_opt_z_ LPCTSTR pszServiceName, _In_opt_z_ LPCTSTR pszDisplayName, _In_ DWORD dwControlsAccepted, _In_opt_z_ LPCTSTR pszDescription)
{
	SetServiceName(pszServiceName);
	SetDisplayName(pszDisplayName);
	SetDescription(pszDescription);

	m_hStatus                 = 0;
	m_dwCheckPoint            = 0;
	m_dwWaitHint              = 0;
	m_dwRequestedControl      = 0;
	m_dwCurrentState          = SERVICE_STOPPED;
	m_dwControlsAccepted      = dwControlsAccepted;
	m_dwServiceType           = SERVICE_WIN32_OWN_PROCESS;
	m_dwStartType             = SERVICE_DEMAND_START;
	m_dwErrorControl          = SERVICE_ERROR_IGNORE;
	m_bEventLogSource         = TRUE;
#ifdef _CONSOLE
	m_bUseConsole             = TRUE;
#else
	m_bUseConsole             = FALSE;
#endif //#ifdef _CONSOLE
	m_UILoggingDetail         = UI_StringAndErrorCodeAndErrorDescription;
	m_ELLoggingDetail         = EL_ErrorCodeAndErrorDescription;
	m_bProfileWriteFlush      = TRUE; //Default to the slower but safer form of registry writing
	m_bAllowCommandLine       = FALSE;
	m_bAllowNameChange        = FALSE; 
	m_bAllowDescriptionChange = FALSE;
	m_bAllowDisplayNameChange = FALSE;
	m_bDelayedAutoStart       = FALSE;
	m_dwServiceSidType        = SERVICE_SID_TYPE_NONE; //Use the old style sid type by default
	m_dwPreshutdownTimeout    = 0;
	m_dwEventCategoryCount    = 0;
	m_dwEventTypesSupported   = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | EVENTLOG_INFORMATION_TYPE;
	m_dwLaunchProtected       = SERVICE_LAUNCH_PROTECTED_NONE;

	//By default use a event log source name the same as the display name. You can of course
	//customize this by calling m_EventLogSource.SetSourceName in your derived class at the 
	//appropriate time
#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_EventLogSource.SetSourceName(m_sDisplayName);
#else
	m_EventLogSource.SetSourceName(m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//Copy the address of the current object so we can access it from the static member callback functions.
	//WARNING: This limits the application to only one CNTService object. i.e. the CNTService class framework only supports 
	//1 service per process i.e. you cannot use the flag SERVICE_WIN32_SHARE_PROCESS
	sm_pService = this; //hive away the "this" pointer;
}

_Return_type_success_(return != 0) BOOL CNTService::_ReportStatus(_In_ DWORD dwCurrentState, _In_ DWORD dwCheckPoint, _In_ DWORD dwWaitHint, _In_ DWORD dwControlsAccepted,
	_In_ DWORD dwWin32ExitCode, _In_ DWORD dwServiceSpecificExitCode)
{
	//synchronise access to the variables
	ATL::CComCritSecLock<ATL::CComAutoCriticalSection> sl(m_CritSect, true); 

	m_dwCurrentState = dwCurrentState;
	SERVICE_STATUS ServiceStatus;
	ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;

	//The only stat that can set exit codes is STOPPED
	//Fix if necessary, just in case not properly set
	if (dwCurrentState != SERVICE_STOPPED)
	{
		dwWin32ExitCode = S_OK;
		dwServiceSpecificExitCode = 0;
	}

	//Only pending states can set checkpoints and wait hints
	//and pending states *must* set wait hints
	if (dwCurrentState == SERVICE_STOPPED || dwCurrentState == SERVICE_RUNNING || dwCurrentState == SERVICE_PAUSED)
	{
		//Requires hint and checkpoint == 0
		dwWaitHint = 0;
		dwCheckPoint = 0;
	}
	else
	{
		//You need to set wait hints and checkpoints
		if (dwWaitHint == STATE_NO_CHANGE)
			ATLASSERT(m_dwWaitHint);
		else
			ATLASSERT(dwWaitHint != 0);
		if (dwCheckPoint == STATE_NO_CHANGE)
			ATLASSERT(m_dwCheckPoint);
		else
			ATLASSERT(dwCheckPoint != 0);
	}

	if (dwCheckPoint != STATE_NO_CHANGE)
		m_dwCheckPoint = dwCheckPoint;
	if (dwWaitHint != STATE_NO_CHANGE)
		m_dwWaitHint = dwWaitHint;
	if (dwControlsAccepted != STATE_NO_CHANGE)
		m_dwControlsAccepted = dwControlsAccepted;

	//Disable control requests while the service is in a pending state
	if (dwCurrentState == SERVICE_START_PENDING || dwCurrentState == SERVICE_STOP_PENDING || 
		dwCurrentState == SERVICE_PAUSE_PENDING || dwCurrentState == SERVICE_CONTINUE_PENDING)
		ServiceStatus.dwControlsAccepted = 0;    
	else
		ServiceStatus.dwControlsAccepted = m_dwControlsAccepted;

	ServiceStatus.dwCurrentState = dwCurrentState;
	ServiceStatus.dwWin32ExitCode = dwWin32ExitCode;
	ServiceStatus.dwServiceSpecificExitCode = dwServiceSpecificExitCode;
	ServiceStatus.dwCheckPoint = m_dwCheckPoint;
	ServiceStatus.dwWaitHint = m_dwWaitHint;

	//Release the critical section lock now that we are finished tweaking the member variables
	sl.Unlock();

	//Only report to the SCM if we have a SCM status handle
	BOOL bSuccess = FALSE;
	if (m_hStatus != nullptr)
		bSuccess = SetServiceStatus(m_hStatus, &ServiceStatus);

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTService::ReportStatus(_In_ DWORD dwCurrentState, _In_ DWORD dwCheckPoint, _In_ DWORD dwWaitHint, _In_ DWORD dwControlsAccepted)
{
	ATLASSERT(dwCurrentState != SERVICE_STOPPED); //You should never call ReportStatus (previously ReportStatusToSCM) with the parameter
	//SERVICE_STOPPED

	return _ReportStatus(dwCurrentState, dwCheckPoint, dwWaitHint, dwControlsAccepted);
}

_Return_type_success_(return != 0) BOOL CNTService::ReportStatus()
{
	return ReportStatus(m_dwCurrentState);
}

void CNTService::OnStop()
{
	//Derived classes are required to implement
	//their own code to stop a service, all we do is
	//report that we were succesfully stopped

	//Add an Event log entry to say the service was stopped
	if (m_bEventLogSource)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_STOPPED), m_sDisplayName);
#else
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_STOPPED), m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	ATLASSERT(FALSE);
}

void CNTService::OnPause()
{
	//Add an Event log entry to say the service was stopped
	if (m_bEventLogSource)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_PAUSED), m_sDisplayName);
#else
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_PAUSED), m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	//Derived classes are required to implement
	//their own code to pause a service
	ATLASSERT(FALSE);
}

void CNTService::OnContinue()
{
	//Add an Event log entry to say the service was stopped
	if (m_bEventLogSource)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_CONTINUED), m_sDisplayName);
#else
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_CONTINUED), m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	//Derived classes are required to implement
	//their own code to continue a service
	ATLASSERT(FALSE);
}

void CNTService::OnInterrogate()
{
	//Default implementation returns the current status
	//as stored in m_ServiceStatus
	ReportStatus();
}

void CNTService::OnShutdown()
{
	//Add an Event log entry to say the service was stopped
	if (m_bEventLogSource)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_SHUTDOWN), m_sDisplayName);
#else
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_SHUTDOWN), m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	//Derived classes are required to implement
	//their own code to shutdown a service
	ATLASSERT(FALSE);
}

void CNTService::OnUserDefinedRequest(_In_ DWORD /*dwControl*/)
{
	ATLTRACE(_T("CNTService::OnUserDefinedRequest was called\n"));

	//Default implementation is do nothing
}

void CNTService::OnNetBindAdd()
{
	ATLTRACE(_T("CNTService::OnNetBindAdd was called\n"));

	//Default implementation is do nothing
}

void CNTService::OnNetBindRemove()
{
	ATLTRACE(_T("CNTService::OnNetBindRemove was called\n"));

	//Default implementation is do nothing
}

void CNTService::OnNetBindEnable()
{
	ATLTRACE(_T("CNTService::OnNetBindEnable was called\n"));

	//Default implementation is do nothing
}

void CNTService::OnNetBindDisable()
{
	ATLTRACE(_T("CNTService::OnNetBindDisable was called\n"));

	//Default implementation is do nothing
}

void CNTService::OnParamChange()
{
	ATLTRACE(_T("CNTService::OnParamChange was called\n"));

	//Default implementation is do nothing
}

#ifdef _DEBUG
DWORD CNTService::OnHardwareProfileChange(_In_ DWORD dwEventType, _In_opt_ LPVOID /*lpEventData*/)
#else
DWORD CNTService::OnHardwareProfileChange(_In_ DWORD /*dwEventType*/, _In_opt_ LPVOID /*lpEventData*/)
#endif //#ifdef _DEBUG
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnHardwareProfileChange was called, EventType:%08X\n"), dwEventType);
#endif //#ifdef _DEBUG

	//Default implementation just returns NO_ERROR which grants the request
	return NO_ERROR;
}

#ifdef _DEBUG
DWORD CNTService::OnPowerEvent(_In_ DWORD dwEventType, _In_opt_ LPVOID /*lpEventData*/)
#else
DWORD CNTService::OnPowerEvent(_In_ DWORD /*dwEventType*/, _In_opt_ LPVOID /*lpEventData*/)
#endif //#ifdef _DEBUG
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnPowerEvent was called, EventType:%08X\n"), dwEventType);
#endif //#ifdef _DEBUG

	//Default implementation just returns NO_ERROR which grants the request
	return NO_ERROR;
}

#ifdef _DEBUG
DWORD CNTService::OnDeviceEvent(_In_ DWORD dwEventType, _In_opt_ LPVOID /*lpEventData*/)
#else
DWORD CNTService::OnDeviceEvent(_In_ DWORD /*dwEventType*/, _In_opt_ LPVOID /*lpEventData*/)
#endif //#ifdef _DEBUG
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnDeviceEvent was called, EventType:%08X\n"), dwEventType);
#endif //#ifdef _DEBUG

	//Default implementation just returns NO_ERROR which grants the request
	return NO_ERROR;
}

#ifdef _DEBUG
void CNTService::OnSessionChange(_In_ DWORD dwEventType, _In_opt_ WTSSESSION_NOTIFICATION* /*lpEventData*/)
#else
void CNTService::OnSessionChange(_In_ DWORD /*dwEventType*/, _In_opt_ WTSSESSION_NOTIFICATION* /*lpEventData*/)
#endif //#ifdef _DEBUG
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnSessionChange was called, EventType:%08X\n"), dwEventType);
#endif //#ifdef _DEBUG
}

void CNTService::OnPreShutdown()
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnPreShutdown was called\n"));
#endif //#ifdef _DEBUG
}

void CNTService::OnTimeChange(_In_opt_ SERVICE_TIMECHANGE_INFO* /*lpEventData*/)
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnTimeChange was called\n"));
#endif //#ifdef _DEBUG
}

void CNTService::OnTriggerEvent()
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnTriggerEvent was called\n"));
#endif //#ifdef _DEBUG
}

void CNTService::OnLowResources()
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnLowResources was called\n"));
#endif //#ifdef _DEBUG
}

void CNTService::OnSystemLowResources()
{
#ifdef _DEBUG
	ATLTRACE(_T("CNTService::OnSystemLowResources was called\n"));
#endif //#ifdef _DEBUG
}

DWORD WINAPI CNTService::ServiceCtrlHandler(_In_ DWORD dwControl, _In_ DWORD dwEventType, _In_opt_ LPVOID pEventData)
{
	//Need to keep an additional control request of the same type from coming in when your're already handling it
	if (dwControl == m_dwRequestedControl)
		return ERROR_CALL_NOT_IMPLEMENTED;

	//Just switch on the control code sent to us and call the relevant virtual function
	DWORD dwRet = NO_ERROR;
	switch (dwControl)
	{
	case SERVICE_CONTROL_STOP: 
		{
			OnStop();
			break;
		}
	case SERVICE_CONTROL_PAUSE:
		{
			OnPause();
			break;
		}
	case SERVICE_CONTROL_CONTINUE:
		{
			OnContinue();
			break;
		}
	case SERVICE_CONTROL_INTERROGATE:
		{
			OnInterrogate();
			break;
		}
	case SERVICE_CONTROL_SHUTDOWN:
		{
			OnShutdown();
			break;
		}
	case SERVICE_CONTROL_PARAMCHANGE: 
		{
			OnParamChange();
			break;
		}
	case SERVICE_CONTROL_NETBINDADD: 
		{
			OnNetBindAdd();
			break;
		}
	case SERVICE_CONTROL_NETBINDREMOVE:
		{
			OnNetBindRemove();
			break;
		}
	case SERVICE_CONTROL_NETBINDENABLE:
		{
			OnNetBindEnable();
			break;
		}
	case SERVICE_CONTROL_NETBINDDISABLE:
		{
			OnNetBindDisable();
			break;
		}
	case SERVICE_CONTROL_DEVICEEVENT:
		{
			dwRet = OnDeviceEvent(dwEventType, pEventData);
			break;
		}
	case SERVICE_CONTROL_HARDWAREPROFILECHANGE:
		{
			dwRet = OnHardwareProfileChange(dwEventType, pEventData);
			break;
		}
	case SERVICE_CONTROL_POWEREVENT:
		{
			dwRet = OnPowerEvent(dwEventType, pEventData);
			break;
		}
	case SERVICE_CONTROL_SESSIONCHANGE:
		{
			OnSessionChange(dwEventType, static_cast<WTSSESSION_NOTIFICATION*>(pEventData));
			break;
		}
	case SERVICE_CONTROL_PRESHUTDOWN:
		{
			OnPreShutdown();
			break;
		}
	case SERVICE_CONTROL_TIMECHANGE:
		{
			OnTimeChange(static_cast<SERVICE_TIMECHANGE_INFO*>(pEventData));
			break;
		}
	case SERVICE_CONTROL_TRIGGEREVENT:
		{
			OnTriggerEvent();
			break;
		}
	case SERVICE_CONTROL_LOWRESOURCES:
		{
			OnLowResources();
			break;
		}
	case SERVICE_CONTROL_SYSTEMLOWRESOURCES:
		{
			OnSystemLowResources();
			break;
		}
	default:
		{
			OnUserDefinedRequest(dwControl);
			break;
		}
	}

	//Any request from the SCM will be acked by this service
	ReportStatus();

	return dwRet;
}

_Return_type_success_(return != 0) BOOL CNTService::RegisterCtrlHandler()
{
	ATL::CComCritSecLock<ATL::CComAutoCriticalSection> sl(m_CritSect, true); //Synchronize access to the variables

	ATLASSERT(m_hStatus == 0); //If this ASSERTs, most likely you are calling RegisterCtrlHandler
	//yourself. Just remove this call from your code as this is now
	//done for you automatically by the CNTService framework

#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_hStatus = RegisterServiceCtrlHandlerEx(m_sServiceName, _ServiceCtrlHandlerEx, nullptr);
#else
	m_hStatus = RegisterServiceCtrlHandlerEx(m_sServiceName.c_str(), _ServiceCtrlHandlerEx, nullptr);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	return (m_hStatus != 0);
}

void WINAPI CNTService::ServiceMain(_In_ DWORD /*dwArgc*/, _In_opt_ LPTSTR* /*lpszArgv*/)
{
	//Default implementation does nothing but asserts, your version should
	//implement its own service specific code
	ATLASSERT(FALSE); 
}

void WINAPI CNTService::_ServiceCtrlHandler(_In_ DWORD dwControl)
{
	//Validate our parameters
	ATLASSUME(sm_pService != nullptr);

	//Convert from the SDK world to the C++ world
	sm_pService->ServiceCtrlHandler(dwControl, 0, nullptr);
}

DWORD WINAPI CNTService::_ServiceCtrlHandlerEx(_In_ DWORD dwControl, _In_ DWORD dwEventType, _In_opt_ LPVOID pEventData, _In_opt_ LPVOID /*pContext*/)
{
	//Validate our parameters
	ATLASSUME(sm_pService != nullptr);

	//Convert from the SDK world to the C++ world
	return sm_pService->ServiceCtrlHandler(dwControl, dwEventType, pEventData);
}

void WINAPI CNTService::_SDKServiceMain(_In_ DWORD dwArgc, _In_opt_ LPTSTR* pszArgv)
{
	//Validate our parameters
	ATLASSUME(sm_pService != nullptr);

	//Convert from the SDK world to the C++ world
	sm_pService->_ServiceMain(dwArgc, pszArgv);
}

void CNTService::_ServiceMain(_In_ DWORD dwArgc, _In_opt_ LPTSTR* pszArgv)
{
	//Register the Control Handler
	RegisterCtrlHandler();

	DWORD dwWin32ExitCode = NO_ERROR;
	DWORD dwServiceSpecificExitCode = 0;

	//Call the main C++ function
	try
	{
		ServiceMain(dwArgc, pszArgv);
	}
	catch(CNTServiceTerminateException& e)
	{
		dwWin32ExitCode = e.m_dwWin32ExitCode;
		dwServiceSpecificExitCode = e.m_dwServiceSpecificExitCode;
	}

	//Report to the SCM that the service has stopped.
	//Note that it is important that we do not access anything on the stack 
	//after this call as the SCM could have terminated this worker thread by then
	_ReportStatus(SERVICE_STOPPED, 0, 0, 0, dwWin32ExitCode, dwServiceSpecificExitCode);
}

_Return_type_success_(return != 0) BOOL CNTService::WriteServiceProfileString(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_opt_z_ LPCTSTR pszValue, _In_ BOOL bFlush, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSUME(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	LSTATUS lResult = 0;
	if (pszEntry == nullptr) //delete whole section
	{
		ATL::CRegKey serviceKey;
		if (!GetServiceParametersKey(serviceKey, pszService, FALSE, pLastError))
			return FALSE;

		lResult = serviceKey.DeleteSubKey(pszSection);
		if ((lResult != ERROR_SUCCESS) && pLastError)
			*pLastError = lResult;
		if (bFlush)
			serviceKey.Flush();
	}
	else if (pszValue == nullptr)
	{
		ATL::CRegKey secKey;
		if (!GetSectionKey(secKey, pszService, pszSection, FALSE, pLastError))
			return FALSE;

		lResult = secKey.DeleteValue(pszEntry);
		if ((lResult != ERROR_SUCCESS) && pLastError)
			*pLastError = lResult;
		if (bFlush)
			secKey.Flush();
	}
	else
	{
		ATL::CRegKey secKey;
		if (!GetSectionKey(secKey, pszService, pszSection, FALSE, pLastError))
			return FALSE;

		lResult = secKey.SetStringValue(pszEntry, pszValue);
		if ((lResult != ERROR_SUCCESS) && pLastError)
			*pLastError = lResult;
		if (bFlush)
			secKey.Flush();
	}
	return lResult == ERROR_SUCCESS;
}

_Return_type_success_(return != 0) BOOL CNTService::WriteServiceProfileInt(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ int nValue, _In_ BOOL bFlush, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSERT(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, FALSE, pLastError))
		return FALSE;

	LSTATUS lResult = secKey.SetDWORDValue(pszEntry, nValue);
	if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
		*pLastError = lResult;
	if (bFlush)
		secKey.Flush();
	return lResult == ERROR_SUCCESS;
}

_Return_type_success_(return != 0) BOOL CNTService::WriteServiceProfileStringArray(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ const CNTServiceStringArray& array, _In_ BOOL bFlush, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszSection != nullptr);
	ATLASSERT(pszService != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, FALSE, pLastError))
		return FALSE;

	BOOL bSuccess = CNTEventLogSource::SetStringArrayIntoRegistry(secKey, pszEntry, array, pLastError);
	if (bFlush)
		secKey.Flush();
	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTService::WriteServiceProfileBinary(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_reads_bytes_opt_(nBytes) LPBYTE pData, _In_ ULONG nBytes, _In_ BOOL bFlush, _Inout_opt_ DWORD* pLastError)
{ 
	//Validate our parameters
	ATLASSERT(pszSection != nullptr);
	ATLASSERT(pszService != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, FALSE, pLastError))
		return FALSE;

	LSTATUS lResult = secKey.SetBinaryValue(pszEntry, pData, nBytes);
	if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
		*pLastError = lResult;
	if (bFlush)
		secKey.Flush();
	return lResult == ERROR_SUCCESS;
}

CNTServiceString CNTService::GetServiceProfileString(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_opt_z_ LPCTSTR pszDefault, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSERT(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, TRUE, pLastError))
		return CNTServiceString((pszDefault == nullptr) ? _T("") : pszDefault);

	CNTServiceString sValue;
	DWORD dwType = 0;
	ULONG nBytes = 0;
	LSTATUS lResult = secKey.QueryValue(pszEntry, &dwType, nullptr, &nBytes);
	if (lResult == ERROR_SUCCESS)
	{
		ULONG nChars = nBytes/sizeof(TCHAR);
#ifdef CNTSERVICE_MFC_EXTENSIONS
		lResult = secKey.QueryStringValue(pszEntry, sValue.GetBuffer(nChars), &nChars);
		sValue.ReleaseBuffer();
#else
		sValue.resize(nChars);
		lResult = secKey.QueryStringValue(pszEntry, &(sValue[0]), &nChars);
		if (lResult == ERROR_SUCCESS)
			sValue.erase(nChars - 1, 1);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
		*pLastError = lResult;

	if (lResult == ERROR_SUCCESS)
		return sValue;

	return CNTServiceString((pszDefault == nullptr) ? _T("") : pszDefault);
}

UINT CNTService::GetServiceProfileInt(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ int nDefault, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSERT(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, TRUE, pLastError))
		return nDefault;

	DWORD dwValue;
	LSTATUS lResult = secKey.QueryDWORDValue(pszEntry, dwValue);
	if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
		*pLastError = lResult;

	if (lResult == ERROR_SUCCESS)
		return static_cast<UINT>(dwValue);

	return nDefault;
}

_Return_type_success_(return != 0) BOOL CNTService::GetServiceProfileStringArray(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _Out_ CNTServiceStringArray& array, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSERT(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	//Remove all the array entries before we go any further
#ifdef CNTSERVICE_MFC_EXTENSIONS
	array.RemoveAll();
#else
	array.clear();
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, TRUE, pLastError))
		return FALSE;

	return CNTEventLogSource::GetStringArrayFromRegistry(secKey, pszEntry, array, pLastError);
}

_Return_type_success_(return != 0) BOOL CNTService::GetServiceProfileBinary(_In_opt_z_ LPCTSTR pszService, _In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _Out_writes_bytes_(*pnBytes) LPBYTE* ppData, _Out_ ULONG* pnBytes, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszService != nullptr);
	ATLASSERT(pszSection != nullptr);
	ATLASSERT(pszEntry != nullptr);
	ATLASSUME(ppData != nullptr);
	ATLASSUME(pnBytes != nullptr);

	//Initialize the output parameter to default value.
	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	*ppData = nullptr;
	*pnBytes = 0;

	ATL::CRegKey secKey;
	if (!GetSectionKey(secKey, pszService, pszSection, TRUE, pLastError))
		return FALSE;

	DWORD dwType = 0;
	LSTATUS lResult = secKey.QueryValue(pszEntry, &dwType, nullptr, pnBytes);
	if (lResult == ERROR_SUCCESS)
	{
		*ppData = new BYTE[*pnBytes];
		lResult = secKey.QueryBinaryValue(pszEntry, *ppData, pnBytes);
		if ((lResult != ERROR_SUCCESS) && pLastError)
			*pLastError = lResult;
	}
	else
	{
		if (pLastError != nullptr)
			*pLastError = lResult;
	}

	if (lResult == ERROR_SUCCESS)
		return TRUE;
	else
	{
		delete [] *ppData;
		*ppData = nullptr;
	}

	return FALSE;
}

// returns key for:
//      HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ServiceName\Parameters\pszSection
// creating it if it doesn't exist.
_Return_type_success_(return != 0) BOOL CNTService::GetSectionKey(_In_ ATL::CRegKey& sectionKey, _In_opt_z_ LPCTSTR pszServiceName, _In_opt_z_ LPCTSTR pszSection, _In_ BOOL bReadOnly, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSERT(pszServiceName != nullptr);
	ATLASSUME(pszSection != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey serviceParametersKey;
	if (!GetServiceParametersKey(serviceParametersKey, pszServiceName, bReadOnly, pLastError))
		return FALSE;

	LSTATUS lResult = sectionKey.Create(serviceParametersKey, pszSection, REG_NONE, REG_OPTION_NON_VOLATILE, bReadOnly ? KEY_READ : KEY_WRITE | KEY_READ, nullptr);
	if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
		*pLastError = lResult;

	return (lResult == ERROR_SUCCESS);
}

// returns key for:
//      HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ServiceName\Parameters
// creating it if it doesn't exist
_Return_type_success_(return != 0) BOOL CNTService::GetServiceParametersKey(_In_ ATL::CRegKey& serviceParametersKey, _In_opt_z_ LPCTSTR pszServiceName, _In_ BOOL bReadOnly, _Inout_opt_ DWORD* pLastError)
{
	//Validate our parameters
	ATLASSUME(pszServiceName != nullptr);

	if (pLastError != nullptr)
		*pLastError = ERROR_SUCCESS;

	ATL::CRegKey servicesKey;
	LSTATUS lResult = servicesKey.Open(HKEY_LOCAL_MACHINE, _T("SYSTEM\\CurrentControlSet\\Services"), bReadOnly ? KEY_READ : KEY_WRITE | KEY_READ);
	if (lResult == ERROR_SUCCESS)
	{
		//Create the service key
		ATL::CRegKey serviceKey;
		lResult = serviceKey.Create(servicesKey, pszServiceName, REG_NONE, REG_OPTION_NON_VOLATILE, KEY_WRITE | KEY_READ, nullptr);
		if (lResult == ERROR_SUCCESS)
		{
			//Create the parameters key
			lResult = serviceParametersKey.Create(serviceKey, _T("Parameters"), REG_NONE, REG_OPTION_NON_VOLATILE, KEY_WRITE | KEY_READ, nullptr);
			if ((lResult != ERROR_SUCCESS) && (pLastError != nullptr))
				*pLastError = lResult;
		}
		else
		{
			if (pLastError != nullptr)
				*pLastError = lResult;
		}
	}
	else
	{
		if (pLastError != nullptr)
			*pLastError = lResult;
	}

	return (lResult == ERROR_SUCCESS);
}

_Return_type_success_(return != 0) BOOL CNTService::WriteProfileString(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_opt_z_ LPCTSTR pszValue)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return WriteServiceProfileString(m_sServiceName, pszSection, pszEntry, pszValue, m_bProfileWriteFlush);
#else
	return WriteServiceProfileString(m_sServiceName.c_str(), pszSection, pszEntry, pszValue, m_bProfileWriteFlush);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::WriteProfileInt(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ int nValue)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return WriteServiceProfileInt(m_sServiceName, pszSection, pszEntry, nValue, m_bProfileWriteFlush);
#else
	return WriteServiceProfileInt(m_sServiceName.c_str(), pszSection, pszEntry, nValue, m_bProfileWriteFlush);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::WriteProfileStringArray(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ const CNTServiceStringArray& array)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return WriteServiceProfileStringArray(m_sServiceName, pszSection, pszEntry, array, m_bProfileWriteFlush);
#else
	return WriteServiceProfileStringArray(m_sServiceName.c_str(), pszSection, pszEntry, array, m_bProfileWriteFlush);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::WriteProfileBinary(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_reads_bytes_opt_(nBytes) LPBYTE pData, _In_ UINT nBytes)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return WriteServiceProfileBinary(m_sServiceName, pszSection, pszEntry, pData, nBytes, m_bProfileWriteFlush);
#else
	return WriteServiceProfileBinary(m_sServiceName.c_str(), pszSection, pszEntry, pData, nBytes, m_bProfileWriteFlush);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

CNTServiceString CNTService::GetProfileString(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_opt_z_ LPCTSTR pszDefault, _Inout_opt_ DWORD* pLastError)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return GetServiceProfileString(m_sServiceName, pszSection, pszEntry, pszDefault, pLastError);
#else
	return GetServiceProfileString(m_sServiceName.c_str(), pszSection, pszEntry, pszDefault, pLastError);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

UINT CNTService::GetProfileInt(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _In_ int nDefault, _Inout_opt_ DWORD* pLastError)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return GetServiceProfileInt(m_sServiceName, pszSection, pszEntry, nDefault, pLastError);
#else
	return GetServiceProfileInt(m_sServiceName.c_str(), pszSection, pszEntry, nDefault, pLastError);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::GetProfileStringArray(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _Out_ CNTServiceStringArray& array)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	return GetServiceProfileStringArray(m_sServiceName, pszSection, pszEntry, array);
#else
	return GetServiceProfileStringArray(m_sServiceName.c_str(), pszSection, pszEntry, array);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::GetProfileBinary(_In_opt_z_ LPCTSTR pszSection, _In_opt_z_ LPCTSTR pszEntry, _Out_writes_bytes_(*pnBytes) LPBYTE* ppData, _Out_ ULONG* pnBytes)
{
	//Validate our parameters
	ATLASSUME(pnBytes != nullptr);
	*pnBytes = 0;

#ifdef CNTSERVICE_MFC_EXTENSIONS
	return GetServiceProfileBinary(m_sServiceName, pszSection, pszEntry, ppData, pnBytes);
#else
	return GetServiceProfileBinary(m_sServiceName.c_str(), pszSection, pszEntry, ppData, pnBytes);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}
_Return_type_success_(return != 0) BOOL CNTService::Run()
{
	//Set up the SERVICE table array
	SERVICE_TABLE_ENTRY ServiceTable[2];
	TCHAR szServiceName[256];
#ifdef CNTSERVICE_MFC_EXTENSIONS
	_tcscpy_s(szServiceName, sizeof(szServiceName)/sizeof(TCHAR), m_sServiceName);
#else
	_tcscpy_s(szServiceName, sizeof(szServiceName)/sizeof(TCHAR), m_sServiceName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	ServiceTable[0].lpServiceName = szServiceName;
	ServiceTable[0].lpServiceProc = _SDKServiceMain;
	ServiceTable[1].lpServiceName = 0;
	ServiceTable[1].lpServiceProc = 0;

	//Notify the SCM of our service
	return StartServiceCtrlDispatcher(ServiceTable);
}

_Return_type_success_(return != 0) BOOL CNTService::GetDependencies(_Out_ ATL::CHeapPtr<TCHAR>& mszDependencies)
{
	//Work out the size of the string we need
#ifdef CNTSERVICE_MFC_EXTENSIONS
	int nSize = 0;
	INT_PTR nDependencies = m_sDependencies.GetSize();
	for (INT_PTR i=0; i<nDependencies; i++)
		nSize += (m_sDependencies.GetAt(i).GetLength() + 1);
#else
	CNTServiceStringArray::size_type nSize = 0;
	CNTServiceStringArray::size_type nDependencies = m_sDependencies.size();
	for (CNTServiceStringArray::size_type i=0; i<nDependencies; i++)
		nSize += (m_sDependencies[i].length() + 1);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//Need one second null for the double null at the end
	nSize++;

	//Now form the string
	if (!mszDependencies.Allocate(nSize))
	{
		SetLastError(ERROR_OUTOFMEMORY);
		return FALSE;
	}

	//Now copy thr strings into the buffer
	LPTSTR pszString = mszDependencies.m_pData;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	int nCurOffset = 0;
	for (INT_PTR i=0; i<nDependencies; i++)
#else
	CNTServiceStringArray::size_type nCurOffset = 0;
	for (CNTServiceStringArray::size_type i=0; i<nDependencies; i++)
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		CNTServiceString sDependency(m_sDependencies.GetAt(i));
		int nDependencyLength = sDependency.GetLength();
		_tcscpy_s(&pszString[nCurOffset], nDependencyLength+1, sDependency);
#else
		const CNTServiceString& sDependency = m_sDependencies[i];
		CNTServiceString::size_type nDependencyLength = sDependency.length();
		_tcscpy_s(&pszString[nCurOffset], nDependencyLength+1, sDependency.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		nCurOffset += (nDependencyLength + 1);
	}
	//Don't forgot to doubly null terminate
	pszString[nCurOffset] = _T('\0');

	return TRUE;
}

void CNTService::TerminateService(_In_ DWORD dwWin32ExitCode, _In_ DWORD dwServiceSpecificExitCode)
{
	throw CNTServiceTerminateException(dwWin32ExitCode, dwServiceSpecificExitCode);
}

void CNTService::SecureEmptyString(_Inout_ CNTServiceString& sVal)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	int nLength = sVal.GetLength();
	LPTSTR pszVal = sVal.GetBuffer(nLength);
	SecureZeroMemory(pszVal, nLength*sizeof(TCHAR));
	sVal.ReleaseBuffer();
#else
	//fix:�ж�sVal.length()==0
	if(sVal.length()==0){
		ATLTRACE(_T("CNTService::SecureEmptyString:sVal.length()==0\n"));
	}
	else{
		ATLTRACE(_T("CNTService::SecureEmptyString:sVal.length()==%d\n"),sVal.length());
		SecureZeroMemory(&(sVal[0]), sVal.length());
	}
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

_Return_type_success_(return != 0) BOOL CNTService::InstallEventLogSource(_Inout_ CNTServiceString& sErrorMsg, _Inout_ DWORD& dwError)
{
	//Validate our parameters
	ATLASSERT(m_bEventLogSource);

	//Initialize the output parameters to default values.
	sErrorMsg = CNTServiceString();
	dwError = ERROR_SUCCESS;

	//Setup this service as an event log source (using the friendly name)
	//If a message dll has not been specified, then we use one with the same name 
	//as this application and in the same path
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_sEventMessageFile.IsEmpty())
#else
	if (m_sEventMessageFile.length() == 0)
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		TCHAR szAppPath[_MAX_PATH];
		szAppPath[0] = _T('\0');
		if (!GetModuleFileName(nullptr, szAppPath, _MAX_PATH))
		{
			dwError = GetLastError();
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_INSTALL_AS_EVENT_LOG_SOURCE), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
		TCHAR szPath[_MAX_PATH];
		szPath[0] = _T('\0');
		TCHAR szDrive[_MAX_DRIVE];
		szDrive[0] = _T('\0');
		TCHAR szDir[_MAX_DIR];
		szDir[0] = _T('\0');
		TCHAR szFname[_MAX_FNAME];
		szFname[0] = _T('\0');
		_tsplitpath_s(szAppPath, szDrive, sizeof(szDrive)/sizeof(TCHAR), szDir, sizeof(szDir)/sizeof(TCHAR), szFname, sizeof(szFname)/sizeof(TCHAR), nullptr, 0);
		_tmakepath_s(szPath, sizeof(szPath)/sizeof(TCHAR), szDrive, szDir, szFname, _T("DLL"));
		m_sEventMessageFile = szPath;
	}

#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (!m_EventLogSource.Install(m_EventLogSource.GetLogName(), m_EventLogSource.GetSourceName(), m_sEventMessageFile, m_sEventCategoryMessageFile, m_sEventParameterMessageFile, m_dwEventTypesSupported, m_dwEventCategoryCount))
#else
	if (!m_EventLogSource.Install(m_EventLogSource.GetLogName().c_str(), m_EventLogSource.GetSourceName().c_str(), m_sEventMessageFile.c_str(), m_sEventCategoryMessageFile.c_str(), m_sEventParameterMessageFile.c_str(), m_dwEventTypesSupported, m_dwEventCategoryCount))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_INSTALL_AS_EVENT_LOG_SOURCE), dwError, FALSE);
		TraceMessage(sErrorMsg);
		return FALSE;
	}

	return TRUE;
}
CNTServiceString CNTService::GetHelperMainFile(CNTServiceString strExeFile){
	TCHAR szAppPath[_MAX_PATH];
	szAppPath[0] = _T('\0');
	GetModuleFileName(NULL, szAppPath,_MAX_PATH);
	TCHAR szDrive[_MAX_DRIVE];
	szDrive[0] = _T('\0');
	TCHAR szDir[_MAX_DIR];
	szDir[0] = _T('\0');
	TCHAR szFname[_MAX_FNAME];
	szFname[0] = _T('\0');  
	_tsplitpath_s(szAppPath, szDrive, sizeof(szDrive)/sizeof(TCHAR), szDir, sizeof(szDir)/sizeof(TCHAR), szFname, sizeof(szFname)/sizeof(TCHAR), nullptr, 0);
	_stprintf_s(szAppPath,sizeof(szAppPath)/sizeof(TCHAR), _T("%s\\APPSOFT\\ZLHelperMain.EXE"), szDrive);
	strExeFile.assign(szAppPath);
	return strExeFile;
}
BOOL CNTService::IsFileExists(LPCTSTR strExeFile){
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;

	hFind = FindFirstFile(strExeFile, &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) { 
		return FALSE;
	} 
	else {
		FindClose(hFind); 
		return TRUE;
	}
}
//����һ��EXE�����ؽ���ID.�������û��UI����Ȩ�ޣ���Ҫ���⴦��.ÿ���Ự��ͬ������
BOOL CNTService::RunExeInEverySession(LPCTSTR pszExeFile,LPCTSTR pszExeFileName)	
{	//��WIn7
	if(m_pfnWTSEnumerateProcessesEx==nullptr ||  m_pfnWTSEnumerateProcessesEx==nullptr ||m_pfnWTSEnumerateSessionsEx==nullptr)
	{
		return RunExeInEverySessionVista(pszExeFile,pszExeFileName);
	}
	else
	{
		//return RunExeInEverySessionVista(pszExeFile,pszExeFileName);
		return RunExeInEverySessionVista(pszExeFile,pszExeFileName);
	}
}
//����һ��EXE�����ؽ���ID.�������û��UI����Ȩ�ޣ���Ҫ���⴦��.ÿ���Ự��ͬ������
BOOL CNTService::KillExeInEverySession(LPCTSTR pszExeFileName)	
{	//��WIn7
	if(m_pfnWTSEnumerateProcessesEx==nullptr ||  m_pfnWTSEnumerateProcessesEx==nullptr ||m_pfnWTSEnumerateSessionsEx==nullptr)
	{
		return KillExeInEverySessionVista(pszExeFileName);
	}
	else
	{
		return KillExeInEverySessionVista(pszExeFileName);
		//return KillExeInEverySessionWin7(pszExeFile,pszExeFileName);
	}
}
//2003���ڲ���APIʵ���Ǵ��ڣ���MSDN˵�����ڲ��죬��ʱ�����ӿڣ���ʵ��
BOOL CNTService::RunExeInEverySessionWin2003(LPCTSTR pszExeFile,LPCTSTR pszExeFileName)
{
	return true;
}
//2003���ڲ���APIʵ���Ǵ��ڣ���MSDN˵�����ڲ��죬��ʱ�����ӿڣ���ʵ��
BOOL CNTService::KillExeInEverySessionWin2003(LPCTSTR pszExeFileName)
{
	return true;
}
BOOL CNTService::RunExeInEverySessionVista(LPCTSTR pszExeFile,LPCTSTR pszExeFileName)
{
	DWORD dwSessionId = 0;
	PWTS_SESSION_INFO  pSessionInfo = NULL;
	DWORD dwSessionCount = 0;
	DWORD dwSessionLevel=1;
	HANDLE hThisProcess = GetCurrentProcess(); // ��ȡ��ǰ���̾��
	TCHAR szError[_MAX_PATH]={0};
	if(!m_pfnWTSEnumerateSessions(WTS_CURRENT_SERVER_HANDLE,0, 1,  &pSessionInfo, &dwSessionCount)){
		_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionVista:WTSEnumerateSessions.Error=%d"), GetLastError());
		LogEvent(szError); 
	}
	int *pSessionMap;
	pSessionMap=new int[dwSessionCount];
	DWORD *pSessionIDMap;
	pSessionIDMap=new DWORD[dwSessionCount];
	for(DWORD i = 0; i < dwSessionCount; i++)
	{
		WTS_SESSION_INFO si = pSessionInfo[i];
		pSessionIDMap[i]=si.SessionId;
		pSessionMap[i]=0;
	}

	DWORD dwCurIdex	=0;
	DWORD dwFind	=0;
	UINT	uFailed=0;
	DWORD dwProcessID = 0;
	DWORD dwCurSessionID=0;
	PROCESSENTRY32 pe = {sizeof(PROCESSENTRY32)};
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);

	if (hSnapshot != INVALID_HANDLE_VALUE)
	{
		if (Process32First(hSnapshot, &pe))
		{
			while (Process32Next(hSnapshot, &pe)){
				if (lstrcmpi(pszExeFileName, pe.szExeFile) == 0)
				{
					dwProcessID = pe.th32ProcessID;
					dwCurSessionID=0;
					if(!m_pfnProcessIdToSessionId(dwProcessID,&dwCurSessionID))
					{
						_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionVista:ProcessIdToSessionId.Error=%d"), GetLastError());
						LogEvent(szError); 
					}
					else
					{
						dwCurIdex=0;
						for(DWORD i = 0; i < dwSessionCount; i++)
						{
							if(pSessionIDMap[i]==dwCurSessionID)
							{
								dwCurIdex=i;
								break;
							}
						}
						pSessionMap[dwCurIdex]=dwProcessID;
					}
					dwFind=dwFind+1;
					if(dwFind==dwSessionCount)
					{
						break;
					}
				}
			}
		}
		CloseHandle(hSnapshot);
	}
	for(DWORD i = 0; i < dwSessionCount; i++)
	{
		WTS_SESSION_INFO si = pSessionInfo[i];
		//�ûỰû���������ּ���
		if(WTSActive == si.State && pSessionMap[i]==0 )
		{
			TCHAR szUserName[_MAX_PATH]={0};
			TCHAR szDomain[_MAX_PATH]={0};
			DWORD dwBufferLen;
			LPTSTR pBuffer = NULL;
			if(!m_pfnWTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, si.SessionId, WTSUserName, &pBuffer, &dwBufferLen))
			{
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionVista:WTSQuerySessionInformation_UserName.Error=%d"), GetLastError());
				LogEvent(szError); 
			}
			else
			{
				lstrcpy(szUserName ,pBuffer);
				m_pfnWTSFreeMemory(pBuffer);
			}
			pBuffer=NULL;
			dwBufferLen=0;
			if(!m_pfnWTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, si.SessionId, WTSDomainName, &pBuffer, &dwBufferLen))
			{
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionVista:WTSQuerySessionInformation_DomainName.Error=%d"), GetLastError());
				LogEvent(szError); 
			}
			else
			{
				lstrcpy(szDomain ,pBuffer);
				m_pfnWTSFreeMemory(pBuffer);
			}
			BOOL   bOk=true;
			LogEvent(_T("RunExeInEverySessionVista:Not Find HelperMain Proccess"));
			TCHAR szCommand[1024]={0};
			//����ӿ�ͷ�ո񣬷��������д��ݲ�ȫ
			_stprintf_s(szCommand,sizeof(szCommand)/sizeof(TCHAR), _T(" SVRSTART SESSIONID=%d USERNAME=%s DOMAIN=%s"),si.SessionId,szUserName,szDomain);
			bOk=RunExeInSession(hThisProcess,si.SessionId,pszExeFile,szCommand);
			if( !bOk )
			{
				uFailed=uFailed+1;
			}
		}
	}
	m_pfnWTSFreeMemory(pSessionInfo);
	if (hThisProcess != NULL)
		CloseHandle(hThisProcess);
	delete[]pSessionMap;
	delete[]pSessionIDMap;
	return uFailed==0;
}
BOOL CNTService::KillExeInEverySessionVista(LPCTSTR pszExeFileName)
{
	DWORD dwSessionId = 0;
	PWTS_SESSION_INFO  pSessionInfo = NULL;
	DWORD dwSessionCount = 0;
	DWORD dwSessionLevel=1;
	TCHAR szError[_MAX_PATH]={0};
	if(!m_pfnWTSEnumerateSessions(WTS_CURRENT_SERVER_HANDLE,0, 1,  &pSessionInfo, &dwSessionCount)){
		_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("KillExeInEverySessionVista:WTSEnumerateSessions.Error=%d"), GetLastError());
		LogEvent(szError); 
	}
	DWORD *pSessionMap;
	pSessionMap=new DWORD[dwSessionCount];
	for(DWORD i = 0; i < dwSessionCount; i++)
	{
		pSessionMap[i]=0;
	}
	DWORD dwCurIdex	=0;
	DWORD dwProcessID = 0;
	PROCESSENTRY32 pe = {sizeof(PROCESSENTRY32)};
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);
	if (hSnapshot != INVALID_HANDLE_VALUE)
	{
		pe.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hSnapshot, &pe))
		{
			pe.dwSize = sizeof(PROCESSENTRY32);
			do
			{
				if (lstrcmpi(pszExeFileName, pe.szExeFile) == 0)
				{
					dwProcessID = pe.th32ProcessID;
					pSessionMap[dwCurIdex]=dwProcessID;
					dwCurIdex=dwCurIdex+1;
					if(dwCurIdex==dwSessionCount)
					{
						break;
					}
				}
				pe.dwSize = sizeof(PROCESSENTRY32);
			}while (Process32Next(hSnapshot, &pe));
		}
		CloseHandle(hSnapshot);
	}
	for(DWORD i = 0; i < dwSessionCount; i++)
	{
		if(pSessionMap[i]!=0 )
		{	
			if(!m_pfnWTSTerminateProcess(WTS_CURRENT_SERVER_HANDLE,pSessionMap[i],1))
			{
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("KillExeInEverySessionVista:WTSTerminateProcess(%d).Error=%d"), pSessionMap[i],GetLastError());
				LogEvent(szError); 
				HANDLE   hTmpProcess = OpenProcess(PROCESS_ALL_ACCESS,FALSE,pSessionMap[i]);
				if(hTmpProcess==0){
					_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("KillExeInEverySessionVista:OpenProcess(%d).Error=%d"), pSessionMap[i],GetLastError());
					LogEvent(szError); 
				}else{
					UINT uExitCode=0;
					if(!TerminateProcess(hTmpProcess,uExitCode))
					{
						_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("KillExeInEverySessionVista:TerminateProcess(%d).Error=%d"), pSessionMap[i],GetLastError());
						LogEvent(szError); 
					}
				}
			}
		}
	}
	m_pfnWTSFreeMemory(pSessionInfo);
	delete[]pSessionMap;
	return true;
}
BOOL CNTService::RunExeInEverySessionWin7(LPCTSTR pszExeFile,LPCTSTR pszExeFileName)	
{
	DWORD dwSessionId = 0;
	PWTS_SESSION_INFO_1 pSessionInfo = NULL;
	DWORD dwSessionCount = 0;
	DWORD dwSessionLevel=1;
	HANDLE hThisProcess = GetCurrentProcess(); // ��ȡ��ǰ���̾��
	TCHAR szError[_MAX_PATH]={0};
	if(!m_pfnWTSEnumerateSessionsEx(WTS_CURRENT_SERVER_HANDLE,&dwSessionLevel, 0,  &pSessionInfo, &dwSessionCount)){
		_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionWin7:WTSEnumerateSessionsEx.Error=%d"), GetLastError());
		LogEvent(szError); 
	}
	UINT	uFailed=0;
	//_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySession:SessionCount=%d"), dwSessionCount);
	//LogEvent(szError); 
	for(DWORD i = 0; i < dwSessionCount; i++)
	{
		WTS_SESSION_INFO_1 si = pSessionInfo[i];
		if(WTSActive == si.State)
		{
			PWTS_PROCESS_INFO pProcessInfo = NULL;
			DWORD dwProCount = 0;
			DWORD dwProLevel=0;
			BOOL  bFind = false;
			if(!m_pfnWTSEnumerateProcessesEx(WTS_CURRENT_SERVER_HANDLE,&dwProLevel,si.SessionId,(LPSTR *)&pProcessInfo,&dwProCount))
			{
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionWin7:WTSEnumerateProcessesEx.Error=%d"), GetLastError());
				LogEvent(szError); 
			}
			//_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySession:ProccessCount=%d"), dwProCount);
			//LogEvent(szError); 
			for(DWORD j = 0; j < dwProCount; j++){
				WTS_PROCESS_INFO pi=pProcessInfo[j];
				TCHAR szModName[MAX_PATH]= {0};
				HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,FALSE,pi.ProcessId);  
				if(hProcess)  
				{
					if (GetModuleFileNameEx(hProcess, NULL, szModName, MAX_PATH))
					{
						//_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySession:Proccess[%d]=%s"),j, szModName);
						//LogEvent(szError); 
						if (_tcsicmp(szModName,pszExeFile) == 0)
						{
	/*						_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySession:FindHelperMain=%d") ,pi.ProcessId);
							LogEvent(szError); */
							bFind=true;
							break;
						}
					}
					else
					{
						_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionWin7:GetModuleFileNameEx.Error=%d"),GetLastError());
						LogEvent(szError);
					}
					CloseHandle( hProcess );
				}
				else
				{
					_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionWin7:OpenProcess.Error=%d"),GetLastError());
					LogEvent(szError);
				}
			}
			if(!m_pfnWTSFreeMemoryEx(WTSTypeProcessInfoLevel0,pProcessInfo,dwProCount))
			{
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInEverySessionWin7:WTSFreeMemoryEx_Pro.Error=%d"),GetLastError());
				LogEvent(szError);
			}
			//�ûỰû���������ּ���
			if(!bFind)
			{
				BOOL   bOk=true;
				LogEvent(_T("RunExeInEverySessionWin7:Not Find HelperMain Proccess"));
				TCHAR szCommand[1024]={0};
				//����ӿ�ͷ�ո񣬷��������д��ݲ�ȫ
				_stprintf_s(szCommand,sizeof(szCommand)/sizeof(TCHAR), _T(" SVRSTART SESSIONID=%d USERNAME=%s DOMAIN=%s"),si.SessionId,si.pUserName,si.pDomainName);
				bOk=RunExeInSession(hThisProcess,si.SessionId,pszExeFile,szCommand);
				if( !bOk )
				{
					uFailed=uFailed+1;
				}
			}
		}
	}
	m_pfnWTSFreeMemoryEx(WTSTypeSessionInfoLevel1,pSessionInfo,dwSessionCount);
	if (hThisProcess != NULL)
		CloseHandle(hThisProcess);
	return uFailed==0;
 }
 BOOL CNTService::RunExeInSession(HANDLE hThisProcess,DWORD dwSeeionID,LPCTSTR pszExeFile,LPTSTR pszCommandline)
 {
	// �򿪵�ǰ��������
	HANDLE hTokenThis = NULL;
	HANDLE hTokenDup = NULL;
	BOOL   bOk=true;
	TCHAR szError[_MAX_PATH];
	OpenProcessToken(hThisProcess, TOKEN_ALL_ACCESS, &hTokenThis);
	// ����һ���������ƣ�Ŀ����Ϊ���޸�session id���ԣ��Ա�������session�д�������
	DuplicateTokenEx(hTokenThis, MAXIMUM_ALLOWED,NULL, SecurityIdentification, TokenPrimary, &hTokenDup);
	DWORD dwCurSessionId=dwSeeionID; //��Ự��������
	BOOL bRes;
	bRes=SetTokenInformation(hTokenDup, TokenSessionId, &dwCurSessionId, sizeof(DWORD));
	if (!bRes)
	{
		_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInSession:SetTokenInformation.Error=%d"),GetLastError());
		LogEvent(szError);
		bOk=false;
	}
	STARTUPINFO siCur;
	PROCESS_INFORMATION piCur;
	ZeroMemory(&siCur, sizeof(STARTUPINFO));
	ZeroMemory(&piCur, sizeof(PROCESS_INFORMATION));
	siCur.cb = sizeof(STARTUPINFO);
	siCur.lpDesktop =_T("WinSta0\\Default");
	if(bOk){
		LPVOID pEnv =NULL;
		DWORD dwCreationFlags = CREATE_PRESERVE_CODE_AUTHZ_LEVEL;
		if(CreateEnvironmentBlock(&pEnv,hTokenDup,TRUE))
		{
			dwCreationFlags|=CREATE_UNICODE_ENVIRONMENT;
		}
		else
		{
			pEnv = NULL;
		}

		bRes = CreateProcessAsUser(
			hTokenDup,                     // client's access token
			pszExeFile,    // file to execute
			pszCommandline,                 // command line
			NULL,            // pointer to process SECURITY_ATTRIBUTES
			NULL,               // pointer to thread SECURITY_ATTRIBUTES
			FALSE,              // handles are not inheritable
			dwCreationFlags,     // creation flags
			pEnv,               // pointer to new environment block
			NULL,               // name of current directory
			&siCur,               // pointer to STARTUPINFO structure
			&piCur                // receives information about new process
			);	
		if(piCur.hProcess){	
			CloseHandle(piCur.hThread);
			CloseHandle(piCur.hProcess);
			if(!bRes)
			{ 
				bOk=false;
				_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInSession:CreateProcessAsUser.Error_1=%d"),GetLastError());
				LogEvent(szError);
			}
		}
		else
		{
			bOk=false;
			_stprintf_s(szError,sizeof(szError)/sizeof(TCHAR), _T("RunExeInSession:CreateProcessAsUser.Error_2=%d"),GetLastError());
			LogEvent(szError);
		}
		if (pEnv != NULL)
		DestroyEnvironmentBlock(pEnv);
	}
	if (hTokenDup != NULL)
		CloseHandle(hTokenDup);
	if (hTokenThis != NULL)
		CloseHandle(hTokenThis);
	return bOk;
 }
_Return_type_success_(return != 0) BOOL CNTService::InstallServiceConfiguration(_In_ CNTScmService& service, _Inout_ CNTServiceString& sErrorMsg, _Inout_ DWORD& dwError)
{
	//Initialize the output parameters to default values.
	sErrorMsg = CNTServiceString();
	dwError = ERROR_SUCCESS;

	//Change the service description if necessary
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_sDescription.GetLength())
#else
	if (m_sDescription.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		if (!service.ChangeDescription(m_sDescription))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGEDESCRIPTION), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Change the service Sid if necessary
	if (m_dwServiceSidType != SERVICE_SID_TYPE_NONE)
	{
		if (!service.ChangeSidInfo(m_dwServiceSidType))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGESIDINFO), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Change the service DelayedAutoStart setting if necessary
	if (m_bDelayedAutoStart)
	{
		if (!service.ChangeDelayAutoStart(m_bDelayedAutoStart))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGEDELAYAUTOSTART), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Change the service privileges if necessary
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_sPrivileges.GetSize())
#else
	if (m_sPrivileges.size())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		if (!service.ChangeRequiredPrivileges(m_sPrivileges))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGEPRIVILEGES), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Change the preshutdown timeout if necessary
	if (m_dwPreshutdownTimeout)
	{
		if (!service.ChangePreShutdown(m_dwPreshutdownTimeout))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGEPRESHUTDOWNTIMEOUT), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Change the Launch protected setting if necessary
	if (m_dwLaunchProtected != SERVICE_LAUNCH_PROTECTED_NONE)
	{
		if (!service.ChangeLaunchProtected(m_dwLaunchProtected))
		{
			dwError = GetLastError();  
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CHANGELAUNCHPROTECTED), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	return TRUE;
}

_Return_type_success_(return != 0) BOOL CNTService::EnableServiceLogonRight(_Inout_ CNTServiceString& sErrorMsg, _Inout_ DWORD& dwError)
{
	//Validate our parameters
#ifdef CNTSERVICE_MFC_EXTENSIONS
	ATLASSERT(m_sUserName.GetLength());
#else
	ATLASSERT(m_sUserName.length());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//By default empty the error message 
	sErrorMsg = CNTServiceString();
	dwError = ERROR_SUCCESS;

	//First we need to lookup the SID for the specified account
	DWORD dwSIDSize = 0;
	DWORD dwDomainNameSize = 0;
	SID_NAME_USE snu;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	LookupAccountName(nullptr, m_sUserName, nullptr, &dwSIDSize, nullptr, &dwDomainNameSize, &snu);
#else
	LookupAccountName(nullptr, m_sUserName.c_str(), nullptr, &dwSIDSize, nullptr, &dwDomainNameSize, &snu);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (dwSIDSize)
	{
		ATL::CHeapPtr<BYTE> sid;
		ATL::CHeapPtr<TCHAR> domain;
		if (!sid.Allocate(dwSIDSize) || !domain.Allocate(dwDomainNameSize))
		{
			dwError = ERROR_OUTOFMEMORY;
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_ENABLESERVICELOGONRIGHT), dwError, FALSE);
			return FALSE;
		}
#ifdef CNTSERVICE_MFC_EXTENSIONS
		if (!LookupAccountName(nullptr, m_sUserName, sid.m_pData, &dwSIDSize, domain.m_pData, &dwDomainNameSize, &snu))
#else
		if (!LookupAccountName(nullptr, m_sUserName.c_str(), sid.m_pData, &dwSIDSize, domain.m_pData, &dwDomainNameSize, &snu))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		{
			dwError = GetLastError();
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_LOOKUP_ACCOUNT_NAME), dwError, FALSE);
			return FALSE;
		}

		//Open the Policy handle
		LSA_OBJECT_ATTRIBUTES attributes;
		memset(&attributes, 0, sizeof(attributes));
		LSA_HANDLE lsaHandle = nullptr;
		NTSTATUS ntStatus = LsaOpenPolicy(nullptr, &attributes, POLICY_LOOKUP_NAMES | POLICY_CREATE_ACCOUNT, &lsaHandle);
		if (ntStatus != ERROR_SUCCESS) //ERROR_SUCCESS == STATUS_SUCCESS
		{
			dwError = LsaNtStatusToWinError(ntStatus);
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_OPEN_POLICY_HANDLE), dwError, FALSE);
			return FALSE;
		}

		//Next prep a LSA_UNICODE_STRING for the privilege name with the Service Logon Right
		LSA_UNICODE_STRING userRights;
		const wchar_t* pszPrivilege = L"SeServiceLogonRight";
		userRights.Buffer = const_cast<PWSTR>(pszPrivilege);
		size_t dwPrivilegeLen = wcslen(pszPrivilege);
		userRights.Length = static_cast<USHORT>(dwPrivilegeLen * sizeof(wchar_t));
		userRights.MaximumLength = static_cast<USHORT>((dwPrivilegeLen + 1) * sizeof(wchar_t));

		//Finally call LsaAddAccountRights to enable the privilege
		ntStatus = LsaAddAccountRights(lsaHandle, static_cast<PSID>(sid.m_pData), &userRights, 1);
		if (ntStatus != ERROR_SUCCESS) //ERROR_SUCCESS == STATUS_SUCCESS
		{
			LsaClose(lsaHandle);
			dwError = LsaNtStatusToWinError(ntStatus);
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_ENABLESERVICELOGONRIGHT), dwError, FALSE);
			return FALSE;
		}

		//Release the policy handle now that we are finished with it
		LsaClose(lsaHandle);
	}
	else
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_LOOKUP_ACCOUNT_NAME), dwError, FALSE);
		return FALSE;
	}

	return TRUE;
}

_Return_type_success_(return != 0) BOOL CNTService::Install(_Inout_ CNTServiceString& sErrorMsg, _Inout_ DWORD& dwError)
{
	//By default empty the error message 
	sErrorMsg = CNTServiceString();
	dwError = ERROR_SUCCESS;

	//Open up the SCM requesting creation rights
	CNTServiceControlManager manager;
	if (!manager.Open(nullptr, SC_MANAGER_CREATE_SERVICE | SC_MANAGER_LOCK))
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_OPEN_SCM), dwError, FALSE);
		TraceMessage(sErrorMsg);
		return FALSE;
	}

	//Lock the SCM since we are going to install a service
	if (!manager.Lock())
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_LOCK_SCM), dwError, FALSE);
		TraceMessage(sErrorMsg);
		return FALSE;
	}

	//Get the dependencies for this service
	ATL::CHeapPtr<TCHAR> mszDependencies;
	if (!GetDependencies(mszDependencies))
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_GET_DEPENDENCIES), dwError, FALSE);
		TraceMessage(sErrorMsg);
		return FALSE;
	}

	//Create the new service entry in the SCM database
	CNTScmService service;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (!service.Create(manager, m_sServiceName, m_sDisplayName, SERVICE_CHANGE_CONFIG, m_dwServiceType, m_dwStartType, 
		m_dwErrorControl, m_sBinaryPathName, m_sLoadOrderGroup.GetLength() ? m_sLoadOrderGroup.GetString() : nullptr, 
		nullptr, mszDependencies, m_sUserName.GetLength() ? m_sUserName.GetString() : nullptr, 
		m_sPassword.GetLength() ? m_sPassword.GetString() : nullptr))
#else
	if (!service.Create(manager, m_sServiceName.c_str(), m_sDisplayName.c_str(), SERVICE_CHANGE_CONFIG, m_dwServiceType, m_dwStartType, 
		m_dwErrorControl, m_sBinaryPathName.c_str(), m_sLoadOrderGroup.length() ? m_sLoadOrderGroup.c_str() : nullptr, 
		nullptr, mszDependencies, m_sUserName.length() ? m_sUserName.c_str() : nullptr, 
		m_sPassword.length() ? m_sPassword.c_str() : nullptr))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		dwError = GetLastError();

		//As a security precaution we nuke the username and password details once we have used them
		SecureEmptyString(m_sUserName);
		SecureEmptyString(m_sPassword);

		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_INSTALL_FAIL_CREATESERVICE), dwError, FALSE);
		TraceMessage(sErrorMsg);
		return FALSE;
	}

	//As a security precaution we nuke the username and password details once we have used them
	SecureEmptyString(m_sUserName);
	SecureEmptyString(m_sPassword);

	//Install the event log source
	if (m_bEventLogSource)
	{
		if (!InstallEventLogSource(sErrorMsg, dwError))
			return FALSE;
	}

	//Setup the service configuration settings
	if (!InstallServiceConfiguration(service, sErrorMsg, dwError))
		return FALSE;

	//Add an Event log entry to say the service was successfully installed
	if (m_bEventLogSource)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_INSTALLED), m_sDisplayName);
#else
		m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MapMessageID(CNTS_MSG_SERVICE_INSTALLED), m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

#ifdef CNTSERVICE_MFC_EXTENSIONS
	ATLTRACE(_T("CNTService::Install, Service: %s was succesfully installed\n"), m_sServiceName.GetString());
#else
	ATLTRACE(_T("CNTService::Install, Service: %s was succesfully installed\n"), m_sServiceName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	return TRUE;
}

//Class used by EnumerateInstances
struct _NTSERV_EnumerateInstancesInfo
{
	//Constructors / Destructors
	_NTSERV_EnumerateInstancesInfo() : pServiceNames(nullptr), 
		psAppPath(nullptr),
		pManager(nullptr) 
	{
	}

	//Member variables
	CNTServiceStringArray*    pServiceNames; //The array to populate
	CNTServiceString*         psAppPath;     //The full path to this exe
	CNTServiceControlManager* pManager;      //Pointer to the controlling manager
};

_Return_type_success_(return != 0) BOOL CNTService::EnumerateInstances(_Out_ CNTServiceStringArray& ServiceNames, _Out_ DWORD& dwError)
{
	//By default empty the error message 
	dwError = ERROR_SUCCESS;

	//Empty the array before we go any further
#ifdef CNTSERVICE_MFC_EXTENSIONS
	ServiceNames.RemoveAll();
#else
	ServiceNames.clear();
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//Open up the SCM requesting enumeration rights
	CNTServiceControlManager manager;
	if (!manager.Open(nullptr, SC_MANAGER_CONNECT | SC_MANAGER_ENUMERATE_SERVICE))
	{
		dwError = GetLastError();
		return FALSE;
	}

	//Get the full path to this exe
	TCHAR szAppPath[_MAX_PATH];
	szAppPath[0] = _T('\0');
	if (!GetModuleFileName(nullptr, szAppPath, _MAX_PATH))
	{
		dwError = GetLastError();
		return FALSE;
	}
	CNTServiceString sAppPath(szAppPath);
#ifdef CNTSERVICE_MFC_EXTENSIONS
	sAppPath.MakeUpper(); //Comparisons will be case insensitive
#else
	std::transform(sAppPath.begin(), sAppPath.end(), sAppPath.begin(), [](TCHAR c) -> TCHAR { return static_cast<TCHAR>(_totupper(c)); });
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//Create the info struct we will pass to the callback function
	_NTSERV_EnumerateInstancesInfo info;
	info.pServiceNames = &ServiceNames;
	info.psAppPath = &sAppPath;
	info.pManager = &manager;

	//Finally call the enumeration function
	return manager.EnumServices(SERVICE_WIN32, SERVICE_STATE_ALL, &info, _EnumerateInstances);
}

_Return_type_success_(return != 0) BOOL CALLBACK CNTService::_EnumerateInstances(_In_opt_ void* pData, _In_ ENUM_SERVICE_STATUS& ss)
{
	//Validate our parameters
	ATLASSERT(pData != nullptr);

	_NTSERV_EnumerateInstancesInfo* pInfo = static_cast<_NTSERV_EnumerateInstancesInfo*>(pData);
	ATLASSUME(pInfo != nullptr);
	ATLASSUME(pInfo->pManager != nullptr);
	ATLASSUME(pInfo->psAppPath != nullptr);
	ATLASSUME(pInfo->pServiceNames != nullptr);

	//Open up the service to get its configuration
	CNTScmService service;
	if (pInfo->pManager->OpenService(ss.lpServiceName, SERVICE_QUERY_CONFIG, service))
	{
		//Now that we have the service opened, query it configuration to get its binary path name
		LPQUERY_SERVICE_CONFIG pServiceConfig = nullptr;
		if (service.QueryConfig(pServiceConfig))
		{
			ATLASSUME(pServiceConfig != nullptr);

			//If the binary path in the SCM contains our path, then add this found service to the instance array
			CNTServiceString sBinaryPath(pServiceConfig->lpBinaryPathName);
#ifdef CNTSERVICE_MFC_EXTENSIONS
			sBinaryPath.MakeUpper();
			if (sBinaryPath.Find(*pInfo->psAppPath) != -1)
#else
			std::transform(sBinaryPath.begin(), sBinaryPath.end(), sBinaryPath.begin(), [](TCHAR c) -> TCHAR { return static_cast<TCHAR>(_totupper(c)); });
			if (sBinaryPath.find(*pInfo->psAppPath) != CNTServiceString::npos)
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			{
#ifdef CNTSERVICE_MFC_EXTENSIONS
				pInfo->pServiceNames->Add(ss.lpServiceName);
#else
				pInfo->pServiceNames->push_back(ss.lpServiceName);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			}
		}
		else
			ATLTRACE(_T("CNTService::_EnumerateInstances, Failed to query service configuration, Service:%s\n"), ss.lpServiceName);

		//Tidy up any used heap memory
		if (pServiceConfig != nullptr)
			delete [] pServiceConfig;
	}
	else
		ATLTRACE(_T("CNTService::_EnumerateInstances, Failed to open service, Service:%s\n"), ss.lpServiceName);

	//Always continue enumeration
	return TRUE;
}

_Return_type_success_(return != 0) BOOL CNTService::Uninstall(_Inout_ CNTServiceString& sErrorMsg, _Inout_ DWORD& dwError, _In_ DWORD dwTimeToWaitForStop)
{
	//By default empty the error message 
	sErrorMsg = CNTServiceString();
	dwError = ERROR_SUCCESS;

	//Open up the SCM requesting connect rights
	CNTServiceControlManager manager;
	if (!manager.Open(nullptr, SC_MANAGER_CONNECT))
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_OPEN_SCM), dwError, FALSE);
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			CNTServiceString sError(Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_OPEN_SCM), dwError, TRUE));
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONNECT_SCM), sError);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONNECT_SCM), sError.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

	//Open up the existing service requesting deletion rights
	CNTScmService service;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (!manager.OpenService(m_sServiceName, DELETE | SERVICE_STOP | SERVICE_QUERY_STATUS, service))
#else
	if (!manager.OpenService(m_sServiceName.c_str(), DELETE | SERVICE_STOP | SERVICE_QUERY_STATUS, service))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_OPEN_SERVICE), dwError, FALSE);
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			CNTServiceString sError(Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_OPEN_SERVICE), dwError, TRUE));
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_OPEN_SERVICE), sError);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_OPEN_SERVICE), sError.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

	//Ask the service to stop if it is running
	SERVICE_STATUS status;
	if (service.QueryStatus(status) && status.dwCurrentState != SERVICE_STOPPED)
	{
		if (!service.Stop())
		{
			dwError = GetLastError();
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_STOP), dwError, FALSE);
			TraceMessage(sErrorMsg);
		}

		//Wait for the service to stop
		if (!service.WaitForStop(dwTimeToWaitForStop))
		{
			dwError = GetLastError();
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_WAIT_FOR_STOP), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

	//Delete the service from the SCM database
	if (!service.Delete())
	{
		dwError = GetLastError();
		sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_DELETE_SERVICE), dwError, FALSE);
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			CNTServiceString sError(Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_DELETE_SERVICE), dwError, TRUE));
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_DELETE_SERVICE), sError);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_DELETE_SERVICE), sError.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

	if (m_bEventLogSource)
	{
		//Remove this service as an event log source
#ifdef CNTSERVICE_MFC_EXTENSIONS
		if (!m_EventLogSource.Uninstall(m_EventLogSource.GetLogName(), m_EventLogSource.GetSourceName()))
#else
		if (!m_EventLogSource.Uninstall(m_EventLogSource.GetLogName().c_str(), m_EventLogSource.GetSourceName().c_str()))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		{
			dwError = GetLastError();
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_UNINSTALL_FAIL_UNINSTALL_EVENTLOG_SOURCE), dwError, FALSE);
			TraceMessage(sErrorMsg);
			return FALSE;
		}
	}

#ifdef CNTSERVICE_MFC_EXTENSIONS
	ATLTRACE(_T("CNTService::Uninstall, Service: %s was succesfully uninstalled\n"), m_sServiceName.GetString());
#else
	ATLTRACE(_T("CNTService::Uninstall, Service: %s was succesfully uninstalled\n"), m_sServiceName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	return TRUE;
}

_Return_type_success_(return != 0) BOOL CNTService::SetServiceToStatus(_In_ ServiceAction esaStatusWanted, _Inout_ DWORD& dwError, _In_ DWORD dwTimeout, _In_ DWORD dwPollingInterval)
{
	//Initialize the output parameter to default value.
	dwError = ERROR_SUCCESS;

	DWORD dwStatusWanted = 0;
	DWORD dwRightNeeded = 0;

	switch (esaStatusWanted) 
	{
	case ActionStartService:
		{
			dwStatusWanted = SERVICE_RUNNING;
			dwRightNeeded = SERVICE_START;
			break;
		}
	case ActionPauseService:
		{
			dwStatusWanted = SERVICE_PAUSED;
			dwRightNeeded = SERVICE_PAUSE_CONTINUE;
			break;
		}
	case ActionContinueService:
		{
			dwStatusWanted = SERVICE_RUNNING;
			dwRightNeeded = SERVICE_PAUSE_CONTINUE;
			break;
		}
	case ActionStopService:
		{
			dwStatusWanted = SERVICE_STOPPED;
			dwRightNeeded = SERVICE_STOP;
			break;
		}
	default:
		{
			ATLASSERT(FALSE);  //unknown status wanted
			break;
		}
	}

	//Open up the SCM requesting connect rights
	CNTServiceControlManager manager;
	if (!manager.Open(nullptr, SC_MANAGER_CONNECT))
	{
		dwError = GetLastError();
		CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_OPEN_SCM), dwError, FALSE));
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_OPEN_SCM), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONNECT_SCM), sErrorMsg);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONNECT_SCM), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

	//Open up the existing service requesting the necessary rights
	CNTScmService service;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (!manager.OpenService(m_sServiceName, dwRightNeeded | SERVICE_QUERY_STATUS, service))
#else
	if (!manager.OpenService(m_sServiceName.c_str(), dwRightNeeded | SERVICE_QUERY_STATUS, service))
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		dwError = GetLastError();
		CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_OPEN_SERVICE), dwError, FALSE));
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_OPEN_SERVICE), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_OPEN_SERVICE), sErrorMsg);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_OPEN_SERVICE), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

	//Ask the service to change to the requested status if it is not already in that status
	SERVICE_STATUS status;
	if (service.QueryStatus(status))
	{
		if (status.dwCurrentState != dwStatusWanted)
		{
			BOOL bSuccess = FALSE;
			switch (esaStatusWanted) 
			{
			case ActionStartService:
				{
					bSuccess = service.Start(0, nullptr);
					if (!bSuccess)
					{
						dwError = GetLastError();
						CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_START), dwError, FALSE));
						TraceMessage(sErrorMsg);
						if (m_bEventLogSource)
						{
							sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_START), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_START), sErrorMsg);
#else
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_START), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
						}
					}
					break;
				}
			case ActionPauseService:
				{
					bSuccess = service.Pause();
					if (!bSuccess)
					{
						dwError = GetLastError();
						CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_PAUSE), dwError, FALSE));
						TraceMessage(sErrorMsg);
						if (m_bEventLogSource)
						{
							sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_PAUSE), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_PAUSE), sErrorMsg);
#else
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_PAUSE), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
						}
					}
					break;
				}
			case ActionContinueService:
				{
					bSuccess = service.Continue();
					if (!bSuccess)
					{
						dwError = GetLastError();
						CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_CONTINUE), dwError, FALSE));
						TraceMessage(sErrorMsg);
						if (m_bEventLogSource)
						{
							sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_CONTINUE), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONTINUE), sErrorMsg);
#else
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CONTINUE), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
						}
					}
					break;
				}
			case ActionStopService:
				{
					bSuccess = service.Stop();
					if (!bSuccess)
					{
						dwError = GetLastError();
						CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_STOP), dwError, FALSE));
						TraceMessage(sErrorMsg);
						if (m_bEventLogSource)
						{
							sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_STOP), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_STOP), sErrorMsg);
#else
							m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_STOP), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
						}
					}
					break;
				}
			default:
				{
					ATLASSERT(FALSE);
					break;
				}
			}

			if (!bSuccess)
				return FALSE;
		}

		//Wait for the service to have the status wanted
		if (!service.WaitForServiceStatus(dwTimeout, dwStatusWanted, dwPollingInterval))
		{
			dwError = GetLastError();
			CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_WAITFORCHANGE), dwError, FALSE));
			TraceMessage(sErrorMsg);
			if (m_bEventLogSource)
			{
				sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_WAITFORCHANGE), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
				m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CHANGE_STATE), sErrorMsg, dwStatusWanted, FALSE);
#else
				m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_CHANGE_STATE), sErrorMsg.c_str(), dwStatusWanted, FALSE);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			}

			return FALSE;
		}
	}
	else
	{
		dwError = GetLastError();
		CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_QUERYSTATUS), dwError, FALSE));
		TraceMessage(sErrorMsg);
		if (m_bEventLogSource)
		{
			sErrorMsg = Win32ErrorToString(MapResourceID(IDS_NTSERV_SETSERVICETOSTATUS_FAIL_QUERYSTATUS), dwError, TRUE);
#ifdef CNTSERVICE_MFC_EXTENSIONS
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_QUERY_STATUS), sErrorMsg);
#else
			m_EventLogSource.Report(EVENTLOG_ERROR_TYPE, MapMessageID(CNTS_MSG_SERVICE_FAIL_QUERY_STATUS), sErrorMsg.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
		return FALSE;
	}

#ifdef CNTSERVICE_MFC_EXTENSIONS
	ATLTRACE(_T("CNTService::SetServiceToStatus, Service: %s status was successfully set\n"), m_sServiceName.GetString());
#else
	ATLTRACE(_T("CNTService::SetServiceToStatus, Service: %s status was successfully set\n"), m_sServiceName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	return TRUE;
}
void CNTService::LogEvent(_In_z_ LPCTSTR lpszStrings)
{
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_CONTINUED, lpszStrings);
}
void CNTService::Debug()
{
	//Runing as EXE not as service, just execute the services
	//SeviceMain function. 

	//Note we pass in all parameters except for the "-debug" 
	//string which brought us here.
	DWORD argc = 0;
	ATL::CHeapPtr<LPTSTR> pArgv;
	if (!pArgv.Allocate(__argc))
		TerminateService(ERROR_OUTOFMEMORY, 0);

	for (int n=0; n<__argc; ++n)
	{
		if (_tcsicmp(__targv[n], _T("-debug")) && _tcsicmp(__targv[n], _T("/debug")) && 
			_tcsicmp(__targv[n], _T("-app")) && _tcsicmp(__targv[n], _T("/app")) &&
			_tcsicmp(__targv[n], _T("-application")) && _tcsicmp(__targv[n], _T("/application")) &&
			_tcsicmp(__targv[n], _T("-console")) && _tcsicmp(__targv[n], _T("/console")))
			pArgv.m_pData[argc++] = __targv[n];
	}

	//Register the console handler to allow the console to generate requests to simulate stopping the service
	SetConsoleCtrlHandler(_ConsoleCtrlHandler, TRUE);

	//Now simply call ServiceMain with out modified set of parameters
	ServiceMain(argc, pArgv);
}

void CNTService::ShowHelp()
{
	//Default behaviour is to do nothing. In your service application, you should override this function 
	//to either display something	helpful to the console or if the service is running in the GUI subsystem, 
	//to display a messagebox or dialog to provide info about your service.
}

//Based upon the function of the same name in CWinApp
void CNTService::ParseCommandLine(_In_ CNTServiceCommandLineInfo& rCmdInfo)
{
	for (int i=1; i<__argc; i++)
	{
#ifdef _UNICODE
		LPCTSTR pszParam = __wargv[i];
#else
		LPCTSTR pszParam = __argv[i];
#endif //#ifdef _UNICODE
		BOOL bFlag = FALSE;
		BOOL bLast = ((i + 1) == __argc);
		if (pszParam[0] == _T('-') || pszParam[0] == _T('/'))
		{
			// remove flag specifier
			bFlag = TRUE;
			++pszParam;
		}
		rCmdInfo.ParseParam(pszParam, bFlag, bLast);
	}
}

//Callback function to handle console control signals
_Return_type_success_(return != 0) BOOL WINAPI CNTService::_ConsoleCtrlHandler(_In_ DWORD dwCtrlType)
{
	//Validate our parameters
	ATLASSUME(sm_pService != nullptr);

	//Convert from the SDK world to the C++ world
	return sm_pService->ConsoleCtrlHandler(dwCtrlType);
}

_Return_type_success_(return != 0) BOOL CNTService::ConsoleCtrlHandler(_In_ DWORD dwCtrlType)
{
	//If the event is a shutdown event then call the OnStop virtual method
	if (dwCtrlType == CTRL_C_EVENT || dwCtrlType == CTRL_BREAK_EVENT || dwCtrlType == CTRL_CLOSE_EVENT)
	{
		sm_pService->OnStop();
		return TRUE;
	}
	else
		return FALSE;
}

void CNTService::DisplayMessage(_In_ const CNTServiceString& sMessage)
{
	if (m_bUseConsole)
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		_tprintf(_T("%s\n"), sMessage.GetString());
#else
		_tprintf(_T("%s\n"), sMessage.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}
	else
	{
#ifdef CNTSERVICE_MFC_EXTENSIONS
		AfxMessageBox(sMessage);
#else
		MessageBox(nullptr, sMessage.c_str(), m_sDisplayName.c_str(), MB_OK | MB_ICONSTOP);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}
}

void CNTService::TraceMessage(_In_opt_z_ LPCTSTR pszMessage)
{
#ifdef _DEBUG
	ATLTRACE(_T("%s\n"), pszMessage);
#else
	UNREFERENCED_PARAMETER(pszMessage);
#endif //#ifdef _DEBUG
}

void CNTService::TraceMessage(_In_ const CNTServiceString& sMessage)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	TraceMessage(sMessage.GetString());
#else
	TraceMessage(sMessage.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

void CNTService::FormatString(_In_ CNTServiceString& sMsg, _In_ UINT nIDS, _In_z_ LPCTSTR psz1)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	AfxFormatString1(sMsg, nIDS, psz1);
#else
	TCHAR szResource[4096];
	szResource[0] = _T('\0');
	LoadString(GetModuleHandle(nullptr), nIDS, szResource, sizeof(szResource)/sizeof(TCHAR));
	sMsg = szResource;
	CNTServiceString::size_type nFind = sMsg.find(_T("%1"));
	if (nFind != CNTServiceString::npos)
		sMsg.replace(nFind, 2, psz1);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

void CNTService::FormatString(_In_ CNTServiceString& sMsg, _In_ UINT nIDS, _In_z_ LPCTSTR psz1, _In_z_ LPCTSTR psz2)
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	AfxFormatString2(sMsg, nIDS, psz1, psz2);
#else
	TCHAR szResource[4096];
	szResource[0] = _T('\0');
	LoadString(GetModuleHandle(nullptr), nIDS, szResource, sizeof(szResource)/sizeof(TCHAR));
	sMsg = szResource;
	CNTServiceString::size_type nFind = sMsg.find(_T("%1"));
	if (nFind != CNTServiceString::npos)
		sMsg.replace(nFind, 2, psz1);
	nFind = sMsg.find(_T("%2"));
	if (nFind != CNTServiceString::npos)
		sMsg.replace(nFind, 2, psz2);
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

//Based upon the function of the same name in CWinApp
DWORD CNTService::ProcessShellCommand(_In_ CNTServiceCommandLineInfo& rCmdInfo)
{
	//Update the service name if allowed and provided on the command line
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_bAllowNameChange && rCmdInfo.m_sServiceName.GetLength())
#else
	if (m_bAllowNameChange && rCmdInfo.m_sServiceName.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_sServiceName = rCmdInfo.m_sServiceName;

	//Update the display name if allowed and provided on the command line
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_bAllowDisplayNameChange && rCmdInfo.m_sServiceDisplayName.GetLength())
#else
	if (m_bAllowDisplayNameChange && rCmdInfo.m_sServiceDisplayName.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	{
		m_sDisplayName = rCmdInfo.m_sServiceDisplayName;

		//Also by default update the event log source name 
#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_EventLogSource.SetSourceName(m_sDisplayName);
#else
		m_EventLogSource.SetSourceName(m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	}

	//Update the description string if allowed and provided on the command line
#ifdef CNTSERVICE_MFC_EXTENSIONS
	if (m_bAllowDescriptionChange && rCmdInfo.m_sServiceDescription.GetLength())
#else
	if (m_bAllowDescriptionChange && rCmdInfo.m_sServiceDescription.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		m_sDescription = rCmdInfo.m_sServiceDescription;

	//What will be the return value from this function
	DWORD dwError = ERROR_SUCCESS;

	switch (rCmdInfo.m_nShellCommand)
	{
	case CNTServiceCommandLineInfo::RunAsService:
		{
			if (!Run())
				dwError = GetLastError();
			break;
		}
	case CNTServiceCommandLineInfo::StartTheService:
		{
			//Display the error message if the install failed
			if (!SetServiceToStatus(ActionStartService, dwError, rCmdInfo.m_dwTimeout))
			{
				CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_FAIL_START_SERVICE), dwError, FALSE));
				if (!rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			break;
		}
	case CNTServiceCommandLineInfo::PauseService:
		{
			//Display the error message if the install failed
			if (!SetServiceToStatus(ActionPauseService, dwError, rCmdInfo.m_dwTimeout))
			{
				CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_FAIL_PAUSE_SERVICE), dwError, FALSE));
				if (!rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			break;
		}
	case CNTServiceCommandLineInfo::ContinueService:
		{
			//Display the error message if the install failed
			if (!SetServiceToStatus(ActionContinueService, dwError, rCmdInfo.m_dwTimeout))
			{
				CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_FAIL_CONTINUE_SERVICE), dwError, FALSE));
				if (!rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			break;
		}
	case CNTServiceCommandLineInfo::StopService:
		{
			//Display the error message if the install failed
			if (!SetServiceToStatus(ActionStopService, dwError, rCmdInfo.m_dwTimeout))
			{
				CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_FAIL_STOP_SERVICE), dwError, FALSE));
				if (!rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			break;
		}
	case CNTServiceCommandLineInfo::InstallService:
		{
			//Form the command line options which we use for the command line when 
			//registering the service
			CNTServiceString sCommandLine;

			//First get the full path of this exe
			TCHAR szAppPath[_MAX_PATH];
			szAppPath[0] = _T('\0');
			if (GetModuleFileName(nullptr, szAppPath, _MAX_PATH))
			{
				m_sBinaryPathName = szAppPath;

				//Always ensure the sevice path is quoted if there are spaces in it
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (m_sBinaryPathName.Find(_T(' ')) != -1)
#else
				if (m_sBinaryPathName.find(_T(' ')) != CNTServiceString::npos)
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
					m_sBinaryPathName = _T('\"') + m_sBinaryPathName + _T('\"');

				//Add in the pertinent options we have already parsed from the command line
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (m_bAllowNameChange && rCmdInfo.m_sServiceName.GetLength())
#else
				if (m_bAllowNameChange && rCmdInfo.m_sServiceName.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					TCHAR szName[2048];
#ifdef CNTSERVICE_MFC_EXTENSIONS
					_stprintf_s(szName, sizeof(szName)/sizeof(TCHAR), _T(" \"/SN:%s\""), rCmdInfo.m_sServiceName.GetString());
#else
					_stprintf_s(szName, sizeof(szName)/sizeof(TCHAR), _T(" \"/SN:%s\""), rCmdInfo.m_sServiceName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
					m_sBinaryPathName += szName;
				}
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (m_bAllowDisplayNameChange && rCmdInfo.m_sServiceDisplayName.GetLength())
#else
				if (m_bAllowDisplayNameChange && rCmdInfo.m_sServiceDisplayName.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					TCHAR szDisplayName[2048];
#ifdef CNTSERVICE_MFC_EXTENSIONS
					_stprintf_s(szDisplayName, sizeof(szDisplayName)/sizeof(TCHAR), _T(" \"/SDN:%s\""), rCmdInfo.m_sServiceDisplayName.GetString());
#else
					_stprintf_s(szDisplayName, sizeof(szDisplayName)/sizeof(TCHAR), _T(" \"/SDN:%s\""), rCmdInfo.m_sServiceDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
					m_sBinaryPathName += szDisplayName;
				}
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (m_bAllowDescriptionChange && rCmdInfo.m_sServiceDescription.GetLength())
#else
				if (m_bAllowDescriptionChange && rCmdInfo.m_sServiceDescription.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					TCHAR szDescription[2048];
#ifdef CNTSERVICE_MFC_EXTENSIONS
					_stprintf_s(szDescription, sizeof(szDescription)/sizeof(TCHAR), _T(" \"/SD:%s\""), rCmdInfo.m_sServiceDescription.GetString());
#else
					_stprintf_s(szDescription, sizeof(szDescription)/sizeof(TCHAR), _T(" \"/SD:%s\""), rCmdInfo.m_sServiceDescription.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
					m_sBinaryPathName += szDescription;
				}

				//If a service command line is used, then use it for registration
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (m_bAllowCommandLine && rCmdInfo.m_sServiceCommandLine.GetLength())
#else
				if (m_bAllowCommandLine && rCmdInfo.m_sServiceCommandLine.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					m_sBinaryPathName += _T(" ");
					m_sBinaryPathName += rCmdInfo.m_sServiceCommandLine;
				}

				//If a username was specified, then use it for registration
				BOOL bHaveUserName = FALSE;
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (rCmdInfo.m_sUserName.GetLength())
#else
				if (rCmdInfo.m_sUserName.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					bHaveUserName = TRUE;
					m_sUserName = rCmdInfo.m_sUserName;

					//As a security precaution nuke the command line copy of the username now that we have used it
					SecureEmptyString(rCmdInfo.m_sUserName);
				}

				//If a password was specified, then use it for registration
#ifdef CNTSERVICE_MFC_EXTENSIONS
				if (rCmdInfo.m_sPassword.GetLength())
#else
				if (rCmdInfo.m_sPassword.length())
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				{
					m_sPassword = rCmdInfo.m_sPassword;

					//As a security precaution nuke the command line copy of the username now that we have used it
					SecureEmptyString(rCmdInfo.m_sPassword);
				}

				//Should the service be started automatically
				if (rCmdInfo.m_bAutoStart)
					m_dwStartType = SERVICE_AUTO_START;

				//Display the error message if the enable of the service logon right failed
				CNTServiceString sErrorMsg;
				if (bHaveUserName && rCmdInfo.m_bEnableServiceLogonRight && !EnableServiceLogonRight(sErrorMsg, dwError) && !rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);

				//Display the error message if the install failed
				if ((dwError == ERROR_SUCCESS) && !Install(sErrorMsg, dwError) && !rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			else
			{
				CNTServiceString sErrorMsg(Win32ErrorToString(MapResourceID(IDS_NTSERV_FAIL_GET_MODULE_FILENAME), dwError, FALSE));
				if (!rCmdInfo.m_bSilent)
					DisplayMessage(sErrorMsg);
			}
			break;
		}
	case CNTServiceCommandLineInfo::UninstallService:
		{
			//Display the error message if the uninstall failed
			CNTServiceString sErrorMsg;
			if (!Uninstall(sErrorMsg, dwError, rCmdInfo.m_dwTimeout) && !rCmdInfo.m_bSilent)
				DisplayMessage(sErrorMsg);
			break;
		}
	case CNTServiceCommandLineInfo::DebugService:
		{
			try
			{
				Debug();
			}
			catch(CNTServiceTerminateException& e)
			{
				dwError = e.m_dwWin32ExitCode;
			}

			break;
		}
	case CNTServiceCommandLineInfo::ShowServiceHelp:
		{
			ShowHelp();
			break;
		}
	default:
		{
			ATLASSERT(FALSE);
			break;
		}
	}

	return dwError;
}

CNTServiceString CNTService::GetErrorMessage(_In_ DWORD dwError)
{
	//What will be the return value from this function
	CNTServiceString sError;

	//Look up the error description using FormatMessage
	LPTSTR pBuffer = nullptr;
	if (FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		nullptr, dwError, MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT), reinterpret_cast<LPTSTR>(&pBuffer), 0, nullptr) != 0)
	{
		sError = pBuffer;
		LocalFree(pBuffer);
	}

	return sError;
}

CNTServiceString CNTService::Win32ErrorToString(_In_ UINT nStringID, _In_ DWORD dwError, _In_ BOOL bEventLog)
{
	//What will be the return value from this function
	CNTServiceString sMsg;

	if (bEventLog)
	{
		switch (m_ELLoggingDetail)
		{
		case EL_ErrorCode:
			{
				TCHAR szTemp[32];
				_stprintf_s(szTemp, sizeof(szTemp)/sizeof(TCHAR), _T("%u"), dwError);
				sMsg = szTemp;
				break;
			}
		case EL_ErrorDescription:
			{
				sMsg = GetErrorMessage(dwError);
				break;
			}
		case EL_ErrorCodeAndErrorDescription:
			{
				CNTServiceString sDescription(GetErrorMessage(dwError));

				TCHAR szErrorCode[32];
				_stprintf_s(szErrorCode, sizeof(szErrorCode)/sizeof(TCHAR), _T("%u"), dwError);

#ifdef CNTSERVICE_MFC_EXTENSIONS
				FormatString(sMsg, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szErrorCode, sDescription);
#else
				FormatString(sMsg, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szErrorCode, sDescription.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				break;
			}
		default:
			{
				ATLASSERT(FALSE);
				break;
			}
		}
	}
	else
	{
		switch (m_UILoggingDetail)
		{
		case UI_ErrorCode:
			{
				TCHAR szTemp[32];
				szTemp[0] = _T('\0');
				_stprintf_s(szTemp, sizeof(szTemp)/sizeof(TCHAR), _T("%u"), dwError);
				sMsg = szTemp;
				break;
			}
		case UI_ErrorDescription:
			{
				sMsg = GetErrorMessage(dwError);
				break;
			}
		case UI_ErrorCodeAndErrorDescription:
			{
				CNTServiceString sDescription(GetErrorMessage(dwError));

				TCHAR szErrorCode[32];
				szErrorCode[0] = _T('\0');
				_stprintf_s(szErrorCode, sizeof(szErrorCode)/sizeof(TCHAR), _T("%u"), dwError);
#ifdef CNTSERVICE_MFC_EXTENSIONS
				FormatString(sMsg, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szErrorCode, sDescription);
#else
				FormatString(sMsg, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szErrorCode, sDescription.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				break;
			}
		case UI_StringAndErrorCode:
			{
				TCHAR szError[32];
				szError[0] = _T('\0');
				_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%u"), dwError);

				FormatString(sMsg, nStringID, szError);
				break;
			}
		case UI_StringAndErrorDescription:
			{
				CNTServiceString sDescription(GetErrorMessage(dwError));

#ifdef CNTSERVICE_MFC_EXTENSIONS
				FormatString(sMsg, nStringID, sDescription);
#else
				FormatString(sMsg, nStringID, sDescription.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				break;
			}
		case UI_StringAndErrorCodeAndErrorDescription:
			{
				CNTServiceString sDescription(GetErrorMessage(dwError));

				TCHAR szError[32];
				szError[0] = _T('\0');
				_stprintf_s(szError, sizeof(szError)/sizeof(TCHAR), _T("%u"), dwError);

				CNTServiceString sErrorAndDescription;
#ifdef CNTSERVICE_MFC_EXTENSIONS
				FormatString(sErrorAndDescription, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szError, sDescription);
				FormatString(sMsg, nStringID, sErrorAndDescription);
#else
				FormatString(sErrorAndDescription, MapResourceID(IDS_NTSERV_VERBOSE_ERROR_STRING), szError, sDescription.c_str());
				FormatString(sMsg, nStringID, sErrorAndDescription.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
				break;
			}
		default:
			{
				ATLASSERT(FALSE);
				break;
			}
		}
	}

	return sMsg;
}

UINT CNTService::MapResourceID(_In_ UINT nID)
{
	//Just return the same value as what was asked for. Derived classes can customize the values 
	//for their own use
	return nID;
}

UINT CNTService::MapMessageID(_In_ UINT nID)
{
	//Just return the same value as what was asked for. Derived classes can customize the values 
	//for their own use
	return nID;
}

_Return_type_success_(return != 0) BOOL CNTService::QueryServiceDynamicInformation(_In_ DWORD dwInfoLevel, _Outptr_ PVOID* ppDynamicInfo)
{
	//Check to see if the function pointer is available
	if (m_pfnQueryServiceDynamicInformation == nullptr)
	{
		ATLTRACE(_T("CNTService::EnumServices,QueryServiceDynamicInformation function is not supported on this OS. You need to be running at least Windows 8 / Windows Server 2012 to use this function\n"));
		SetLastError(ERROR_CALL_NOT_IMPLEMENTED);
		return FALSE;
	}

	//Call through the function pointer
	return m_pfnQueryServiceDynamicInformation(m_hStatus, dwInfoLevel, ppDynamicInfo);
}