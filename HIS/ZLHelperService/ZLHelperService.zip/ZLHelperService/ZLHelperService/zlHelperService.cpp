////////////////////////////// Includes ///////////////////////////////////////

#include "stdafx.h"
#include "ntserv_msg.h"
#include "ntservEventLog.h"
#include "zlHelperService.h"


/////////////////////////////////  Macros /////////////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG

//The one and only one application
CWinApp theApp;
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Implementation //////////////////////////////

#ifdef _DEBUG
BOOL CALLBACK EnumServices(void* /*pData*/, ENUM_SERVICE_STATUS& Service)
#else
BOOL CALLBACK EnumServices(void* /*pData*/, ENUM_SERVICE_STATUS& /*Service*/)
#endif //#ifdef _DEBUG
{
#ifdef _DEBUG
	ATLTRACE(_T("Service name is %s\n"), Service.lpServiceName);
	ATLTRACE(_T("Friendly name is %s\n"), Service.lpDisplayName);
#endif //#ifdef _DEBUG

	return TRUE; //continue enumeration
}

#ifdef _DEBUG
BOOL CALLBACK EnumServices2(void* /*pData*/, ENUM_SERVICE_STATUS_PROCESS& ssp)
#else
BOOL CALLBACK EnumServices2(void* /*pData*/, ENUM_SERVICE_STATUS_PROCESS& /*ssp*/)
#endif
{
#ifdef _DEBUG
	ATLTRACE(_T("Service name is %s\n"), ssp.lpServiceName);
	ATLTRACE(_T("Friendly name is %s\n"), ssp.lpDisplayName);
#endif

	return TRUE; //continue enumeration
}

VOID CALLBACK NotificationCallback(_In_ DWORD /*dwNotify*/, _In_opt_ PVOID /*pCallbackContext*/)
{
}


int _tmain(int /*argc*/, TCHAR* /*argv*/[], TCHAR* /*envp*/[])
{
#ifdef CNTSERVICE_MFC_EXTENSIONS
	//Don't forget to explicitly initialize MFC, since we are in a console app (Note we must put up with some /analyze warnings for AfxWinInit even in VC 2008)
	if (!AfxWinInit(::GetModuleHandle(nullptr), nullptr, ::GetCommandLine(), 0))
		return 1;
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

#ifdef _DEBUG
	DWORD dwError = 0;
	zlHelperService testService;
	UINT nValue = testService.GetProfileInt(_T("General"), _T("IntValue"), 33, &dwError);
	CNTServiceString sValue = testService.GetProfileString(_T("General"), _T("StringValue"), _T("DefaultValue"), &dwError);

	BOOL bSuccess = testService.WriteProfileInt(_T("General"), _T("IntValue"), 37);
	bSuccess = testService.WriteProfileString(_T("General"), _T("StringValue"), _T("Test Value"));

	nValue = testService.GetProfileInt(_T("General"), _T("IntValue"), 33, &dwError);
	sValue = testService.GetProfileString(_T("General"), _T("StringValue"), nullptr, &dwError);

	CNTServiceStringArray array;
#ifdef CNTSERVICE_MFC_EXTENSIONS
	array.Add(_T("First String"));
	array.Add(_T("Second and Last String"));
#else
	array.push_back(_T("First String"));
	array.push_back(_T("Second and Last String"));
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	bSuccess = testService.WriteProfileStringArray(_T("General"), _T("StringArrayValue"), array);
	bSuccess = testService.GetProfileStringArray(_T("General"), _T("StringArrayValue"), array);
	bSuccess = testService.GetProfileStringArray(_T("General"), _T("Does Not Exist"), array);

	BYTE* pSetData = new BYTE[10];
	for (int i=0; i<10; i++)
		pSetData[i] = static_cast<BYTE>(i);
	bSuccess = testService.WriteProfileBinary(_T("General"), _T("BinaryValue"), pSetData, 10);
	delete [] pSetData;

#ifdef CNTSERVICE_MFC_EXTENSIONS
	array.SetSize(0);
#else
	array.clear();
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
	bSuccess = testService.GetProfileStringArray(_T("General"), _T("StringArrayValue"), array); 

	BYTE* pGetData = nullptr;
	ULONG nBytes = 0;
	bSuccess = testService.GetProfileBinary(_T("General"), _T("BinaryValue"), &pGetData, &nBytes);
	if (bSuccess)
	{
		delete [] pGetData;
	}

	testService.WriteProfileString(_T("General"), _T("BinaryValue"), nullptr);
	testService.WriteProfileString(_T("General"), nullptr, nullptr);
#endif //#ifdef _DEBUG

#ifdef _DEBUG
	{
		zlHelperService testService2;
		CNTServiceStringArray instances;
		DWORD dwError2 = 0;
		if (testService2.EnumerateInstances(instances, dwError2))
		{
#ifdef CNTSERVICE_MFC_EXTENSIONS
			for (int i=0; i<instances.GetSize(); i++)
				ATLTRACE(_T("Found instance, %s\n"), instances[i].GetString());
#else
			for (CNTServiceStringArray::size_type i=0; i<instances.size(); i++)
				ATLTRACE(_T("Found instance, %s\n"), instances[i].c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
		}
	}
#endif //#ifdef _DEBUG

#ifdef _DEBUG
	CNTServiceControlManager manager;
	SC_HANDLE hScm = manager;
	BOOL bSuccess2 = manager.Open(nullptr, SC_MANAGER_CONNECT | SC_MANAGER_QUERY_LOCK_STATUS | SC_MANAGER_ENUMERATE_SERVICE | SC_MANAGER_LOCK); //We only need SC_MANAGER_CONNECT, SC_MANAGER_LOCK_STATUS and SC_MANAGER_LOCK access here
	if (bSuccess2)
	{
		hScm = manager;
		LPQUERY_SERVICE_LOCK_STATUS pLockStatus = nullptr;
		bSuccess2 = manager.QueryLockStatus(pLockStatus);
		if (bSuccess2)
		{
			BOOL bIsLocked = (pLockStatus->fIsLocked != 0);
			UNREFERENCED_PARAMETER(bIsLocked);
			LPCTSTR pszOwner = pLockStatus->lpLockOwner;
			UNREFERENCED_PARAMETER(pszOwner);
			DWORD dwDuration = pLockStatus->dwLockDuration;
			UNREFERENCED_PARAMETER(dwDuration);
		}
		if (pLockStatus)
			delete [] reinterpret_cast<BYTE*>(pLockStatus);
		bSuccess2 = manager.Lock();
		bSuccess2 = manager.Unlock();
		pLockStatus = nullptr;
		bSuccess2 = manager.QueryLockStatus(pLockStatus);
		if (bSuccess2)
		{
			BOOL bIsLocked = (pLockStatus->fIsLocked != 0);
			UNREFERENCED_PARAMETER(bIsLocked);
			LPCTSTR pszOwner = pLockStatus->lpLockOwner;
			UNREFERENCED_PARAMETER(pszOwner);
			DWORD dwDuration = pLockStatus->dwLockDuration;
			UNREFERENCED_PARAMETER(dwDuration);
		}
		if (pLockStatus != nullptr)
			delete [] reinterpret_cast<BYTE*>(pLockStatus);
		bSuccess2 = manager.EnumServices(SERVICE_WIN32, SERVICE_STATE_ALL, 0, EnumServices);
		bSuccess2 = manager.EnumServices(SERVICE_WIN32, SERVICE_STATE_ALL, nullptr, 0, EnumServices2);

		CNTScmService service;
		SC_HANDLE hService = service;
		bSuccess2 = manager.OpenService(_T("ZLHelperService"), SERVICE_START | SERVICE_QUERY_STATUS | SERVICE_QUERY_CONFIG | SERVICE_ENUMERATE_DEPENDENTS, service); //Use only the required access rights we need
		if (bSuccess2)
		{
			hService = service;
			//bSuccess2 = service.Start(0, nullptr);
			//Sleep(4000);
			//bSuccess2 = service.Control(128);
			//bSuccess2 = service.Pause();
			//Sleep(4000);
			//bSuccess2 = service.Continue();
			bSuccess2 = service.Stop();
			LPQUERY_SERVICE_CONFIG pServiceConfig = nullptr;
			bSuccess2 = service.QueryConfig(pServiceConfig);
			if (bSuccess2)
			{
				ATLTRACE(_T("dwServiceType is %d\n"),      pServiceConfig->dwServiceType);
				ATLTRACE(_T("dwStartType is %d\n"),        pServiceConfig->dwStartType);
				ATLTRACE(_T("dwErrorControl is %d\n"),     pServiceConfig->dwErrorControl);
				ATLTRACE(_T("lpBinaryPathName is %s\n"),   pServiceConfig->lpBinaryPathName);
				ATLTRACE(_T("lpLoadOrderGroup is %s\n"),   pServiceConfig->lpLoadOrderGroup);
				ATLTRACE(_T("dwTagId is %d\n"),            pServiceConfig->dwTagId);
				ATLTRACE(_T("lpDependencies are %s\n"),    pServiceConfig->lpDependencies);
				ATLTRACE(_T("lpServiceStartName is %s\n"), pServiceConfig->lpServiceStartName);
				ATLTRACE(_T("lpDisplayName is %s\n"),      pServiceConfig->lpDisplayName);
			}
			if (pServiceConfig != nullptr)
				delete [] reinterpret_cast<BYTE*>(pServiceConfig);
			bSuccess2 = service.EnumDependents(SERVICE_STATE_ALL, 0, EnumServices);
			UNREFERENCED_PARAMETER(bSuccess2);

			PSECURITY_DESCRIPTOR pSecurityDescriptor = nullptr;
			bSuccess2 = service.QueryObjectSecurity(DACL_SECURITY_INFORMATION, pSecurityDescriptor);
			UNREFERENCED_PARAMETER(bSuccess2);
			if (pSecurityDescriptor != nullptr)
				delete [] reinterpret_cast<BYTE*>(pSecurityDescriptor);

			CNTServiceString sDescription;
			if (service.QueryDescription(sDescription))
				bSuccess2 = service.ChangeDescription(sDescription);

			DWORD dwPreShutdownTimeout = 0;
			if (service.QueryPreShutdown(dwPreShutdownTimeout))
				bSuccess2 = service.ChangePreShutdown(dwPreShutdownTimeout);

			LPSERVICE_FAILURE_ACTIONS pFailureActions = nullptr;
			bSuccess2 = service.QueryFailureActions(pFailureActions);
			UNREFERENCED_PARAMETER(bSuccess2);
			bSuccess2 = service.ChangeFailureActions(pFailureActions);
			if (pFailureActions)
				delete [] reinterpret_cast<BYTE*>(pFailureActions);

			bSuccess2 = service.ChangeDelayAutoStart(TRUE);
			BOOL bDelayedAutoStart;
			bSuccess2 = service.QueryDelayAutoStart(bDelayedAutoStart);
			UNREFERENCED_PARAMETER(bSuccess2);

			bSuccess2 = service.ChangeFailureActionsFlag(TRUE);
			BOOL bFailureActionsOnNonCrashFailures;
			bSuccess2 = service.QueryFailureActionsFlag(bFailureActionsOnNonCrashFailures);
			UNREFERENCED_PARAMETER(bSuccess2);

			bSuccess2 = service.ChangeSidInfo(3); //3 is SERVICE_SID_TYPE_RESTRICTED
			DWORD dwServiceSidType;
			bSuccess2 = service.QuerySidInfo(dwServiceSidType);
			UNREFERENCED_PARAMETER(bSuccess2);

			CNTServiceStringArray sPrivileges;
#ifdef CNTSERVICE_MFC_EXTENSIONS
			sPrivileges.Add(_T("SeIncreaseQuotaPrivilege"));
#else
			sPrivileges.push_back(_T("SeIncreaseQuotaPrivilege"));
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			bSuccess2 = service.ChangeRequiredPrivileges(sPrivileges);
			bSuccess2 = service.QueryRequiredPrivileges(sPrivileges);
			UNREFERENCED_PARAMETER(bSuccess2);

			bSuccess2 = service.ChangePreferredNode(2, FALSE);
			USHORT usPreferredNode;
			BOOL bDelete;
			bSuccess2 = service.QueryPreferredNode(usPreferredNode, bDelete);
			UNREFERENCED_PARAMETER(bSuccess2);

			bSuccess2 = service.ChangeLaunchProtected(SERVICE_LAUNCH_PROTECTED_NONE);
			DWORD dwLaunchProtected = 0;
			bSuccess2 = service.QueryLaunchProtected(dwLaunchProtected);
			UNREFERENCED_PARAMETER(bSuccess2);

			PSERVICE_TRIGGER_INFO pTriggerInfo = nullptr;
			bSuccess2 = service.QueryTrigger(pTriggerInfo);
			UNREFERENCED_PARAMETER(bSuccess2);
			bSuccess2 = service.ChangeTrigger(pTriggerInfo);
			if (pTriggerInfo)
				delete [] reinterpret_cast<BYTE*>(pTriggerInfo);

			SERVICE_CONTROL_STATUS_REASON_PARAMS scsrp;
			memset(&scsrp, 0, sizeof(scsrp));
			bSuccess2 = service.Control(SERVICE_STOP, SERVICE_CONTROL_STATUS_REASON_INFO, &scsrp);
			UNREFERENCED_PARAMETER(bSuccess2);

			SERVICE_STATUS_PROCESS ssp;
			bSuccess2 = service.QueryStatus(ssp);
			UNREFERENCED_PARAMETER(bSuccess2);

			//PSC_NOTIFICATION_REGISTRATION pRegistration = nullptr;
			//DWORD dwValue = service.SubscribeChangeNotifications(SC_EVENT_STATUS_CHANGE, NotificationCallback, nullptr, &pRegistration);
			//bSuccess2 = service.UnsubscribeChangeNotifications(pRegistration);
			//dwValue = service.WaitState(SERVICE_STOPPED, 1000, nullptr);
		}
	}
#endif //#ifdef _DEBUG

#ifdef _DEBUG
	CNTEventLog el;
	HANDLE hEventLog = el;
	BOOL bSuccess3 = el.OpenSecurity(nullptr);
	hEventLog = el;
	bSuccess3 = el.OpenSystem(nullptr);
	bSuccess3 = el.OpenApplication(nullptr);
	DWORD dwOldest;
	bSuccess3 = el.GetOldestRecord(dwOldest);
	bSuccess3 = el.Backup(_T("C:\\BACKUPLOG.TXT"));
	bSuccess3 = el.Close();
	bSuccess3 = el.OpenBackup(nullptr, _T("C:\\BACKUPLOG.TXT"));
	DWORD dwRecords;
	bSuccess3 = el.OpenSystem(nullptr);
	bSuccess3 = el.GetNumberOfRecords(dwRecords);
	ATLASSUME(bSuccess3);
	//bSuccess = el.Clear(nullptr);
	CEventLogRecord record;
	DWORD ii=0;
	while (ii<dwRecords)
	{
		bSuccess3 = el.ReadNext(record);
		ii++;
	}
	bSuccess3 = el.ReadPrev(record);
	DWORD dwFull;
	bSuccess3 = el.GetFullInformation(dwFull);
#endif //#ifdef _DEBUG

#ifdef _DEBUG
	CNTEventLogSource els(nullptr, _T("ZLSOFT Upgrade Helper Service"));
	LPCTSTR pString = _T("ZLSOFT Upgrade Helper Service");
	LPCTSTR* ppString = &pString;
	BOOL bSuccess4 = els.Register(nullptr, pString);
	bSuccess4 = els.Deregister();
	DWORD dwError2 = GetLastError();
	dwError2;
	bSuccess4 = els.Report(EVENTLOG_INFORMATION_TYPE, 0, CNTS_MSG_SERVICE_STARTED, nullptr, 1, 0, ppString, nullptr);
#endif //#ifdef _DEBUG

#ifdef _DEBUG
	//CNTEventLogSource els(nullptr, _T("ZLSOFT Upgrade Helper Service"));
	//LPCTSTR pString = _T("ZLSOFT Upgrade Helper Service");
	//LPCTSTR* ppString = &pString;
	//BOOL bSuccess4 = els.Register(nullptr, pString);
	//bSuccess4 = els.Deregister();
	//DWORD dwError2 = GetLastError();
	//dwError2;
	//bSuccess4 = els.Report(EVENTLOG_INFORMATION_TYPE, 0, CNTS_MSG_SERVICE_STARTED, nullptr, 1, 0, ppString, nullptr);
#endif //#ifdef _DEBUG
	//All that is required to get the service up and running
	CNTServiceCommandLineInfo cmdInfo;
	zlHelperService Service;
	Service.SetAllowCommandLine(TRUE);
	Service.SetAllowNameChange(TRUE);       
	Service.SetAllowDescriptionChange(TRUE);
	Service.SetAllowDisplayNameChange(TRUE);
	Service.ParseCommandLine(cmdInfo);
	return Service.ProcessShellCommand(cmdInfo);
}



zlHelperService::zlHelperService() : CNTService(_T("ZLHelperService"), _T("ZLSOFT Upgrade Helper Service"), SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE, _T("�����������ַ���")),
	m_lWantStop(FALSE),    //Simple boolean which is set to request the service to stop
	m_lPaused(FALSE),      //The boolean used to represent that the service is paused
	m_dwBeepInternal(1000) //The default beep interval of 1 second
{
	//For demonstration purposes, make this service dependent on Windows Audio. Please note that because of Session Isolation on Windows Vista and
	//later, when you start the "PJSERVICE" service, you will not hear any message beeps because the service is running in a different session

	//Uncomment the following code (or put it in the member variable initialization above) to setup the service with different requirements
	m_dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	m_dwStartType = SERVICE_AUTO_START;
	m_dwErrorControl = SERVICE_ERROR_NORMAL;
	//m_sUserName = _T(".\\auser");
	//m_sPassword = _T("apassword");
}

void zlHelperService::ServiceMain(DWORD /*dwArgc*/, LPTSTR* /*pszArgv*/)
{
	//Pretend that starting up takes some time
	ReportStatus(SERVICE_START_PENDING, 1, 1100);
	Sleep(1000);
	ReportStatus(SERVICE_RUNNING);

	//Report to the event log that the service has started successfully
#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_STARTED, m_sDisplayName);
#else
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_STARTED, m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS

	//The tight loop which constitutes the service
	long lOldPause = m_lPaused;
	while (!m_lWantStop)
	{
		//As a demo, we just do a message beep
		if (!m_lPaused){
			//��ȡ�ļ�·��
			if( m_file.empty()){
				m_file=CNTService::sm_pService->GetHelperMainFile(m_file);
			}
			if( !m_file.empty()){
				if (CNTService::sm_pService->IsFileExists(m_file.c_str()))
				{
					BOOL bRet=CNTService::sm_pService->RunExeInEverySession(m_file.c_str(),_T("ZLHelperMain.EXE"));
				}
			}
		}
		//Wait for the specified time
		Sleep(m_dwBeepInternal);

		//SCM has requested a Pause / Continue
		if (m_lPaused != lOldPause)
		{
			if (m_lPaused)
			{
				ReportStatus(SERVICE_PAUSED);

				//Report to the event log that the service has paused successfully
#ifdef CNTSERVICE_MFC_EXTENSIONS
				m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_PAUSED, m_sDisplayName);
#else
				m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_PAUSED, m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			}
			else
			{
				ReportStatus(SERVICE_RUNNING);

				//Report to the event log that the service has stopped continued
#ifdef CNTSERVICE_MFC_EXTENSIONS
				m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_CONTINUED, m_sDisplayName);
#else
				m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_CONTINUED, m_sDisplayName.c_str());        
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
			}
		}

		lOldPause = m_lPaused;
	}
	//�ر�����ZLHELPERMAIN����
	CNTService::sm_pService->KillExeInEverySession(_T("ZLHelperMain.EXE"));
	//Pretend that closing down takes some time
	ReportStatus(SERVICE_STOP_PENDING, 1, 1100);
	Sleep(1000);

	//Report to the event log that the service has stopped successfully
#ifdef CNTSERVICE_MFC_EXTENSIONS
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_STOPPED, m_sDisplayName);
#else
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, CNTS_MSG_SERVICE_STOPPED, m_sDisplayName.c_str());
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS
}

void zlHelperService::OnStop()
{
	//Signal the other thread to end via the boolean variable
	InterlockedExchange(&m_lWantStop, TRUE);
}

void zlHelperService::OnPause()
{
	//Signal the other thread via the boolean variable
	InterlockedExchange(&m_lPaused, TRUE);
}

void zlHelperService::OnContinue()
{
	//Signal the other thread to continue via the boolean variable
	InterlockedExchange(&m_lPaused, FALSE);
}

void zlHelperService::OnUserDefinedRequest(DWORD dwControl)
{
	//Any value greater than 200 increments the doubles the beep frequency
	//otherwise the frequency is halved
	if (dwControl > 200)
		m_dwBeepInternal /= 2;
	else
		m_dwBeepInternal *= 2;

	//Report to the event log that the beep interval has been changed
	TCHAR szInterval[32];
	_stprintf_s(szInterval, sizeof(szInterval)/sizeof(TCHAR), _T("%u"), m_dwBeepInternal);
	m_EventLogSource.Report(EVENTLOG_INFORMATION_TYPE, MSG_SERVICE_SET_FREQUENCY, szInterval);
}

void zlHelperService::ShowHelp()
{
	_tprintf(_T("�����������ַ���\nUsage: zlHelperService [ -install | -uninstall | -remove | -start | -pause | -continue | -stop | -help | -? ]\n"));
}