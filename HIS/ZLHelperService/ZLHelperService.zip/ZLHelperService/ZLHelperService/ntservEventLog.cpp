/*
Module : ntservEventLog.cpp
Purpose: ʵ��CNTEventLog�Ľӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
///////////////////////////////// Includes  ///////////////////////////////////

#include "stdafx.h"
#include "ntservEventlog.h"


///////////////////////////////// Macros //////////////////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Implementation //////////////////////////////

CNTEventLog::CNTEventLog() : m_hEventLog(nullptr)
{
}

CNTEventLog::~CNTEventLog()
{
	Close();
}

CNTEventLog::operator HANDLE() const
{
	return m_hEventLog;
}

_Return_type_success_(return != 0) BOOL CNTEventLog::Attach(_In_opt_ HANDLE hEventLog)
{
	if (m_hEventLog != hEventLog)
		Close();

	m_hEventLog = hEventLog;
	return TRUE;
}

HANDLE CNTEventLog::Detach()
{
	HANDLE hReturn = m_hEventLog;
	m_hEventLog = nullptr;
	return hReturn;
}

_Return_type_success_(return != 0) BOOL CNTEventLog::Open(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pSourceName)
{
	Close();
	m_hEventLog = OpenEventLog(pUNCServerName, pSourceName);
	return (m_hEventLog != nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::OpenApplication(_In_opt_ LPCTSTR pUNCServerName)
{
	return Open(pUNCServerName, _T("Application"));
}

_Return_type_success_(return != 0) BOOL CNTEventLog::OpenSystem(_In_opt_ LPCTSTR pUNCServerName)
{
	return Open(pUNCServerName, _T("System"));
}

_Return_type_success_(return != 0) BOOL CNTEventLog::OpenSecurity(_In_opt_ LPCTSTR pUNCServerName)
{
	return Open(pUNCServerName, _T("Security"));
}

_Return_type_success_(return != 0) BOOL CNTEventLog::OpenBackup(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pFileName)
{
	Close();
	m_hEventLog = OpenBackupEventLog(pUNCServerName, pFileName);
	return (m_hEventLog != nullptr);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::Close()
{
	BOOL bSuccess = TRUE;
	if (m_hEventLog != nullptr)
	{
		bSuccess = CloseEventLog(m_hEventLog);
		m_hEventLog = nullptr;
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLog::Backup(_In_ LPCTSTR pBackupFileName) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	return BackupEventLog(m_hEventLog, pBackupFileName);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::Clear(_In_opt_ LPCTSTR pBackupFileName) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	return ClearEventLog(m_hEventLog, pBackupFileName);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::GetNumberOfRecords(_Out_ DWORD& dwNumberOfRecords) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	return GetNumberOfEventLogRecords(m_hEventLog, &dwNumberOfRecords);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::GetOldestRecord(_Out_ DWORD& dwOldestRecord) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	return GetOldestEventLogRecord(m_hEventLog, &dwOldestRecord);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::NotifyChange(_In_ HANDLE hEvent) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	return NotifyChangeEventLog(m_hEventLog, hEvent);
}

_Return_type_success_(return != 0) BOOL CNTEventLog::ReadNext(_Out_ CEventLogRecord& record) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	DWORD dwBytesRead;
	DWORD dwBytesNeeded;
	EVENTLOGRECORD el;
	BOOL bSuccess = ReadEventLog(m_hEventLog, EVENTLOG_SEQUENTIAL_READ | EVENTLOG_FORWARDS_READ, 0, &el, sizeof(EVENTLOGRECORD), &dwBytesRead, &dwBytesNeeded);
	if (bSuccess)
		record = CEventLogRecord(&el);
	else if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
	{
		//Allocate some memory for the API
		ATL::CHeapPtr<BYTE> pBuffer;
		if (!pBuffer.Allocate(dwBytesNeeded))
		{
			SetLastError(ERROR_OUTOFMEMORY);
			return FALSE;
		}

		bSuccess = ReadEventLog(m_hEventLog, EVENTLOG_SEQUENTIAL_READ | EVENTLOG_FORWARDS_READ, 0, pBuffer, dwBytesNeeded, &dwBytesRead, &dwBytesNeeded);
		if (bSuccess)
			record = CEventLogRecord(reinterpret_cast<EVENTLOGRECORD*>(pBuffer.m_pData));
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLog::ReadPrev(_Out_ CEventLogRecord& record) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	DWORD dwBytesRead;
	DWORD dwBytesNeeded;
	EVENTLOGRECORD el;
	BOOL bSuccess = ReadEventLog(m_hEventLog, EVENTLOG_SEQUENTIAL_READ | EVENTLOG_BACKWARDS_READ, 0, &el, sizeof(EVENTLOGRECORD), &dwBytesRead, &dwBytesNeeded);
	if (bSuccess)
		record = CEventLogRecord(&el);
	else if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
	{
		//Allocate some memory for the API
		ATL::CHeapPtr<BYTE> pBuffer;
		if (!pBuffer.Allocate(dwBytesNeeded))
		{
			SetLastError(ERROR_OUTOFMEMORY);
			return FALSE;
		}

		bSuccess = ReadEventLog(m_hEventLog, EVENTLOG_SEQUENTIAL_READ | EVENTLOG_BACKWARDS_READ, 0, pBuffer, dwBytesNeeded, &dwBytesRead, &dwBytesNeeded);
		if (bSuccess)
			record = CEventLogRecord(reinterpret_cast<EVENTLOGRECORD*>(pBuffer.m_pData));
	}

	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTEventLog::GetFullInformation(_Out_ DWORD& dwFull) const
{
	//Validate our parameters
	ATLASSUME(m_hEventLog != nullptr);

	//Call through the function pointer
	EVENTLOG_FULL_INFORMATION efi;
	DWORD dwBytesNeeded = 0;
	BOOL bSuccess = GetEventLogInformation(m_hEventLog, EVENTLOG_FULL_INFO, &efi, sizeof(efi), &dwBytesNeeded);
	if (bSuccess)
		dwFull = efi.dwFull;

	return bSuccess;
}