/*
Module : ntservScmService.h
Purpose: CNTScmService��ӿڶ���
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
/////////////////////////////// Macros / Defines //////////////////////////////

#pragma once

#ifndef __NTSERVSCMSERVICE_H__
#define __NTSERVSCMSERVICE_H__


////////////////////////////// Includes ///////////////////////////////////////

#include "ntservDefines.h"


////////////////////////////// Classes ////////////////////////////////////////

//Forward declaration
class CNTServiceControlManager;

//An encapsulation of a service as returned from querying the SCM (i.e. an SC_HANDLE)
class CNTSERVICE_EXT_CLASS CNTScmService
{
public:
	//typedefs
	typedef BOOL (CALLBACK* ENUM_SERVICES_PROC)(void* pUserData, ENUM_SERVICE_STATUS& ss);

	//Constructors / Destructors
	CNTScmService();
	~CNTScmService();

	//Methods
	//Releases the underlying SC_HANDLE
	void Close();

	//Allows access to the underlying SC_HANDLE representing the service
	operator SC_HANDLE() const;

	//Attach / Detach support from an SDK SC_HANDLE
	_Return_type_success_(return != 0) BOOL Attach(_In_opt_ SC_HANDLE hService);
	SC_HANDLE Detach();

	//Changes the configuration of this service
	_Return_type_success_(return != 0) BOOL ChangeConfig(_In_ DWORD dwServiceType, _In_ DWORD dwStartType, _In_ DWORD dwErrorControl,
		_In_opt_ LPCTSTR pBinaryPathName, _In_opt_ LPCTSTR pLoadOrderGroup, _Out_opt_ LPDWORD pdwTagId,
		_In_opt_ LPCTSTR pDependencies, _In_opt_ LPCTSTR pServiceStartName, _In_opt_ LPCTSTR pPassword,
		_In_opt_ LPCTSTR pDisplayName) const;

	//Send a command to the service
	_Return_type_success_(return != 0) BOOL Control(_In_ DWORD dwControl);
	_Return_type_success_(return != 0) BOOL Control(_In_ DWORD dwControl, _In_ DWORD dwInfoLevel, _Inout_ PVOID pControlParams);

	//These functions call Control() with the standard predefined control codes
	_Return_type_success_(return != 0) BOOL Stop() const;			  //Ask the service to stop
	_Return_type_success_(return != 0) BOOL Pause() const;			  //Ask the service to pause
	_Return_type_success_(return != 0) BOOL Continue() const;	  //Ask the service to continue
	_Return_type_success_(return != 0) BOOL Interrogate() const; //Ask the service to update its status to the SCM

	//Waits for a service to stop with a configurable timeout
	_Return_type_success_(return != 0) BOOL WaitForStop(_In_ DWORD dwTimeout);

	//Waits for a service to have a certain status (with a configurable timeout)
	_Return_type_success_(return != 0) BOOL WaitForServiceStatus(_In_ DWORD dwTimeout, _In_ DWORD dwWaitForStatus, _In_ DWORD dwPollingInterval = 250);

	//Start the execution of the service
	_Return_type_success_(return != 0) BOOL Start(_In_ DWORD dwNumServiceArgs, _In_reads_opt_(dwNumServiceArgs) LPCTSTR* pServiceArgVectors) const;

	//Get the most return status of the service reported to the SCM by this service
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryStatus(_Out_ SERVICE_STATUS& ServiceStatus) const;

	//Get the configuration parameters of this service from the SCM
	_Return_type_success_(return != 0) BOOL QueryConfig(_Inout_ LPQUERY_SERVICE_CONFIG& pServiceConfig) const;

	//Add a new service to the SCM database
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL Create(_In_ CNTServiceControlManager& Manager, _In_ LPCTSTR pServiceName, _In_opt_ LPCTSTR pDisplayName,
		_In_ DWORD dwDesiredAccess, _In_ DWORD dwServiceType, _In_ DWORD dwStartType, _In_ DWORD dwErrorControl,
		_In_opt_ LPCTSTR pBinaryPathName, _In_opt_ LPCTSTR pLoadOrderGroup, _Out_opt_ LPDWORD pdwTagId, _In_opt_ LPCTSTR pDependencies,
		_In_opt_ LPCTSTR pServiceStartName, _In_opt_ LPCTSTR pPassword);

	//Mark this service as to be deleted from the SCM.
	_Return_type_success_(return != 0) BOOL Delete() const;

	//Enumerate the services that this service depends upon
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL EnumDependents(_In_ DWORD dwServiceState, _In_opt_ void* pUserData, _In_ ENUM_SERVICES_PROC pEnumServicesFunc) const;

	//Get the security information associated with this service
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryObjectSecurity(_In_ SECURITY_INFORMATION dwSecurityInformation, _Inout_ PSECURITY_DESCRIPTOR& pSecurityDescriptor) const;

	//Set the security descriptor associated with this service
	_Return_type_success_(return != 0) BOOL SetObjectSecurity(_In_ SECURITY_INFORMATION dwSecurityInformation, _In_ PSECURITY_DESCRIPTOR pSecurityDescriptor) const;

	//Windows 2000+ specific functions
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryDescription(_Out_ CNTServiceString& sDescription) const;
	_Return_type_success_(return != 0) BOOL ChangeDescription(_In_ const CNTServiceString& sDescription);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryFailureActions(_Inout_ LPSERVICE_FAILURE_ACTIONS& pActions) const;
	_Return_type_success_(return != 0) BOOL ChangeFailureActions(_In_opt_ LPSERVICE_FAILURE_ACTIONS pActions);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryStatus(_Out_ SERVICE_STATUS_PROCESS& ssp) const;

	//Windows Vista / 2008+ specific functions
	DWORD NotifyStatusChange(_In_ DWORD dwNotifyMask, _In_ PSERVICE_NOTIFY pNotifyBuffer) const;
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL  QueryDelayAutoStart(_Out_ BOOL& bDelayedAutoStart) const;
	_Return_type_success_(return != 0) BOOL  ChangeDelayAutoStart(_In_ BOOL bDelayedAutoStart);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL  QueryFailureActionsFlag(_Out_ BOOL& bFailureActionsOnNonCrashFailures) const;
	_Return_type_success_(return != 0) BOOL  ChangeFailureActionsFlag(_In_ BOOL bFailureActionsOnNonCrashFailures);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL  QuerySidInfo(_Out_ DWORD& dwServiceSidType) const;
	_Return_type_success_(return != 0) BOOL  ChangeSidInfo(_In_ DWORD dwServiceSidType);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL  QueryRequiredPrivileges(_Out_ CNTServiceStringArray& privileges) const;
	_Return_type_success_(return != 0) BOOL  ChangeRequiredPrivileges(_In_ const CNTServiceStringArray& priviledges);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL  QueryPreShutdown(_Out_ DWORD& dwPreshutdownTimeout) const;
	_Return_type_success_(return != 0) BOOL  ChangePreShutdown(_In_ DWORD dwPreshutdownTimeout);

	//Windows 7 / 2008 R2+ specific functions
	_Return_type_success_(return != 0) BOOL ChangeTrigger(_In_ PSERVICE_TRIGGER_INFO pTriggerInfo);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryTrigger(_Inout_ PSERVICE_TRIGGER_INFO& pTriggerInfo) const;
	_Return_type_success_(return != 0) BOOL ChangePreferredNode(_In_ USHORT usPreferredNode, _In_ BOOL bDelete);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryPreferredNode(_Out_ USHORT& usPreferredNode, _Out_ BOOL& bDelete) const;

	//Windows 8 / 2012+ specific functions
	_Return_type_success_(return != 0) DWORD SubscribeChangeNotifications(_In_ SC_EVENT_TYPE eEventType, _In_ PSC_NOTIFICATION_CALLBACK pCallback, _In_opt_ PVOID pCallbackContext, _Out_ PSC_NOTIFICATION_REGISTRATION* pSubscription) const;
	BOOL UnsubscribeChangeNotifications(_In_ PSC_NOTIFICATION_REGISTRATION pSubscription) const;
	DWORD WaitState(_In_ DWORD dwNotify, _In_ DWORD dwTimeout, _In_opt_ HANDLE hCancelEvent) const;

	//Windows 8.1+ specific functions
	_Return_type_success_(return != 0) BOOL ChangeLaunchProtected(_In_ DWORD dwLaunchProtected);
	_Must_inspect_result_ _Return_type_success_(return != 0) BOOL QueryLaunchProtected(_Out_ DWORD& dwLaunchProtected) const;

protected:
	//typedefs
	typedef BOOL (WINAPI NOTIFYSERVICESTATUSCHANGE)(_In_ SC_HANDLE, _In_ DWORD, _In_ PSERVICE_NOTIFY);
	typedef NOTIFYSERVICESTATUSCHANGE* LPNOTIFYSERVICESTATUSCHANGE;
	typedef BOOL (WINAPI CONTROLSERVICEEX)(_In_ SC_HANDLE, _In_ DWORD, _In_ DWORD, _Inout_ PVOID);
	typedef CONTROLSERVICEEX* LPCONTROLSERVICEEX;
	typedef DWORD (WINAPI SUBSCRIBESERVICECHANGENOTIFICIATIONS)(_In_ SC_HANDLE, _In_ SC_EVENT_TYPE, _In_ PSC_NOTIFICATION_CALLBACK, _In_opt_ PVOID, _Out_ PSC_NOTIFICATION_REGISTRATION*);
	typedef SUBSCRIBESERVICECHANGENOTIFICIATIONS* LPSUBSCRIBESERVICECHANGENOTIFICIATIONS;
	typedef VOID (WINAPI UNSUBSCRIBESERVICECHANGENOTIFICATIONS)(_In_ PSC_NOTIFICATION_REGISTRATION);
	typedef UNSUBSCRIBESERVICECHANGENOTIFICATIONS* LPUNSUBSCRIBESERVICECHANGENOTIFICATIONS;
	typedef DWORD (WINAPI WAITSERVICESTATE)(_In_  SC_HANDLE, _In_ DWORD, _In_opt_ DWORD, _In_opt_ HANDLE);
	typedef WAITSERVICESTATE* LPWAITSERVICESTATE;

	//Member variables
	SC_HANDLE                               m_hService;
	HINSTANCE                               m_hAdvapi32;                                //Instance handle of the "ADVAPI32.DLL" which houses most of the NT Service functions
	HINSTANCE                               m_hSecHost;                                 //Instance handle of the "SECHOST.DLL"
	LPNOTIFYSERVICESTATUSCHANGE             m_pfnNotifyServiceStatusChange;             //NotifyServiceStatusChange function pointer
	LPCONTROLSERVICEEX                      m_pfnControlServiceEx;                      //ControlServiceEx function pointer
	LPSUBSCRIBESERVICECHANGENOTIFICIATIONS  m_pfnSubscribeServiceChangeNotifications;   //SubscribeServiceChangeNotifications function pointer
	LPUNSUBSCRIBESERVICECHANGENOTIFICATIONS m_pfnUnsubscribeServiceChangeNotifications; //UnsubscribeServiceChangeNotifications function pointer
	LPWAITSERVICESTATE                      m_pfnWaitServiceState;
};

#endif //#ifndef __NTSERVSCMSERVICE_H__
