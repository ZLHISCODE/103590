/////////////////////////////// Macros / Defines //////////////////////////////

#pragma once
#ifndef __ZLHELPERSERVICE_H__
#define __ZLHELPERSERVICE_H__


////////////////////////////// Includes ///////////////////////////////////////

#include "ntserv.h"
#include "ntservServiceControlManager.h"
////////////////////////////// Classes ////////////////////////////////////////

class zlHelperService : public CNTService
{
public:
	zlHelperService();
	virtual void WINAPI ServiceMain(DWORD dwArgc, LPTSTR* pszArgv);
	virtual void OnStop();
	virtual void OnPause();
	virtual void OnContinue();
	virtual void ShowHelp();
	virtual void OnUserDefinedRequest(DWORD dwControl);

protected:
	volatile long		m_lWantStop;
	volatile long		m_lPaused;
	CNTServiceString	m_file;
	DWORD				m_dwBeepInternal;
};
#endif //#ifndef __ZLHELPERSERVICE_H__