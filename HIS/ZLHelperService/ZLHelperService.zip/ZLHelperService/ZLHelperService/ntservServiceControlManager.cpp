/*
Module : ntservServiceControlManager.cpp
Purpose: ʵ��CNTServiceControlManager�ӿ�
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/

/////////////////////////////////  Includes  //////////////////////////////////

#include "stdafx.h"
#include "ntservServiceControlManager.h"


////////////////////////////////// Macros / Defines ///////////////////////////

#ifdef CNTSERVICE_MFC_EXTENSIONS
#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG
#endif //#ifdef CNTSERVICE_MFC_EXTENSIONS


///////////////////////////////// Implementation //////////////////////////////

CNTServiceControlManager::CNTServiceControlManager() : m_hSCM(nullptr),
	m_hLock(nullptr),
	m_pfnRegisterServiceCtrlHandlerEx(nullptr),
	m_pfnEnumServicesStatusEx(nullptr)
{
	m_hAdvapi32 = GetModuleHandle(_T("ADVAPI32.DLL"));
	if (m_hAdvapi32 != nullptr)
	{
#ifdef _UNICODE
		m_pfnRegisterServiceCtrlHandlerEx = reinterpret_cast<LPREGISTERSERVICECTRLHANDLEREX>(GetProcAddress(m_hAdvapi32, "RegisterServiceCtrlHandlerExW"));
		m_pfnEnumServicesStatusEx  = reinterpret_cast<LPENUMSERVICESSTATUSEX>(GetProcAddress(m_hAdvapi32, "EnumServicesStatusExW"));
#else
		m_pfnRegisterServiceCtrlHandlerEx = reinterpret_cast<LPREGISTERSERVICECTRLHANDLEREX>(GetProcAddress(m_hAdvapi32, "RegisterServiceCtrlHandlerExA"));
		m_pfnEnumServicesStatusEx  = reinterpret_cast<LPENUMSERVICESSTATUSEX>(GetProcAddress(m_hAdvapi32, "EnumServicesStatusExA"));
#endif //#ifdef _UNICODE
	}
}

CNTServiceControlManager::~CNTServiceControlManager()
{
	Unlock();
	Close();
}

CNTServiceControlManager::operator SC_HANDLE() const
{
	return m_hSCM;
}

BOOL CNTServiceControlManager::Attach(_In_opt_ SC_HANDLE hSCM)
{
	if (m_hSCM != hSCM)
		Close();

	m_hSCM = hSCM;
	return TRUE;
}

SC_HANDLE CNTServiceControlManager::Detach()
{
	SC_HANDLE hReturn = m_hSCM;
	m_hSCM = nullptr;
	return hReturn;
}

_Must_inspect_result_ _Return_type_success_(return != 0) BOOL CNTServiceControlManager::Open(_In_opt_ LPCTSTR pszMachineName, _In_ DWORD dwDesiredAccess)
{
	Close();
	m_hSCM = OpenSCManager(pszMachineName, SERVICES_ACTIVE_DATABASE, dwDesiredAccess);
	return (m_hSCM != nullptr);
}

void CNTServiceControlManager::Close()
{
	if (m_hSCM)
	{
		CloseServiceHandle(m_hSCM);
		m_hSCM = nullptr;
	}
}

_Must_inspect_result_ _Return_type_success_(return != 0) BOOL CNTServiceControlManager::QueryLockStatus(_Inout_ LPQUERY_SERVICE_LOCK_STATUS& pLockStatus) const
{
	//Validate our parameters
	ATLASSUME(m_hSCM != nullptr);
	ATLASSERT(pLockStatus == nullptr); //To prevent double overwrites, this function asserts if you do not send in a null pointer

	DWORD dwBytesNeeded = 0;
	BOOL bSuccess = QueryServiceLockStatus(m_hSCM, nullptr, 0, &dwBytesNeeded);
	if (!bSuccess && GetLastError() == ERROR_INSUFFICIENT_BUFFER)
	{
		pLockStatus = reinterpret_cast<LPQUERY_SERVICE_LOCK_STATUS>(new BYTE[dwBytesNeeded]);
		DWORD dwSize = 0;
		bSuccess = QueryServiceLockStatus(m_hSCM, pLockStatus, dwBytesNeeded, &dwSize);
	}
	return bSuccess;
}

_Must_inspect_result_ _Return_type_success_(return != 0) BOOL CNTServiceControlManager::EnumServices(_In_ DWORD dwServiceType, _In_ DWORD dwServiceState, _In_opt_ void* pUserData, _In_ ENUM_SERVICES_PROC pEnumServicesFunc) const
{
	//Validate our parameters
	ATLASSUME(m_hSCM != nullptr);

	DWORD dwBytesNeeded = 0;
	DWORD dwServices = 0;
	DWORD dwResumeHandle = 0;
	BOOL bSuccess = EnumServicesStatus(m_hSCM, dwServiceType, dwServiceState, nullptr, 0, &dwBytesNeeded, &dwServices, &dwResumeHandle);
	if (!bSuccess && GetLastError() == ERROR_MORE_DATA)
	{
		//Allocate some memory for the API
		ATL::CHeapPtr<BYTE> pBuffer;
		if (!pBuffer.Allocate(dwBytesNeeded))
		{
			SetLastError(ERROR_OUTOFMEMORY);
			return FALSE;
		}

		LPENUM_SERVICE_STATUS pServices = reinterpret_cast<LPENUM_SERVICE_STATUS>(pBuffer.m_pData);
		DWORD dwSize = 0;
		bSuccess = EnumServicesStatus(m_hSCM, dwServiceType, dwServiceState, pServices, dwBytesNeeded, &dwSize, &dwServices, &dwResumeHandle);
		if (bSuccess)
		{
			BOOL bContinue = TRUE;
			for (DWORD i=0; i<dwServices && bContinue; i++)
				bContinue = pEnumServicesFunc(pUserData, pServices[i]);
		}
	}
	return bSuccess;
}

_Must_inspect_result_ _Return_type_success_(return != 0) BOOL CNTServiceControlManager::EnumServices(_In_ DWORD dwServiceType, _In_ DWORD dwServiceState, _In_opt_ LPCTSTR pszGroupName, _In_opt_ void* pUserData, _In_ ENUM_SERVICES_PROC2 pEnumServicesFunc) const
{
	//Check to see if the function pointer is available
	if (m_pfnEnumServicesStatusEx == nullptr)
	{
		ATLTRACE(_T("CNTServiceControlManager::EnumServices, EnumServicesStatusEx function is not supported on this OS. You need to be running at least Windows 2000 to use this function\n"));
		SetLastError(ERROR_CALL_NOT_IMPLEMENTED);
		return FALSE;
	}

	DWORD dwBytesNeeded = 0;
	DWORD dwServices = 0;
	DWORD dwResumeHandle = 0;
	BOOL bSuccess = m_pfnEnumServicesStatusEx(m_hSCM, SC_ENUM_PROCESS_INFO, dwServiceType, dwServiceState, nullptr, 0, &dwBytesNeeded, &dwServices, &dwResumeHandle, pszGroupName);
	if (!bSuccess && GetLastError() == ERROR_MORE_DATA)
	{
		//Allocate some memory for the API
		ATL::CHeapPtr<BYTE> pBuffer;
		if (!pBuffer.Allocate(dwBytesNeeded))
		{
			SetLastError(ERROR_OUTOFMEMORY);
			return FALSE;
		}

		LPENUM_SERVICE_STATUS_PROCESS pServices = reinterpret_cast<LPENUM_SERVICE_STATUS_PROCESS>(pBuffer.m_pData);
		DWORD dwSize = 0;
		bSuccess = m_pfnEnumServicesStatusEx(m_hSCM, SC_ENUM_PROCESS_INFO, dwServiceType, dwServiceState, reinterpret_cast<LPBYTE>(pServices), dwBytesNeeded, &dwSize, &dwServices, &dwResumeHandle, pszGroupName);
		if (bSuccess)
		{
			BOOL bContinue = TRUE;
			for (DWORD i=0; i<dwServices && bContinue; i++)
				bContinue = pEnumServicesFunc(pUserData, pServices[i]);
		}
	}
	return bSuccess;
}

_Must_inspect_result_ _Return_type_success_(return != 0) BOOL CNTServiceControlManager::OpenService(_In_ LPCTSTR pServiceName, _In_ DWORD dwDesiredAccess, _Out_ CNTScmService& service) const
{
	//Validate our parameters
	ATLASSUME(m_hSCM != nullptr);

	SC_HANDLE hService = ::OpenService(m_hSCM, pServiceName, dwDesiredAccess);
	BOOL bSuccess = (hService != nullptr);
	if (bSuccess)
		service.Attach(hService);
	return bSuccess;
}

_Return_type_success_(return != 0) BOOL CNTServiceControlManager::Lock()
{
	//Validate our parameters
	ATLASSUME(m_hSCM != nullptr);

	m_hLock = LockServiceDatabase(m_hSCM);
	return (m_hLock != nullptr);
}

_Return_type_success_(return != 0) BOOL CNTServiceControlManager::Unlock()
{
	BOOL bSuccess = TRUE;
	if (m_hLock)
	{
		bSuccess = UnlockServiceDatabase(m_hLock);
		m_hLock = nullptr;
	}

	return bSuccess;
}