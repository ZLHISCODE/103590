/*
Module : ntservDefines.h
Purpose: CNTService�������Ҫ�ı�������
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
//////////////////////// Macros / Defines /////////////////////////////////////

#pragma once

#ifndef __NTSERVDEFINES_H__
#define __NTSERVDEFINES_H__


//////////////////////// Enums / Defines //////////////////////////////////////

#ifndef CNTSERVICE_EXT_CLASS
#define CNTSERVICE_EXT_CLASS
#endif //#ifndef CNTSERVICE_EXT_CLASS

#ifndef __ATLBASE_H__
#pragma message("To avoid this message, please put atlbase.h in your pre compiled header (normally stdafx.h)")
#include <atlbase.h>
#endif //#ifndef __ATLBASE_H__



#ifndef _STRING_
#pragma message("To avoid this message, please put string in your pre compiled header (normally stdafx.h)")
#include <string>
#endif //#ifndef _STRING_

#ifndef _VECTOR_
#pragma message("To avoid this message, please put vector in your pre compiled header (normally stdafx.h)")
#include <vector>
#endif //#ifndef _VECTOR_

#ifndef _ALGORITHM_
#pragma message("To avoid this message, please put algorithm in your pre compiled header (normally stdafx.h)")
#include <algorithm>
#endif //#ifndef _ALGORITHM_

#ifdef _UNICODE
#define CNTServiceString std::wstring
#define CNTServiceStringArray std::vector<std::wstring>
#else
#define CNTServiceString std::string
#define CNTServiceStringArray std::vector<std::string>
#endif //#ifdef _UNICODE

#define CNTServiceByteArray std::vector<BYTE>


//Various defines from WinSvc.h to allow code to compile without the need for the latest Windows SDK

typedef struct tagWTSSESSION_NOTIFICATION
{
	DWORD cbSize;
	DWORD dwSessionId;
} WTSSESSION_NOTIFICATION, *PWTSSESSION_NOTIFICATION;


#ifndef SERVICE_CONFIG_LAUNCH_PROTECTED
#define SERVICE_CONFIG_LAUNCH_PROTECTED 12
#endif //#ifndef SERVICE_CONFIG_LAUNCH_PROTECTED

#ifndef SERVICE_LAUNCH_PROTECTED_NONE
#define SERVICE_LAUNCH_PROTECTED_NONE 0
#endif //#ifndef SERVICE_LAUNCH_PROTECTED_NONE

#ifndef SERVICE_CONTROL_LOWRESOURCES
#define SERVICE_CONTROL_LOWRESOURCES 0x00000060
#endif //#ifndef SERVICE_CONTROL_LOWRESOURCES

#ifndef SERVICE_CONTROL_SYSTEMLOWRESOURCES
#define SERVICE_CONTROL_SYSTEMLOWRESOURCES 0x00000061
#endif //#ifndef SERVICE_CONTROL_SYSTEMLOWRESOURCES



typedef struct _SERVICE_LAUNCH_PROTECTED_INFO 
{
	DWORD dwLaunchProtected; //Service launch protected
} SERVICE_LAUNCH_PROTECTED_INFO, *PSERVICE_LAUNCH_PROTECTED_INFO;

typedef enum _SC_EVENT_TYPE
{
	SC_EVENT_DATABASE_CHANGE,
	SC_EVENT_PROPERTY_CHANGE,
	SC_EVENT_STATUS_CHANGE
} SC_EVENT_TYPE, *PSC_EVENT_TYPE;

typedef
	VOID
	CALLBACK
	SC_NOTIFICATION_CALLBACK(
	_In_        DWORD                   dwNotify,
	_In_opt_    PVOID                   pCallbackContext
	);

typedef SC_NOTIFICATION_CALLBACK* PSC_NOTIFICATION_CALLBACK;

typedef struct _SC_NOTIFICATION_REGISTRATION* PSC_NOTIFICATION_REGISTRATION;


#ifndef _Return_type_success_
#define _Return_type_success_(expr)
#endif //#ifndef _Return_type_success_

#ifndef _In_reads_bytes_opt_
#define _In_reads_bytes_opt_(size)
#endif //#ifndef _In_reads_opt_

#ifndef _In_reads_opt_
#define _In_reads_opt_(size)
#endif //#ifndef _In_reads_opt_

#ifndef _Must_inspect_result_
#define _Must_inspect_result_
#endif //#ifndef _Must_inspect_result_

#ifndef _Out_writes_bytes_
#define _Out_writes_bytes_(size)
#endif 

#ifndef _Outptr_
#define _Outptr_
#endif //#ifndef _Outptr_

#ifndef _In_opt_
#define _In_opt_
#endif //#ifndef _In_opt_

#ifndef _In_
#define _In_
#endif //#ifndef _In_

#ifndef _Out_opt_
#define _Out_opt_
#endif //#ifndef _Out_opt_

#ifndef _Inout_
#define _Inout_
#endif //#ifndef _Inout_

#ifndef _Out_
#define _Out_
#endif //#ifndef _Out_

#ifndef _In_opt_z_
#define _In_opt_z_
#endif //#ifndef _In_opt_z_

#ifndef _In_z_
#define _In_z_
#endif //#ifndef _In_z_

#ifndef _Inout_opt_
#define _Inout_opt_
#endif //#ifndef _Inout_opt_

#define WTS_CURRENT_SERVER         ((HANDLE)NULL)
#define WTS_CURRENT_SERVER_HANDLE  ((HANDLE)NULL)
#define WTS_CURRENT_SERVER_NAME    (NULL)

/*
 *  Specifies the current session (SessionId)
 */
#define WTS_CURRENT_SESSION ((DWORD)-1)

/*
 *  Specifies any-session (SessionId)
 */
#define WTS_ANY_SESSION ((DWORD)-2)

typedef enum _WTS_CONNECTSTATE_CLASS {
    WTSActive,              // User logged on to WinStation
    WTSConnected,           // WinStation connected to client
    WTSConnectQuery,        // In the process of connecting to client
    WTSShadow,              // Shadowing another WinStation
    WTSDisconnected,        // WinStation logged on without client
    WTSIdle,                // Waiting for client to connect
    WTSListen,              // WinStation is listening for connection
    WTSReset,               // WinStation is being reset
    WTSDown,                // WinStation is down due to error
    WTSInit,                // WinStation in initialization
} WTS_CONNECTSTATE_CLASS;

typedef struct _WTS_SESSION_INFOW {
    DWORD SessionId;             // session id
    LPWSTR pWinStationName;      // name of WinStation this session is
                                 // connected to
    WTS_CONNECTSTATE_CLASS State; // connection state (see enum)
} WTS_SESSION_INFOW, * PWTS_SESSION_INFOW;

typedef struct _WTS_SESSION_INFOA {
    DWORD SessionId;             // session id
    LPSTR pWinStationName;       // name of WinStation this session is
                                 // connected to
    WTS_CONNECTSTATE_CLASS State; // connection state (see enum)
} WTS_SESSION_INFOA, * PWTS_SESSION_INFOA;

typedef struct _WTS_SESSION_INFO_1W {
    DWORD ExecEnvId;
    WTS_CONNECTSTATE_CLASS State;
    DWORD SessionId;
    LPWSTR pSessionName;
    LPWSTR pHostName;
    LPWSTR pUserName;
    LPWSTR pDomainName;
    LPWSTR pFarmName;
} WTS_SESSION_INFO_1W, * PWTS_SESSION_INFO_1W;

typedef struct _WTS_SESSION_INFO_1A {
    DWORD ExecEnvId;
    WTS_CONNECTSTATE_CLASS State;
    DWORD SessionId;
    LPSTR pSessionName;
    LPSTR pHostName;
    LPSTR pUserName;
    LPSTR pDomainName;
    LPSTR pFarmName;
} WTS_SESSION_INFO_1A, * PWTS_SESSION_INFO_1A;

#ifdef UNICODE
#define WTS_SESSION_INFO  WTS_SESSION_INFOW
#define PWTS_SESSION_INFO PWTS_SESSION_INFOW
#define WTS_SESSION_INFO_1  WTS_SESSION_INFO_1W
#define PWTS_SESSION_INFO_1 PWTS_SESSION_INFO_1W
#else
#define WTS_SESSION_INFO  WTS_SESSION_INFOA
#define PWTS_SESSION_INFO PWTS_SESSION_INFOA
#define WTS_SESSION_INFO_1  WTS_SESSION_INFO_1A
#define PWTS_SESSION_INFO_1 PWTS_SESSION_INFO_1A
#endif

typedef struct _WTS_PROCESS_INFOW {
    DWORD SessionId;     // session id
    DWORD ProcessId;     // process id
    LPWSTR pProcessName; // name of process
    PSID pUserSid;       // user's SID
} WTS_PROCESS_INFOW, * PWTS_PROCESS_INFOW;

typedef struct _WTS_PROCESS_INFOA {
    DWORD SessionId;     // session id
    DWORD ProcessId;     // process id
    LPSTR pProcessName;  // name of process
    PSID pUserSid;       // user's SID
} WTS_PROCESS_INFOA, * PWTS_PROCESS_INFOA;

#ifdef UNICODE
#define WTS_PROCESS_INFO  WTS_PROCESS_INFOW
#define PWTS_PROCESS_INFO PWTS_PROCESS_INFOW
#else
#define WTS_PROCESS_INFO  WTS_PROCESS_INFOA
#define PWTS_PROCESS_INFO PWTS_PROCESS_INFOA
#endif

typedef enum _WTS_INFO_CLASS {
    WTSInitialProgram,
    WTSApplicationName,
    WTSWorkingDirectory,
    WTSOEMId,
    WTSSessionId,
    WTSUserName,
    WTSWinStationName,
    WTSDomainName,
    WTSConnectState,
    WTSClientBuildNumber,
    WTSClientName,
    WTSClientDirectory,
    WTSClientProductId,
    WTSClientHardwareId,
    WTSClientAddress,
    WTSClientDisplay,
    WTSClientProtocolType,
    WTSIdleTime,
    WTSLogonTime,
    WTSIncomingBytes,
    WTSOutgoingBytes,
    WTSIncomingFrames,
    WTSOutgoingFrames,
    WTSClientInfo,
    WTSSessionInfo,
    WTSSessionInfoEx,
    WTSConfigInfo,
    WTSValidationInfo,   // Info Class value used to fetch Validation Information through the WTSQuerySessionInformation
    WTSSessionAddressV4,
    WTSIsRemoteSession
} WTS_INFO_CLASS;

typedef enum _WTS_TYPE_CLASS {
    WTSTypeProcessInfoLevel0,
    WTSTypeProcessInfoLevel1,
    WTSTypeSessionInfoLevel1,
} WTS_TYPE_CLASS;
//Win7 WTS32
typedef BOOL (WINAPI MY_WTSENUMERATESESSIONSEX)(HANDLE, DWORD*, DWORD,PWTS_SESSION_INFO_1*,DWORD*);
typedef MY_WTSENUMERATESESSIONSEX* LPMYWTSENUMERATESESSIONSEX;

//Win7 WTS32
typedef BOOL (WINAPI MY_WTSFREEMEMORYEX)(WTS_TYPE_CLASS, PVOID, ULONG);
typedef MY_WTSFREEMEMORYEX* LPMYWTSFREEMEMORYEX;

//Win7 WTS32
typedef BOOL (WINAPI MY_WTSENUMERATEPROCESSESEX)(HANDLE, DWORD*, DWORD, LPSTR*,DWORD*);
typedef MY_WTSENUMERATEPROCESSESEX* LPMYWTSENUMERATEPROCESSESEX;
//WTS32,Vista
typedef BOOL (WINAPI MY_WTSFREEMEMORY)(PVOID);
typedef MY_WTSFREEMEMORY* LPMYWTSFREEMEMORY;

//WTS32,Vista
typedef BOOL (WINAPI MY_WTSENUMERATESESSIONS)(HANDLE,DWORD,DWORD,PWTS_SESSION_INFOA*,DWORD*);
typedef MY_WTSENUMERATESESSIONS* LPMYWTSENUMERATESESSIONS;

//WTS32,Vista
typedef BOOL (WINAPI MY_WTSQUERYSESSIONINFORMATION)(HANDLE, DWORD, WTS_INFO_CLASS, LPSTR*,DWORD*);
typedef MY_WTSQUERYSESSIONINFORMATION* LPMYWTSQUERYSESSIONINFORMATION;
//WTS32,Vista
typedef BOOL (WINAPI MY_WTSTERMINATEPROCESS)(HANDLE, DWORD, DWORD);
typedef MY_WTSTERMINATEPROCESS* LPMYWTSTERMINATEPROCESS;

//Kernel32,Vista
typedef DWORD (WINAPI MY_WTSGETACTIVECONSOLESESSIONID)();
typedef MY_WTSGETACTIVECONSOLESESSIONID* LPMYWTSGETACTIVECONSOLESESSIONID;
//Kernel32,Vista
typedef DWORD (WINAPI MY_PROCESSIDTOSESSIONID)(DWORD,DWORD*);
typedef MY_PROCESSIDTOSESSIONID* LPMYPROCESSIDTOSESSIONID;

#endif //#ifndef __NTSERVDEFINES_H__
