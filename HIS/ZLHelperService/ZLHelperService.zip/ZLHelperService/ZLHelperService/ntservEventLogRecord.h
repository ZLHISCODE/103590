/*
Module : ntservEventLogRecord.h
Purpose: CEventLogRecord��ӿڶ���
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/
/////////////////////////////// Macros / Defines //////////////////////////////

#pragma once

#ifndef __NTSERVEVENTLOGRECORD_H__
#define __NTSERVEVENTLOGRECORD_H__


/////////////////////////////// Includes //////////////////////////////////////

#include "ntservDefines.h"


////////////////////////////// Classes ////////////////////////////////////////

//A friendlier way of handling EVENTLOGRECORD structures
class CNTSERVICE_EXT_CLASS CEventLogRecord
{
public: 
	//Constructors / Destructors
	CEventLogRecord();
	CEventLogRecord(_In_ const CEventLogRecord& record);
	CEventLogRecord(_In_opt_ const EVENTLOGRECORD* pRecord);

	//Methods
	CEventLogRecord& operator=(_In_ const CEventLogRecord& record);

	//Data
	DWORD                 m_dwRecordNumber;
	DWORD                 m_dwTimeGenerated;
	DWORD                 m_dwTimeWritten;
	DWORD                 m_dwEventID;
	WORD                  m_wEventType;
	WORD                  m_wEventCategory;
	CNTServiceByteArray   m_UserSID;
	CNTServiceStringArray m_Strings;
	CNTServiceByteArray   m_Data;
	CNTServiceString      m_sSourceName;
	CNTServiceString      m_sComputerName;
};

#endif //#ifndef __NTSERVEVENTLOGRECORD_H__