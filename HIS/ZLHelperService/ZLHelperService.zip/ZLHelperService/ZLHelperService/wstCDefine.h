//WST���ݱ��봦����WSt32Win7֮�ϲ�������ʹ�á���Ϊ�����ݴ���
#pragma once

#ifndef __WSTCDFINE_H__
#define __WSTCDFINE_H__
#ifndef _STRING_
#pragma message("To avoid this message, please put string in your pre compiled header (normally stdafx.h)")
#include <string>
#endif //#ifndef _STRING_

#ifdef _UNICODE
#define CNTString std::wstring
#else
#define CNTString std::string
#endif //#ifdef _UNICODE

#define WTS_CURRENT_SERVER         ((HANDLE)NULL)
#define WTS_CURRENT_SERVER_HANDLE  ((HANDLE)NULL)
#define WTS_CURRENT_SERVER_NAME    (NULL)

/*
 *  Specifies the current session (SessionId)
 */
#define WTS_CURRENT_SESSION ((DWORD)-1)

/*
 *  Specifies any-session (SessionId)
 */
#define WTS_ANY_SESSION ((DWORD)-2)

typedef enum _WTS_CONNECTSTATE_CLASS {
    WTSActive,              // User logged on to WinStation
    WTSConnected,           // WinStation connected to client
    WTSConnectQuery,        // In the process of connecting to client
    WTSShadow,              // Shadowing another WinStation
    WTSDisconnected,        // WinStation logged on without client
    WTSIdle,                // Waiting for client to connect
    WTSListen,              // WinStation is listening for connection
    WTSReset,               // WinStation is being reset
    WTSDown,                // WinStation is down due to error
    WTSInit,                // WinStation in initialization
} WTS_CONNECTSTATE_CLASS;

typedef struct _WTS_SESSION_INFOW {
    DWORD SessionId;             // session id
    LPWSTR pWinStationName;      // name of WinStation this session is
                                 // connected to
    WTS_CONNECTSTATE_CLASS State; // connection state (see enum)
} WTS_SESSION_INFOW, * PWTS_SESSION_INFOW;

typedef struct _WTS_SESSION_INFOA {
    DWORD SessionId;             // session id
    LPSTR pWinStationName;       // name of WinStation this session is
                                 // connected to
    WTS_CONNECTSTATE_CLASS State; // connection state (see enum)
} WTS_SESSION_INFOA, * PWTS_SESSION_INFOA;

typedef struct _WTS_SESSION_INFO_1W {
    DWORD ExecEnvId;
    WTS_CONNECTSTATE_CLASS State;
    DWORD SessionId;
    LPWSTR pSessionName;
    LPWSTR pHostName;
    LPWSTR pUserName;
    LPWSTR pDomainName;
    LPWSTR pFarmName;
} WTS_SESSION_INFO_1W, * PWTS_SESSION_INFO_1W;

typedef struct _WTS_SESSION_INFO_1A {
    DWORD ExecEnvId;
    WTS_CONNECTSTATE_CLASS State;
    DWORD SessionId;
    LPSTR pSessionName;
    LPSTR pHostName;
    LPSTR pUserName;
    LPSTR pDomainName;
    LPSTR pFarmName;
} WTS_SESSION_INFO_1A, * PWTS_SESSION_INFO_1A;

#ifdef UNICODE
#define WTS_SESSION_INFO  WTS_SESSION_INFOW
#define PWTS_SESSION_INFO PWTS_SESSION_INFOW
#define WTS_SESSION_INFO_1  WTS_SESSION_INFO_1W
#define PWTS_SESSION_INFO_1 PWTS_SESSION_INFO_1W
#else
#define WTS_SESSION_INFO  WTS_SESSION_INFOA
#define PWTS_SESSION_INFO PWTS_SESSION_INFOA
#define WTS_SESSION_INFO_1  WTS_SESSION_INFO_1A
#define PWTS_SESSION_INFO_1 PWTS_SESSION_INFO_1A
#endif

typedef struct _WTS_PROCESS_INFOW {
    DWORD SessionId;     // session id
    DWORD ProcessId;     // process id
    LPWSTR pProcessName; // name of process
    PSID pUserSid;       // user's SID
} WTS_PROCESS_INFOW, * PWTS_PROCESS_INFOW;

typedef struct _WTS_PROCESS_INFOA {
    DWORD SessionId;     // session id
    DWORD ProcessId;     // process id
    LPSTR pProcessName;  // name of process
    PSID pUserSid;       // user's SID
} WTS_PROCESS_INFOA, * PWTS_PROCESS_INFOA;

#ifdef UNICODE
#define WTS_PROCESS_INFO  WTS_PROCESS_INFOW
#define PWTS_PROCESS_INFO PWTS_PROCESS_INFOW
#else
#define WTS_PROCESS_INFO  WTS_PROCESS_INFOA
#define PWTS_PROCESS_INFO PWTS_PROCESS_INFOA
#endif

typedef enum _WTS_INFO_CLASS {
    WTSInitialProgram,
    WTSApplicationName,
    WTSWorkingDirectory,
    WTSOEMId,
    WTSSessionId,
    WTSUserName,
    WTSWinStationName,
    WTSDomainName,
    WTSConnectState,
    WTSClientBuildNumber,
    WTSClientName,
    WTSClientDirectory,
    WTSClientProductId,
    WTSClientHardwareId,
    WTSClientAddress,
    WTSClientDisplay,
    WTSClientProtocolType,
    WTSIdleTime,
    WTSLogonTime,
    WTSIncomingBytes,
    WTSOutgoingBytes,
    WTSIncomingFrames,
    WTSOutgoingFrames,
    WTSClientInfo,
    WTSSessionInfo,
    WTSSessionInfoEx,
    WTSConfigInfo,
    WTSValidationInfo,   // Info Class value used to fetch Validation Information through the WTSQuerySessionInformation
    WTSSessionAddressV4,
    WTSIsRemoteSession
} WTS_INFO_CLASS;

typedef enum _WTS_TYPE_CLASS {
    WTSTypeProcessInfoLevel0,
    WTSTypeProcessInfoLevel1,
    WTSTypeSessionInfoLevel1,
} WTS_TYPE_CLASS;
//Win7 WTS32
typedef BOOL (WINAPI MY_WTSENUMERATESESSIONSEX)(HANDLE, DWORD*, DWORD,PWTS_SESSION_INFO_1*,DWORD*);
typedef MY_WTSENUMERATESESSIONSEX* LPMYWTSENUMERATESESSIONSEX;

//Win7 WTS32
typedef BOOL (WINAPI MY_WTSFREEMEMORYEX)(WTS_TYPE_CLASS, PVOID, ULONG);
typedef MY_WTSFREEMEMORYEX* LPMYWTSFREEMEMORYEX;

//Win7 WTS32
typedef BOOL (WINAPI MY_WTSENUMERATEPROCESSESEX)(HANDLE, DWORD*, DWORD, LPSTR*,DWORD*);
typedef MY_WTSENUMERATEPROCESSESEX* LPMYWTSENUMERATEPROCESSESEX;
//Kernel32,WTS32
typedef BOOL (WINAPI MY_WTSFREEMEMORY)(PVOID);
typedef MY_WTSFREEMEMORY* LPMYWTSFREEMEMORY;

//Kernel32,WTS32
typedef BOOL (WINAPI MY_WTSENUMERATESESSIONS)(HANDLE,DWORD,DWORD,PWTS_SESSION_INFOA*,DWORD*);
typedef MY_WTSENUMERATESESSIONS* LPMYWTSENUMERATESESSIONS;

//Kernel32,WTS32
typedef BOOL (WINAPI MY_WTSQUERYSESSIONINFORMATION)(HANDLE, DWORD, WTS_INFO_CLASS, LPSTR*,DWORD*);
typedef MY_WTSQUERYSESSIONINFORMATION* LPMYWTSQUERYSESSIONINFORMATION;
//Kernel32,Vista
typedef DWORD (WINAPI MY_WTSGETACTIVECONSOLESESSIONID)();
typedef MY_WTSGETACTIVECONSOLESESSIONID* LPMYWTSGETACTIVECONSOLESESSIONID;
//Kernel32,Vista
typedef DWORD (WINAPI MY_PROCESSIDTOSESSIONID)(DWORD,DWORD*);
typedef MY_PROCESSIDTOSESSIONID* LPMYPROCESSIDTOSESSIONID;

#endif //#ifndef __WSTCDFINE_H__