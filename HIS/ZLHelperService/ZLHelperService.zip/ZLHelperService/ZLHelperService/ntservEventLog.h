/*
Module : ntservEventLog.h
Purpose: CNTEventLog�Ľӿڶ���
Created: PJN / 08-09-2003(Web: www.naughter.com, Email: pjna@naughter.com)
*/

/////////////////////////////// Macros / Defines //////////////////////////////

#pragma once

#ifndef __NTSERVEVENTLOG_H__
#define __NTSERVEVENTLOG_H__


////////////////////////////// Includes ///////////////////////////////////////

#include "ntservEventLogRecord.h"
#include "ntservDefines.h"


////////////////////////////// Classes ////////////////////////////////////////

//An encapsulation of the client side to the NT event log APIs
class CNTSERVICE_EXT_CLASS CNTEventLog
{
public:
	//Constructors / Destructors
	CNTEventLog();
	~CNTEventLog();

	//Methods
	operator HANDLE() const;
	_Return_type_success_(return != 0) BOOL Attach(_In_opt_ HANDLE hEventLog);
	HANDLE                                  Detach();
	_Return_type_success_(return != 0) BOOL Open(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pSourceName);
	_Return_type_success_(return != 0) BOOL OpenBackup(_In_opt_ LPCTSTR pUNCServerName, _In_ LPCTSTR pFileName);
	_Return_type_success_(return != 0) BOOL OpenApplication(_In_opt_ LPCTSTR pUNCServerName);
	_Return_type_success_(return != 0) BOOL OpenSystem(_In_opt_ LPCTSTR pUNCServerName);
	_Return_type_success_(return != 0) BOOL OpenSecurity(_In_opt_ LPCTSTR pUNCServerName);
	_Return_type_success_(return != 0) BOOL Close();
	_Return_type_success_(return != 0) BOOL Backup(_In_ LPCTSTR pBackupFileName) const;
	_Return_type_success_(return != 0) BOOL Clear(_In_opt_ LPCTSTR pBackupFileName) const;
	_Return_type_success_(return != 0) BOOL GetNumberOfRecords(_Out_ DWORD& dwNumberOfRecords) const;
	_Return_type_success_(return != 0) BOOL GetOldestRecord(_Out_ DWORD& dwOldestRecord) const;
	_Return_type_success_(return != 0) BOOL NotifyChange(_In_ HANDLE hEvent) const;
	_Return_type_success_(return != 0) BOOL ReadNext(_Out_ CEventLogRecord& record) const;
	_Return_type_success_(return != 0) BOOL ReadPrev(_Out_ CEventLogRecord& record) const;
	_Return_type_success_(return != 0) BOOL GetFullInformation(_Out_ DWORD& dwFull) const;

protected:
	HANDLE m_hEventLog;
};

#endif //#ifndef __NTSERVEVENTLOG_H__