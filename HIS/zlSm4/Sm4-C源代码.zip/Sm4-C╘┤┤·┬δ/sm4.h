/**
 * \file sm4.h
 */
#ifndef XYSSL_SM4_H
#define XYSSL_SM4_H

#define SM4_ENCRYPT     1
#define SM4_DECRYPT     0

/**
 * \brief          SM4 context structure
 */
typedef struct
{
    int mode;                   /*!<  encrypt/decrypt   */
    unsigned long sk[32];       /*!<  SM4 subkeys       */
}
sm4_context;

//�����ҵĺ���
extern "C" 
{
	__declspec(dllexport) void __stdcall sm4_crypt_ecb(
															   int mode,
															   int length,
															   unsigned char key[16],
															   unsigned char *input,
															   unsigned char *output);
	__declspec(dllexport) void __stdcall sm4_crypt_cbc(
				    											int mode,
																int length,
																unsigned char iv[16],
																unsigned char key[16],
																unsigned char *input,
																unsigned char *output );
}

#endif /* sm4.h */
