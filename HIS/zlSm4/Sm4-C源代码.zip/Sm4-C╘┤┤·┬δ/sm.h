#include "stdafx.h"
#include "sm4.h"
#include "sm3.h"
