﻿using System;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;

namespace ZLPubInterface
{
    public class clsDataBase
    {
        private int M_C_BLOBSIZE = -1;
        /// <summary>
        /// 错误编号
        /// </summary>
        private int m_intErrNumber;
        public int ErrorNumber
        {
            get { return m_intErrNumber; }
        }
        /// <summary>
        /// 错误描述
        /// </summary>
        private string m_strErrMessage;
        public string ErrorMessage
        {
            get { return m_strErrMessage; }
        }
        private string m_strCurConnString;
        /// <summary>
        /// 获取数据库连接
        /// </summary>
        /// <returns></returns>
        protected OracleConnection GetConnection()
        {
            if (m_strCurConnString == null) {
                m_intErrNumber = 20011;
                m_strErrMessage = "请设置连接字符串（调用OraDBOpen）。";
                return (new OracleConnection());
            }
            OracleConnection conn = new OracleConnection(m_strCurConnString);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                conn.Close();
                SetError(ex as OracleException);
            }
            return conn;
        }
        /// <summary>
        /// 根据服务器用户密码创建连接。都返回非nULL值，失败时，连接不打开，否则连接为打开状态
        /// </summary>
        /// <param name="strServer">服务器名，或者可以直接指定IP:Port/SID</param>
        /// <param name="strUserName">用户名</param>
        /// <param name="strPassword">密码</param>
        /// <param name="strErrNote">错误信息</param>
        /// <returns></returns>
        public OracleConnection OraDBOpen(string strServer, string strUserName, string strPassword)
        {
            SetError();
            if (strServer == null || strUserName == null || strPassword == null)
            {
                m_intErrNumber = 20010;
                m_strErrMessage = "服务器、用户名或密码为空。";
                return (new OracleConnection());
            }
            string strSID = null;
            string strIP = null;
            string strPort = null;
            bool blnSIDMode = false;
            if (strServer.Contains("/"))
            {
                string[] strArrTmp = strServer.Split('/');
                if (strArrTmp.Length == 2)
                {
                    strSID = strArrTmp[1];
                    if (strArrTmp[0].Contains(":"))
                    {
                        string[] strArrTmp1 = strArrTmp[0].Split(':');
                        if (strArrTmp.Length == 2)
                        {
                            strIP = strArrTmp1[0];
                            strPort = strArrTmp1[1];
                            blnSIDMode = true;
                        }
                        else
                        {
                            strIP = strArrTmp1[0];
                            strPort = "1521";
                            blnSIDMode = true;
                        }
                    }
                    else
                    {
                        strIP = strArrTmp[0];
                        strPort = "1521";
                        blnSIDMode = true;
                    }
                }
            }
            string strConnString = null;
            if (blnSIDMode)
            {
                strConnString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=" + strIP + ")(PORT=" + strPort + "))(CONNECT_DATA=(SERVICE_NAME=" + strSID + ")));User Id=" + strUserName + ";Password=" + strPassword + ";Persist Security Info=True";
            }
            else
            {
                strConnString = "Data Source=" + strServer + ";User Id=" + strUserName + ";Password=" + strPassword + ";Persist Security Info=True";
            }
            m_strCurConnString = strConnString;
            OracleConnection connReturn = GetConnection();
            return connReturn;
        }
        /// <summary>
        /// 初始化连接
        /// </summary>
        /// <param name="conn">连接对象</param>
        public void InitOracleConn(OracleConnection conn) {
            m_strCurConnString = conn.ConnectionString;
        }
        /// <summary>
        /// 执行SQL获取SQL返回的结果
        /// </summary>
        /// <param name="conn">连接对象</param>
        /// <param name="strErrNote">错误信息</param>
        /// <param name="strQuery">SQL</param>
        /// <param name="Parameters">绑定变量</param>
        /// <param name="ctType">命令类型</param>
        /// <returns>SQL查询结果</returns>
        public OracleDataReader ExecuteReader(string strQuery, OracleParameter[] Parameters, CommandType ctType)
        {
            SetError();
            OracleConnection conn = GetConnection();
            if (conn.State != ConnectionState.Open) {
                return null;
            } 
            try
            {
                using (OracleCommand cmd = new OracleCommand(strQuery, conn))
                {
                    cmd.CommandType = ctType;
                    cmd.AddToStatementCache = true;
                    cmd.BindByName = true;
                    cmd.InitialLOBFetchSize = M_C_BLOBSIZE;
                    if (Parameters != null)
                    {
                        foreach (OracleParameter p in Parameters)
                        {
                            cmd.Parameters.Add(p);
                        }
                    }
                    //备注:连接关闭后,Reader读取数据将报错.
                    return cmd.ExecuteReader(CommandBehavior.CloseConnection); //关闭Reader时,一并关闭连接.
                }
            }
            catch (Exception ex)
            {
                SetError(ex as OracleException);
                return null;
            }
        }
        /// <summary>
        /// 执行SQL
        /// </summary>
        /// <param name="conn">连接对象</param>
        /// <param name="strErrNote">错误信息</param>
        /// <param name="strQuery">查询SQL</param>
        /// <param name="Parameters">参数</param>
        /// <returns>查询结果</returns>
        public OracleDataReader ExecuteReader( string strQuery, OracleParameter[] Parameters)
        {
            return ExecuteReader(strQuery, Parameters, CommandType.Text);
        }
        /// <summary>
        /// 执行SQL
        /// </summary>
        /// <param name="conn">连接对象</param>
        /// <param name="strErrNote">错误信息</param>
        /// <param name="strQuery">查询SQL</param>
        /// <param name="Parameters">参数</param>
        /// <returns>查询结果</returns>
        public OracleDataReader ExecuteReader(string strQuery, params object[] Parameters)
        {
            return ExecuteReader(strQuery, CreateParameters(Parameters));
        }
        /// <summary>
        /// 执行sql获取对象
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="parameters">参数</param>
        /// <param name="ctType">命令行类型</param>
        /// <returns>返回结果</returns>
        public object ExecuteScalar(string strQuery, OracleParameter[] Parameters, CommandType ctType)
        {
            SetError();
            OracleConnection conn = GetConnection();
            if (conn.State != ConnectionState.Open)
            {
                return null;
            } 
            try
            {
                using (OracleCommand cmd = new OracleCommand(strQuery, conn))
                {
                    cmd.CommandType = ctType;
                    cmd.AddToStatementCache = true;
                    cmd.BindByName = true;
                    cmd.InitialLOBFetchSize = M_C_BLOBSIZE;

                    if (Parameters != null)
                    {
                        foreach (OracleParameter p in Parameters)
                        {
                            cmd.Parameters.Add(p);
                        }
                    }

                    return cmd.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                SetError(ex as OracleException);
                return null;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }
        /// <summary>
        /// 执行sql获取对象
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="parameters">参数</param>
        /// <returns>返回结果</returns>
        public object ExecuteScalar(string strQuery, OracleParameter[] Parameters)
        {
            return ExecuteScalar(strQuery, Parameters, CommandType.Text);
        }
        /// <summary>
        /// 执行sql获取对象
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="parameters">参数</param>
        /// <returns>返回结果</returns>
        public object ExecuteScalar(string strQuery, params object[] Parameters)
        {
            return ExecuteScalar(strQuery, CreateParameters(Parameters));
        }
        /// <summary>
        /// 执行sql
        /// </summary>
        /// <param name="strSql">SQL</param>
        /// <param name="Parameters">参数</param>
        /// <param name="ctType">类型</param>
        public void ExecuteNonQuery(string strSql, OracleParameter[] Parameters, CommandType ctType)
        {
            SetError();
            OracleConnection conn = GetConnection();
            if (conn.State != ConnectionState.Open)
            {
                return;
            } 
            try
            {
                using (OracleCommand cmd = new OracleCommand(strSql, conn))
                {
                    cmd.CommandType = ctType;
                    cmd.AddToStatementCache = true;
                    cmd.BindByName = true;
                    cmd.InitialLOBFetchSize = M_C_BLOBSIZE;
                    if (Parameters != null)
                    {
                        foreach (OracleParameter p in Parameters)
                        {
                            cmd.Parameters.Add(p);
                        }
                    }
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                SetError(ex as OracleException);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }
        /// <summary>
        /// 执行sql
        /// </summary>
        /// <param name="strSql">SQL</param>
        /// <param name="Parameters">参数</param>
        public void ExecuteNonQuery(string strSql, OracleParameter[] Parameters)
        {
            ExecuteNonQuery(strSql, Parameters, CommandType.Text);
        }
        /// <summary>
        /// 执行sql
        /// </summary>
        /// <param name="strSql">SQL</param>
        /// <param name="Parameters">参数</param>
        public void ExecuteNonQuery(string strSql, params object[] Parameters)
        {
            ExecuteNonQuery(strSql, CreateParameters(Parameters));
        }
        /// <summary>
        /// 执行sql获取Datatable
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="Parameters">参数</param>
        /// <param name="ctType">命令类型</param>
        /// <returns>返回结果</returns>
        public DataTable ExecuteDataTable(string strQuery, OracleParameter[] Parameters, CommandType ctType)
        {
            SetError();
            OracleConnection conn = GetConnection();
            if (conn.State != ConnectionState.Open)
            {
                return null;
            } 
            try
            {
                using (OracleCommand cmd = new OracleCommand(strQuery, conn))
                {
                    cmd.CommandType = ctType;
                    cmd.AddToStatementCache = true;
                    cmd.BindByName = true;
                    cmd.InitialLOBFetchSize = M_C_BLOBSIZE;

                    using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                    {
                        if (Parameters != null)
                        {
                            foreach (OracleParameter p in Parameters)
                            {
                                adapter.SelectCommand.Parameters.Add(p);
                            }
                        }
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                SetError(ex as OracleException);
                return null;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }
        /// <summary>
        /// 执行sql获取Datatable
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="Parameters">参数</param>
        /// <returns>返回结果</returns>
        public DataTable ExecuteDataTable(string strQuery, OracleParameter[] Parameters)
        {
            return ExecuteDataTable(strQuery, Parameters, CommandType.Text);
        }
        /// <summary>
        /// 执行sql获取Datatable
        /// </summary>
        /// <param name="strQuery">SQL</param>
        /// <param name="Parameters">参数</param>
        /// <returns>返回结果</returns>
        public DataTable ExecuteDataTable(string strQuery, params object[] Parameters)
        {
            return ExecuteDataTable(strQuery, CreateParameters(Parameters));
        }
        /// <summary>
        /// 返回错误信息描述
        /// </summary>
        /// <returns>错误描述</returns>
        public string GetErrNote() {
            if (this.ErrorNumber == 0) {
                return null;
            }else if(this.ErrorNumber == 20010 || this.ErrorNumber == 20011){
                return "(" + this.ErrorNumber + ")" + this.ErrorMessage;
            }else{
                return "(ora-" + this.ErrorNumber + ")" + this.ErrorMessage;
            }   
        }
        /// <summary>
        /// 创建ORACLE参数数组
        /// </summary>
        /// <param name="arrPars">参数组</param>
        /// <returns>参数数组</returns>
        OracleParameter[] CreateParameters(object[] arrPars)
        {
            List<OracleParameter> list = new List<OracleParameter>();
            for (int i = 0; i < arrPars.Length; i += 2)
            {
                //这里是解决一个比较奇怪的问题，如果参数的类型是char，新建的OracleParameter的OracleType会变成byte，执行时会出错，只好在这里进行特殊处理
                //但是，编写一个小程序的里面，char类型的转换是正确，转换成OracleType.VarChar，执行结果正确。
                OracleParameter p = null;
                if (arrPars[i + 1].GetType() == typeof(char))
                {
                    p = new OracleParameter(arrPars[i].ToString(), OracleDbType.Char);
                    p.Value = arrPars[i + 1];
                }
                else
                {
                    p = new OracleParameter(arrPars[i].ToString(), arrPars[i + 1]);
                }
                list.Add(p);
            }
            return list.ToArray();
        }

        /// <summary>
        /// 在所有数据库执行方法前调用该方法清除上次错误，在发生错误时使用该方法保存错误
        /// </summary>
        /// <param name="oraExp">数据库异常</param>
        private void SetError(OracleException oraExp = null)
        {
            if (oraExp == null)
            {
                m_intErrNumber = 0;
                m_strErrMessage = null;
            }
            else
            {
                m_intErrNumber = oraExp.Number;
                m_strErrMessage = oraExp.Message;
                switch (oraExp.Number)
                {
                    case 12505:
                        m_strErrMessage = "监听程序当前无法识别连接描述符中所给出的 SID,请检查服务名中配置的实例名称。";
                        break;
                    case 12170:
                        m_strErrMessage = "连接超时，请检查服务器名是否正确，网络是否可访问，以及是否被服务器防火墙阻止。";
                        break;
                    case 12154:
                        m_strErrMessage = "无法分析服务器名，请检查本机的Oracle配置文件(tnsnames.ora)中是否存在当前使用的服务名。";
                        break;
                    case 12541:
                        m_strErrMessage = "无法连接服务器，请检查服务器上的Oracle监听器服务是否启动。";
                        break;
                    case 01033:
                        m_strErrMessage = "ORACLE正在初始化或在关闭，请稍候再试。";
                        break;
                    case 01034:
                        m_strErrMessage = "ORACLE不可用，请检查数据库实例是否启动。";
                        break;
                    case 02391:
                        m_strErrMessage = "用户已经登录，不允许重复登录(已达到系统所允许的最大登录数)。";
                        break;
                    case 01017:
                        m_strErrMessage = "无效的用户名或密码，登录被拒绝。";
                        break;
                    case 28000:
                        m_strErrMessage = "该用户已经被禁用，不允许登录。";
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
